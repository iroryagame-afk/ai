# 缠论看盘（本地网页）— 安装说明（给 AI 助手看）

用户把这个文件夹交给你（Codex / Claude Code / Cursor 等），请按下面步骤帮他装好并启动。只做本地看图，不下单、不写任何账户数据。

## 这是什么
一个本地网页：输入股票代码，画缠论图（笔、线段、中枢、买卖点，MACD/KDJ 同屏，日线/30分/5分），支持美股和 A 股。
后端 Python（FastAPI + uvicorn），入口 `app/local_app.py`，缠论计算用开源 chan.py（MIT，在 `app/chanpy/`）。

## 前提
1. Python 3.10 及以上（Windows 用 python.org 安装包，勾选 “Add python.exe to PATH”）。
2. 富途 OpenD：从 https://www.futunn.com/download/OpenAPI 下载对应系统版本，用户用**自己的**富途账号登录，端口保持默认 11111。没有 OpenD 图表会是空的，要如实告诉用户，不要说“已装好能用”。

## 安装（在本文件夹的 app 目录里执行）
Windows（PowerShell 或 cmd）：
    cd app
    python -m venv .venv
    .venv\Scripts\python -m pip install -r requirements.txt
macOS / Linux：
    cd app
    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt

## 启动
Windows：双击 `启动-Windows.bat`，或在 app 目录执行
    .venv\Scripts\python -m uvicorn local_app:app --host 127.0.0.1 --port 18791
macOS / Linux：`sh 启动-Mac.sh`
然后浏览器打开 http://127.0.0.1:18791 。端口被占可改成 18792。

## 自检（全部 200 才算装好）
- http://127.0.0.1:18791/
- http://127.0.0.1:18791/api/status
- http://127.0.0.1:18791/api/chan?market=us&code=SPY&period=day  （需要 OpenD 已登录）

## 用法
- 首页搜索：代码、名称或拼音首字母（AAPL、600519、gzmt）。
- 指数：标普 `.SPX`、纳指 `.IXIC`、上证 `SH.000001`。
- 想要自选名单就用浏览器书签存个股链接，例如 http://127.0.0.1:18791/?code=NVDA&market=us&period=30m

## 常见问题
- Windows 弹“已保护你的电脑”：点“更多信息 → 仍要运行”。防火墙弹窗选允许。
- 图是空的：先检查 OpenD 是否运行并登录、端口是否 11111、账号是否有该市场行情权限。
- 关闭：关掉命令行窗口，或 Ctrl+C。

## 声明
买卖点是 chan.py 的程序化工程规则，不等同于原著严格结论，仅供学习研究，不构成投资建议。
