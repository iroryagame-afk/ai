/*CSUG 本地码表搜索：空闲预取 sug.js，与服务端同排序；未加载时回落 API*/
(function(){if(window.CSUG)return;let R=null,P=null;
const ver=()=>{const t=new Date(Date.now()+8*3600e3);return ''+t.getUTCFullYear()+(t.getUTCMonth()+1)+t.getUTCDate()};
function load(){if(R)return Promise.resolve(R);if(P)return P;P=new Promise(ok=>{const s=document.createElement('script');s.src='sug.js?v='+ver();s.async=true;s.onload=()=>{const a=window.__SUG||[];R=a.map(r=>{const n=r[2]||r[1];return{m:r[0]?'us':'a',c:r[1],n,N:String(n).toUpperCase(),py:r[3]?r[3].split('|'):[],h:r[4]??1,mc:r[5]||0,al:r[6]?r[6].split('|'):[],AL:r[6]?r[6].toUpperCase().split('|'):[],hot:r[7]??999}});window.__SUG=null;ok(R)};s.onerror=()=>{P=null;ok(null)};document.head.appendChild(s)});return P}
function match(q,limit){if(!R)return null;q=String(q||'').trim().toUpperCase();limit=limit||12;if(!q)return[];const t=[[],[],[],[],[],[]],seen=new Set();
for(const x of R){const c=x.c,n=x.N,py=x.py,al=x.AL;let k;
if(c===q)k=0;else if(al.includes(q))k=1;else if(c.startsWith(q))k=2;else if(n===q||py.includes(q))k=3;
else if(n.startsWith(q)||al.some(a=>a.startsWith(q))||(q.length>=2&&py.some(z=>z.startsWith(q))))k=4;
else if(c.includes(q)||n.includes(q)||al.some(a=>a.includes(q)))k=5;else continue;
const key=x.m+':'+c;if(seen.has(key))continue;seen.add(key);t[k].push(x)}
const cmp=(a,b)=>(a.hot-b.hot)||(a.h-b.h)||(b.mc-a.mc)||(a.c.length-b.c.length)||(a.c<b.c?-1:a.c>b.c?1:0);
for(let i=2;i<6;i++)t[i].sort(cmp);
return [].concat(...t).slice(0,limit).map(x=>{let n=x.n;if(x.m==='us'&&x.al.length&&!n.includes(x.al[0]))n=(n||x.c)+'（'+x.al[0]+'）';return{market:x.m,code:x.c,name:n}})}
const codeLike=q=>/^\d{6}$/.test(q)||/^[A-Z][A-Z.\-]{0,9}$/i.test(q);
const nameOf=(m,c)=>{if(!R)return '';c=String(c||'').toUpperCase();const x=R.find(y=>y.m===m&&y.c===c);return x&&x.n!==x.c?x.n:''};
window.CSUG={load,match,codeLike,nameOf,ready:()=>!!R};
const idle=window.requestIdleCallback||(f=>setTimeout(f,1500));idle(()=>load(),{timeout:4000})})();
/* 缠论站统一导航 + 登录注册 + 收藏（全站共用） */
(function(){
const cur=location.pathname.endsWith('/home')?'home':(document.currentScript&&document.currentScript.dataset.cur)||'';
const brand='缠论看盘';
const logo='<svg width="32" height="32" viewBox="0 0 36 36" aria-hidden="true"><rect x="1" y="1" width="34" height="34" rx="4" fill="#a9322b"/><rect x="3.6" y="3.6" width="28.8" height="28.8" rx="1.7" fill="none" stroke="#ffe9cd" stroke-width="1"/><g fill="#fff0d9" text-anchor="middle" font-family="Songti SC,SimSun,serif" font-size="12" font-weight="800"><text x="24" y="16.5">缠</text><text x="24" y="28.5">论</text><text x="12" y="16.5">看</text><text x="12" y="28.5">盘</text></g></svg>';
const NAV=[['search','./','首页·搜索']];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const css=`.cnav{display:flex;align-items:center;gap:4px;flex-wrap:wrap;font-size:14px}
.cnav a.ni{padding:5px 11px;border-radius:8px;color:#6b5a3e;text-decoration:none;white-space:nowrap}
.cnav a.ni:hover{background:#f5ecda}.cnav a.ni.on{background:#c48a2c;color:#fff;font-weight:600}
.cnav a.ni.external{color:#285e83;background:#edf4fa;font-weight:600;margin-inline:3px}
.cnav a.ni.external:hover,.cnav a.ni.external:focus-visible{background:#dbeaf6;color:#184568}
.cnav .nu{margin-left:6px;padding-left:10px;border-left:1px solid #e6dcc8;display:flex;gap:6px;align-items:center;white-space:nowrap}
.cnav .nu a{color:#8a5a12;text-decoration:none;font-size:13px}.cnav .nu b{font-weight:600;color:#5a4a30;font-size:13px}
.cnav-bar{position:sticky;top:0;left:0;z-index:60;box-sizing:border-box;width:100%;max-width:none;height:44px;min-height:44px;flex:none;margin:0;padding:0 16px;display:flex;align-items:center;justify-content:flex-start;gap:12px;background:rgba(255,253,248,.97);backdrop-filter:blur(6px);border-bottom:1px solid #ece3d3;font:14px/1 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;grid-column:1/-1;align-self:stretch;overflow-x:auto;overflow-y:hidden;scrollbar-width:none}
.cnav-bar::-webkit-scrollbar{display:none}
.cnav-bar .cnav{flex-wrap:nowrap;font-size:14px;margin:0}
.cnav-bar .logo{display:inline-flex;align-items:center;gap:6px;flex:none;font-weight:700;color:#8a5a12;text-decoration:none;font-size:15px;margin-right:4px;white-space:nowrap}
body>header{top:44px!important}
@media(max-width:700px){.cnav-bar{padding:0 8px;gap:4px}.cnav-bar .cnav a.ni{padding:5px 8px;font-size:13px}.cnav-bar .logo span{display:none}.cnav-bar .nu{margin-left:2px;padding-left:6px}}
.cn-star{border:0;background:transparent;cursor:pointer;font-size:18px;line-height:1;color:#c9b99a;padding:2px 4px;border-radius:6px}
.cn-star:hover{background:#f5ecda}.cn-star.on{color:#e0a020}
.cn-mask{position:fixed;inset:0;background:rgba(40,30,15,.35);display:none;align-items:center;justify-content:center;z-index:999}
.cn-mask.show{display:flex}.cn-dlg{background:#fffdf8;border-radius:14px;width:min(340px,92vw);padding:22px 22px 18px;box-shadow:0 12px 40px rgba(0,0,0,.18);font-size:14px}
.cn-dlg h3{margin:0 0 4px;font-size:18px;color:#3d3222}.cn-dlg p{margin:0 0 14px;color:#8a8072;font-size:12.5px}
.cn-tabs{display:flex;border:1px solid #e3d9c6;border-radius:8px;overflow:hidden;margin-bottom:12px}.cn-tabs button{flex:1;border:0;background:#fff;height:34px;cursor:pointer;font-size:14px}.cn-tabs button.on{background:#c48a2c;color:#fff}
.cn-dlg input{width:100%;box-sizing:border-box;height:38px;border:1px solid #e3d9c6;border-radius:8px;padding:0 10px;margin-bottom:10px;font-size:14px;background:#fff}
.cn-dlg .row{display:flex;gap:8px;justify-content:flex-end;margin-top:4px}.cn-dlg .row button{height:36px;padding:0 18px;border-radius:8px;border:1px solid #e3d9c6;background:#fff;cursor:pointer;font-size:14px}
.cn-dlg .row .pri{background:#c48a2c;border-color:#c48a2c;color:#fff;font-weight:600}.cn-err{color:#c0392b;font-size:12.5px;min-height:16px;margin-bottom:6px}
.cn-hint{position:fixed;right:18px;bottom:22px;max-width:340px;background:#fffdf8;border:1px solid #e6dcc8;border-radius:12px;padding:12px 30px 12px 14px;font-size:12.5px;color:#6b5a3e;line-height:1.7;box-shadow:0 6px 20px rgba(0,0,0,.08);z-index:998}.cn-hint a{color:#8a5a12}.cn-hint .x{position:absolute;right:8px;top:6px;cursor:pointer;color:#b0a693}
.cn-note{font-size:12.5px;color:#7a6c55;background:#fbf6ec;border:1px solid #efe1c4;border-radius:10px;padding:8px 12px;line-height:1.7}.cn-note a{color:#8a5a12}
.cn-toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);background:#3d3222;color:#fff;padding:8px 16px;border-radius:20px;font-size:13px;z-index:1000;opacity:0;transition:opacity .2s;pointer-events:none}.cn-toast.show{opacity:.92}`;
const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
const LK='cw_favs_local';const lget=()=>{try{return JSON.parse(localStorage[LK]||'[]')}catch(e){return []}};const lset=a=>localStorage[LK]=JSON.stringify(a);
const CN=window.CN={NOTE:'不登录也能收藏，收藏存在本设备浏览器里，换设备或清除浏览器数据会丢；登录后自动同步到账号，换设备也在。',me:null,favs:new Set(),key:(m,c)=>m+':'+String(c).toUpperCase(),listeners:[]};
async function api(p,o={}){const r=await fetch(p,{credentials:'same-origin',...o,headers:{'Content-Type':'application/json'}});let j={};try{j=await r.json()}catch(e){}if(!r.ok)throw new Error(typeof j.detail==='string'?j.detail:('请求失败 '+r.status));return j}
CN.api=api;
function navHtml(){return NAV.map(([k,h,t,external])=>`<a class="ni${k===cur?' on':''}${external?' external':''}" href="${h}${external?'':'?nav=shared'}"${external?' target="_blank" rel="noopener noreferrer" title="外部链接，在新标签页打开"':''}${k===cur?' aria-current="page"':''}>${t}${external?' <span aria-hidden="true">↗</span>':''}</a>`).join('')+
 `<span class="nu">${CN.me?`<b>👤 ${esc(CN.me)}</b><a href="settings" class="${cur==='settings'?'on':''}" title="微信推送设置">⚙ 设置</a><a href="#" data-cn="logout">退出</a>`:`<a href="#" data-cn="login">登录 / 注册</a>`}</span>`}
function render(){document.querySelectorAll('.cnav').forEach(n=>n.innerHTML=navHtml());document.querySelectorAll('.cn-note').forEach(n=>n.innerHTML=CN.noteHtml());
 document.querySelectorAll('.cn-star').forEach(b=>{const on=CN.favs.has(CN.key(b.dataset.m,b.dataset.c));b.classList.toggle('on',on);b.textContent=b.dataset.txt?(on?'★ 已收藏':'☆ 收藏'):(on?'★':'☆');b.title=on?'取消收藏':'收藏'})}
CN.render=render;
CN.star=(m,c,n,txt)=>`<button type="button" class="cn-star" data-m="${esc(m)}" data-c="${esc(c)}" data-n="${esc(n||'')}"${txt?' data-txt="1"':''}>☆</button>`;
function mount(){document.querySelectorAll('#cnav-slot').forEach(n=>n.remove());
 document.title=cur==='search'?brand:brand+' · '+document.title.replace(/^缠论站\s*·\s*/, '');
 {const bar=document.createElement('div');bar.className='cnav-bar';bar.innerHTML='<a class="logo" href="./?nav=shared" aria-label="'+brand+'">'+logo+'<span>'+brand+'</span></a><nav class="cnav" aria-label="缠论看盘 主导航"></nav>';document.body.prepend(bar)}
 const m=document.createElement('div');m.className='cn-mask';m.id='cnAuth';
 m.innerHTML=`<div class="cn-dlg"><h3 id="cnT">登录缠论站</h3><p id="cnP">登录后收藏自动同步到账号，换设备也在</p><div class="cn-tabs"><button data-t="login" class="on">登录</button><button data-t="register">注册</button></div>
 <input id="cnU" placeholder="用户名（3–20 位）" autocomplete="username"><input id="cnW" type="password" placeholder="密码（至少 8 位）" autocomplete="current-password"><div class="cn-err" id="cnE"></div>
 <div class="row"><button data-cn="close">取消</button><button class="pri" id="cnOk">登录</button></div></div>`;document.body.appendChild(m);
 const t=document.createElement('div');t.className='cn-toast';t.id='cnToast';document.body.appendChild(t);
 let tab='login';m.querySelector('.cn-tabs').onclick=e=>{const k=e.target.dataset.t;if(!k)return;tab=k;m.querySelectorAll('.cn-tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===k));m.querySelector('#cnOk').textContent=k==='login'?'登录':'注册并登录';m.querySelector('#cnW').autocomplete=k==='login'?'current-password':'new-password'};
 m.querySelector('#cnOk').onclick=async()=>{const E=m.querySelector('#cnE');E.textContent='';try{await api('api/'+tab,{method:'POST',body:JSON.stringify({username:m.querySelector('#cnU').value.trim(),password:m.querySelector('#cnW').value})});m.querySelector('#cnW').value='';m.classList.remove('show');await CN.refresh();toast(tab==='login'?'已登录':'注册成功，已登录');if(CN._after){const f=CN._after;CN._after=null;f()}}catch(e){E.textContent=e.message}};
 m.querySelector('#cnW').onkeydown=e=>{if(e.key==='Enter')m.querySelector('#cnOk').click()};
 m.onclick=e=>{if(e.target===m)m.classList.remove('show')};}
function toast(s){const t=document.getElementById('cnToast');if(!t)return;t.textContent=s;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),1600)}
CN.toast=toast;
CN.openAuth=(msg)=>{const m=document.getElementById('cnAuth');m.querySelector('#cnP').textContent=msg||'登录后收藏自动同步到账号，换设备也在';m.querySelector('#cnE').textContent='';m.classList.add('show');setTimeout(()=>m.querySelector('#cnU').focus(),30)};
CN.refresh=async()=>{try{let r=await api('api/fav');CN.me=r.user;
 if(CN.me){const L=lget();if(L.length){for(const x of L){try{await api('api/fav',{method:'POST',body:JSON.stringify({market:x.market,code:x.code,name:x.name||null,on:true})})}catch(e){}}lset([]);r=await api('api/fav');toast('本机 '+L.length+' 只收藏已同步到账号')}CN.items=r.items||[]}else CN.items=lget();
 CN.favs=new Set(CN.items.map(x=>CN.key(x.market,x.code)))}catch(e){CN.me=null;CN.items=lget();CN.favs=new Set(CN.items.map(x=>CN.key(x.market,x.code)))}render();CN.listeners.forEach(f=>{try{f()}catch(e){}})};
CN.noteHtml=()=>CN.me?`☁️ 收藏已同步到账号 <b>${esc(CN.me)}</b>，换设备登录也在。`:`💡 ${CN.NOTE} <a href="#" data-cn="login">登录 / 注册</a>`;
function hint(){if(localStorage.cw_fav_hint)return;localStorage.cw_fav_hint=1;const h=document.createElement('div');h.className='cn-hint';h.innerHTML='<span class="x">✕</span>'+CN.noteHtml();h.querySelector('.x').onclick=()=>h.remove();document.body.appendChild(h);setTimeout(()=>h.remove(),12000)}
CN.toggle=async(m,c,n)=>{const on=!CN.favs.has(CN.key(m,c));
 if(!CN.me){let L=lget().filter(x=>CN.key(x.market,x.code)!==CN.key(m,c));if(on)L.unshift({market:m,code:String(c).toUpperCase(),name:n||c,added:Date.now()/1000});lset(L);CN.items=L;on?CN.favs.add(CN.key(m,c)):CN.favs.delete(CN.key(m,c));render();toast(on?'已收藏到本机 '+(n||c):'已取消收藏');if(on)hint();CN.listeners.forEach(f=>{try{f()}catch(e){}});return}
 try{await api('api/fav',{method:'POST',body:JSON.stringify({market:m,code:c,name:n||null,on})});on?CN.favs.add(CN.key(m,c)):CN.favs.delete(CN.key(m,c));render();toast(on?'已收藏 '+(n||c):'已取消收藏');CN.listeners.forEach(f=>{try{f()}catch(e){}})}catch(e){toast(e.message)}};
document.addEventListener('click',e=>{const s=e.target.closest('.cn-star');if(s){e.preventDefault();e.stopPropagation();CN.toggle(s.dataset.m,s.dataset.c,s.dataset.n);return}
 const a=e.target.closest('[data-cn]');if(!a)return;e.preventDefault();const k=a.dataset.cn;
 if(k==='login')CN.openAuth();if(k==='close')document.getElementById('cnAuth').classList.remove('show');
 if(k==='logout')api('api/logout',{method:'POST'}).catch(()=>{}).then(()=>CN.refresh().then(()=>toast('已退出')))},true);
new MutationObserver(()=>{clearTimeout(CN._mo);CN._mo=setTimeout(()=>{const n=document.querySelectorAll('.cn-star:not([data-r])');if(!n.length)return;n.forEach(b=>b.dataset.r=1);render()},30)}).observe(document.documentElement,{childList:true,subtree:true});
CN.ready=new Promise(r=>{const go=()=>{mount();CN.refresh().then(r)};document.readyState==='loading'?document.addEventListener('DOMContentLoaded',go):go()});
})();

/* 全站右上角搜索（统一组件） */
(function(){
function init(){
 if(document.getElementById('csw'))return;
 const st=document.createElement('style');st.textContent=`
#csw{margin-left:auto;position:relative;display:flex;align-items:center;flex:none}
#csw input{width:210px;height:30px;box-sizing:border-box;border:1px solid #e3d9c6;border-radius:15px;padding:0 12px 0 30px;font-size:13.5px;background:#fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23a08a64' stroke-width='2.5'%3E%3Ccircle cx='11' cy='11' r='7'/%3E%3Cpath d='M20 20l-4-4'/%3E%3C/svg%3E") no-repeat 10px center;outline:none;color:#3a3024}
#csw input:focus{border-color:#c48a2c}
#csw .ic{display:none;border:0;background:none;font-size:18px;cursor:pointer;padding:4px 6px;color:#8a5a12}
#csw .x{display:none}
#home-search #csw{margin:0;position:relative;padding:0;background:none}
#home-search #csw input{display:block;width:100%;height:54px;border-radius:27px;padding-left:42px;font-size:17px;background-position:17px center;box-shadow:0 3px 12px rgba(65,42,14,.08)}
#home-search #csw .ic{display:none}
#csd{position:fixed;z-index:200;background:#fff;border:1px solid #e3d9c6;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.12);max-height:45vh;overflow:auto;min-width:260px;display:none;font:14px/1.4 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
#csd div{padding:8px 12px;cursor:pointer;display:flex;justify-content:space-between;gap:10px}
#csd div.on,#csd div:hover{background:#f7efe0}#csd small{color:#9a907f;white-space:nowrap}
@media(max-width:520px){#csw{position:sticky;right:0;background:#fffdf8;padding-left:4px}#csw input{display:none}#csw .ic{display:block}
#csw.open{position:fixed;left:0;right:0;top:0;height:44px;background:#fffdf8;z-index:210;padding:0 8px;gap:6px;border-bottom:1px solid #ece3d3}
#csw.open input{display:block;flex:1;width:auto;font-size:16px}#csw.open .ic{display:none}#csw.open .x{display:block;border:0;background:none;font-size:15px;color:#8a5a12;padding:6px}
#csd{left:6px!important;right:6px!important;min-width:0}}`;document.head.appendChild(st);
 const w=document.createElement('div');w.id='csw';
 w.innerHTML='<button class="ic" aria-label="搜索">🔍</button><input type="search" placeholder="代码 / 名称 / 拼音" autocomplete="off" enterkeyhint="search"><button class="x">取消</button>';
 const host=document.querySelector('#home-search')||document.querySelector('.cnav-bar');
 if(host)host.appendChild(w);else{w.style.cssText='position:fixed;top:7px;right:12px;z-index:70';document.body.appendChild(w)}
 const d=document.createElement('div');d.id='csd';document.body.appendChild(d);
 const q=w.querySelector('input');let items=[],sel=0,seq=0;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const pos=()=>{const r=(w.classList.contains('open')?w:q).getBoundingClientRect();d.style.top=(r.bottom+4)+'px';d.style.right=Math.max(6,innerWidth-r.right)+'px';d.style.left='auto'};
 const draw=()=>{if(!items.length){d.style.display='none';return}d.innerHTML=items.map((x,i)=>`<div class="${i===sel?'on':''}" data-i="${i}"><b>${esc(x.name||x.code)}</b><small>${esc(x.code)} · ${(x.market==='us'&&/^\./.test(x.code)?'美股指数':x.market==='us'&&/MAIN$/.test(x.code)?'外盘期货':x.market==='a'?'沪深':'美股')}</small></div>`).join('');pos();d.style.display='block'};
 const go=x=>{if(x)location.href='./?code='+encodeURIComponent(x.code)+'&market='+x.market+'&period=day'};
 const msg=(h)=>{items=[];d.innerHTML='<div class="m" style="color:#9a907f;cursor:default">'+h+'</div>';pos();d.style.display='block'};
 let tmo=null;
 async function f(v){const n=++seq;clearTimeout(tmo);if(!v){items=[];draw();return items}
  const C=window.CSUG,loc=C&&C.match(v,12);
  if(loc){items=loc;sel=0;const U=v.toUpperCase();if(items.length&&(items.some(x=>x.code===U)||!C.codeLike(v))){draw();return items}if(items.length)draw()}
  if(!loc||!loc.length){msg('搜索中…');tmo=setTimeout(()=>{if(n===seq){msg('网络较慢，点此重试');const m=d.querySelector('.m');if(m){m.style.cursor='pointer';m.onmousedown=e=>{e.preventDefault();f(q.value.trim())}}}},8000)}
  try{const ac=new AbortController();setTimeout(()=>ac.abort(),15000);const j=await (await fetch('api/suggest?q='+encodeURIComponent(v),{signal:ac.signal})).json();if(n===seq){clearTimeout(tmo);items=j.items||[];sel=0;if(items.length)draw();else msg('无匹配结果')}}catch(e){}return items}
 q.addEventListener('input',()=>f(q.value.trim()));
 q.addEventListener('keydown',async e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(items.length){sel=(sel+(e.key==='ArrowDown'?1:items.length-1))%items.length;draw()}}else if(e.key==='Enter'){e.preventDefault();const v=q.value.trim();if(!v)return;const C=window.CSUG;if(items.length&&items[sel]&&d.style.display==='block'&&items[sel].code){go(items[sel]);return}if(C&&C.codeLike(v)){const U=v.toUpperCase();go({code:U,market:/^\d{6}$/.test(U)?'a':'us'});return}await f(v);go(items[sel]||items[0])}else if(e.key==='Escape'){items=[];draw();q.blur()}});
 d.addEventListener('mousedown',e=>{const t=e.target.closest('[data-i]');if(t){e.preventDefault();go(items[+t.dataset.i])}});
 q.addEventListener('blur',()=>setTimeout(()=>{d.style.display='none'},150));q.addEventListener('focus',()=>{if(items.length)draw()});
 w.querySelector('.ic').onclick=()=>{w.classList.add('open');q.focus()};
 w.querySelector('.x').onclick=()=>{w.classList.remove('open');q.value='';items=[];draw()};
 addEventListener('resize',()=>{if(d.style.display==='block')pos()});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

(function(){const st=document.createElement('style');st.textContent='.nu{display:none!important}';document.head.appendChild(st)})();
