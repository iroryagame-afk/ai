const WL_UI=false; // 自选相关 UI 开关：未登录实测完成前隐藏（代码保留）
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
const LS=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v??d}catch(e){return d}},SS=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const PN={day:'日线','30m':'30分','5m':'5分'};
const st={market:localStorage.cw_market||'a',code:localStorage.cw_code||'600519',period:(['day','30m','5m'].includes(LS('cw_period','day'))?LS('cw_period','day'):'day')};
if(!Object.keys(PN).includes(st.period))st.period='day';
const IND_DEF={VOL:{},MACD:{fast:12,slow:26,signal:9},KDJ:{n:9,k:3,d:3},RSI:{p1:6,p2:12,p3:24},BOLL:{n:20,k:2},MA:{p1:5,p2:10,p3:20,p4:60}};
const IND_LBL={fast:'快线',slow:'慢线',signal:'信号线',n:'周期',k:'K 平滑 / 倍数',d:'D 平滑',p1:'周期1',p2:'周期2',p3:'周期3',p4:'周期4'};
let indOn=LS('cw_ind',{VOL:false,MACD:true,KDJ:true,RSI:false,BOLL:false,MA:false}),indCfg=Object.assign(JSON.parse(JSON.stringify(IND_DEF)),LS('cw_indcfg',{}));
if(!LS('cw_fit_ready',false)){Object.assign(indOn,{VOL:false,MACD:true,KDJ:true,RSI:false});SS('cw_ind',indOn);SS('cw_fit_ready',true)}
let chanOn=LS('cw_chan2',{bi:true,seg:true,trend:true}),opt=LS('cw_opt',{bsp:true,bc:true,zs:true,lv:true,cross:true,slider:true});
let me=null,acct=[],quotes={},lastJ=null,A=null,leftMkt=st.market,leftGrp=LS('cw_lgrp','全部'),rtab='op',alerts=[];
const chartHost=$('#chart');
const chart=echarts.init(chartHost);
const heightSelect=document.createElement('select');
heightSelect.id='chart-height';
heightSelect.setAttribute('aria-label','图表高度');
heightSelect.innerHTML='<option value="fit">同屏显示</option><option value="1080">放大 · 整页滚动</option><option value="1320">更大 · 整页滚动</option>';
$('#inds').after(heightSelect);
heightSelect.addEventListener('change',()=>{
 document.body.classList.toggle('chart-expanded',heightSelect.value!=='fit');
 document.body.style.setProperty('--expanded-chart-height',heightSelect.value==='fit'?'1080px':heightSelect.value+'px');
 chart.resize();
 if(lastJ&&A)draw(true);
});
const chartResize=new ResizeObserver(()=>{
 if(chartHost.clientWidth&&chartHost.clientHeight&&
    (chart.getWidth()!==chartHost.clientWidth||chart.getHeight()!==chartHost.clientHeight)){
     chart.resize();
     if(lastJ&&A)draw(true);
    }
});
chartResize.observe(chartHost);
let _plT=0;const _pl=()=>{clearTimeout(_plT);_plT=setTimeout(()=>placeLv(),60)};chart.on('finished',()=>{if(!window._plBusy){window._plBusy=1;_pl();setTimeout(()=>window._plBusy=0,200)}});chart.on('datazoom',_pl);
const isMob=()=>innerWidth<820;
function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',5000)}
async function api(path,o={}){const r=await fetch(path,{credentials:'same-origin',...o,headers:{'Content-Type':'application/json',...(o.headers||{})}});let j={};try{j=await r.json()}catch(e){}if(!r.ok)throw new Error(typeof j.detail==='string'?j.detail:(j.detail?JSON.stringify(j.detail):r.status));return j}
$$('[data-close]').forEach(b=>b.onclick=()=>b.closest('.modal').classList.remove('show'));
$$('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')}));
const key=()=>st.market+':'+st.code.toUpperCase();
// ---------- 指标计算 ----------
const SMA=(a,n)=>a.map((_,i)=>{if(i<n-1)return null;let s=0;for(let j=i-n+1;j<=i;j++)s+=a[j];return s/n});
const EMA=(a,n)=>{const k=2/(n+1),o=[];a.forEach((v,i)=>o.push(i?o[i-1]+k*(v-o[i-1]):v));return o};
const r3=v=>v==null||isNaN(v)?null:+v.toFixed(3);
function calcInd(K){const C=K.map(k=>k[2]),H=K.map(k=>k[4]),L=K.map(k=>k[3]),o={};
 const m=indCfg.MACD,ef=EMA(C,m.fast),es=EMA(C,m.slow),dif=C.map((_,i)=>ef[i]-es[i]),dea=EMA(dif,m.signal);o.MACD={dif:dif.map(r3),dea:dea.map(r3),hist:dif.map((v,i)=>r3(2*(v-dea[i])))};
 const kd=indCfg.KDJ;let kk=50,dd=50;const KK=[],DD=[],JJ=[];C.forEach((c,i)=>{const s=Math.max(0,i-kd.n+1),hh=Math.max(...H.slice(s,i+1)),ll=Math.min(...L.slice(s,i+1));const rsv=hh===ll?50:(c-ll)/(hh-ll)*100;kk=((kd.k-1)*kk+rsv)/kd.k;dd=((kd.d-1)*dd+kk)/kd.d;KK.push(r3(kk));DD.push(r3(dd));JJ.push(r3(3*kk-2*dd))});o.KDJ={K:KK,D:DD,J:JJ};
 const rsi=n=>{let g=0,l=0;return C.map((c,i)=>{if(!i)return null;const d=c-C[i-1];g=(g*(n-1)+Math.max(d,0))/n;l=(l*(n-1)+Math.max(-d,0))/n;return i<n?null:r3(l===0?100:100-100/(1+g/l))})};
 o.RSI={};['p1','p2','p3'].forEach(p=>o.RSI['RSI'+indCfg.RSI[p]]=rsi(+indCfg.RSI[p]));
 const b=indCfg.BOLL,mid=SMA(C,b.n);o.BOLL={mid:mid.map(r3),up:mid.map((v,i)=>{if(v==null)return null;let s=0;for(let j=i-b.n+1;j<=i;j++)s+=(C[j]-v)**2;return r3(v+b.k*Math.sqrt(s/b.n))}),dn:[]};o.BOLL.dn=mid.map((v,i)=>v==null?null:r3(2*v-o.BOLL.up[i]));
 o.MA={};['p1','p2','p3','p4'].forEach(p=>o.MA['MA'+indCfg.MA[p]]=SMA(C,+indCfg.MA[p]).map(r3));return o}
// ---------- 规则分析（本地生成，不调模型） ----------
const fp=(v,c)=>{if(v==null||v===''||isNaN(+v))return v??'—';const d=/^(5|15|16|18)/.test(String(c||''))||Math.abs(+v)<1?3:2;return (+v).toFixed(d)};
const bspCN=(t,buy)=>{const M={'1':'一','1p':'盘背一','2':'二','2s':'类二','3a':'三','3b':'三','3':'三'};const o=[];String(t).split(',').forEach(x=>{x=x.trim();const w='笔'+(M[x]||x)+(buy?'买':'卖');if(!o.includes(w))o.push(w)});return o.join('、')};
function analyze(j){j.bi=j.bi||[];j.seg=j.seg||[];j.zs=j.zs||[];j.bsp=j.bsp||[];j.volume=j.volume||(j.kline||[]).map(()=>0);const s=j.analysis||{},K=j.kline||[],n=K.length,pos=+LS('cw_pos',{})[key()]||0,ind=calcInd(K);
 const act=pos?(s.act_hold||'加载中'):(s.act_flat||'加载中'),why=pos?(s.why_hold||''):(s.why_flat||'');
 const cls=/买入|试仓/.test(act)?'':/持有|落袋/.test(act)?'hold':/止损|减仓|回避|止盈|放弃/.test(act)?'out':'wait';
 const gates=(s.gates&&!Array.isArray(s.gates))?s.gates:null;
 return {C:s.price,n,T:K.map(k=>k[0]),pos,lb:s.last_bsp,lastBuy:s.last_buy,zs:s.zs,lbi:j.bi.length?j.bi[j.bi.length-1]:null,bc:s.bc||[],macdBc:s.macd_bc||[],
  entry:s.entry,target:s.target,stop:s.stop,where:s.where,segDir:s.seg_dir,biDir:s.bi_dir,trend:s.trend,age:s.signal_age,act,cls,why,
  main:s.main_sig||s.signal,lastsig:s.last_sig,cand:s.cand_sig,tags:s.tags||[],note:s.level_note||[],mom:s.momentum,mc:s.macd,ma20:s.ma20,ind,rr:s.rr,view:s.view,reasons:s.reasons,gates,gn:s.gate_note,ck:s.cand_kind||'',csig:s.cand_sig||'',scat:s.cat,rsrc:s.reso_src,pc:s.pre_cat,inv:!!s.invalid||!!(s.last_bsp&&s.last_bsp.buy&&s.stop!=null&&s.price<s.stop)}}
// ---------- 右侧面板 ----------
const QS=['现在能买吗？','止损放哪里？','目标看多少？','中枢在哪？','趋势怎么样？','最近有背驰吗？','持仓怎么办？'];
function answer(q){if(!A)return'数据还没加载好';const a=A,j=lastJ,nm=`${j.name}（${j.code}）`;
 if(/买|进|上车|入/.test(q)&&a.inv)return`不能买：最近买点已破位失效（${a.why}），等待新的日线买点。`;
 if(/买|进|上车|入/.test(q))return a.pos===1?`你标记为持仓。${a.act}：${a.why}。`:`${PN[j.period]}级别建议「${a.act}」。${a.why}。参考上车位 ${a.entry??'—'}，结构失效 ${a.stop}，落袋 ${a.target}${a.rr?`，盈亏比约 ${a.rr}`:''}。`;
 if(/止损|失效|跌破|防守/.test(q))return`结构失效位 ${a.stop}：取最近中枢/买点/笔低点里离现价最近的支撑${a.lastBuy?`，并不低于买点后的最低价`:''}。收盘跌破就视为本级别结构破坏。`;
 if(/目标|落袋|止盈|看多少|压力/.test(q))return`落袋位 ${a.target}：上方最近的阻力（中枢上沿 / 前笔高点 / 近 60 日高点）。到位附近可分批落袋。`;
 if(/中枢/.test(q))return a.zs?`最近中枢 ${a.zs.low}–${a.zs.high}（${A.T[a.zs.x0]} 至 ${A.T[a.zs.x1]}，${a.zs.sure?'已确认':'未确认'}），现价处在${a.where}。共识别 ${j.zs.length} 个中枢。`:'当前数据里没识别到中枢。';
 if(/趋势|走势|方向/.test(q))return`走势：${a.trend}（按最近两个中枢的位置关系判断）。最后线段${a.segDir}，当前笔${a.biDir}，${a.mc}，现价${a.C>(a.ma20||0)?'在':'在'} MA20（${a.ma20}）${a.C>(a.ma20||0)?'上方':'下方'}。`;
 if(/背驰|背离/.test(q)){const b=a.bc.slice(-3).map(x=>`${A.T[x.x]} ${x.t}（${x.buy?'底':'顶'}，${x.y}）`);return(b.length?'最近的背驰点：\n'+b.join('\n'):'近期没有一类买卖点形成的笔背驰。')+(a.macdBc?`\n另外 MACD 面积比较：${a.macdBc}。`:'')}
 if(/持仓|拿|卖|走/.test(q))return`按持仓看：${a.pos===1?a.act:'（你当前标记为空仓，切到「持仓」可看持仓建议）'}。跌破 ${a.stop} 离场，接近 ${a.target} 分批止盈。`;
 return`没听懂这个问题。可以问：${QS.join(' / ')}。（缠问由本地规则回答，不调用大模型）`}
function renderRight(){const b=$('#rbody');if(!A||!lastJ){b.innerHTML='<div class="empty">加载中…</div>';return}const a=A,j=lastJ;
 $$('#rtabs button').forEach(x=>x.classList.toggle('on',x.dataset.t===rtab));
 if(rtab==='op'){b.innerHTML=`<div class="kv"><span>当前周期操作建议</span><span class="pill">操作级别 · ${PN[j.period]}</span></div>
  <div class="big ${a.cls}">${a.act}</div><div style="color:#6a6152">${esc(a.why)}</div>
  ${(()=>{const d=j.day_analysis;if(!d)return'';const dact=a.pos?d.act_hold:d.act_flat;
   const R=j.reso,ri=R&&R.item,TF={day:'日','30m':'30分'};const rs=ri?`<div class="kv"><span>共振（${+R.for_date.slice(5,7)}月${+R.for_date.slice(8,10)}日开盘参考·基于${+R.session.slice(5,7)}月${+R.session.slice(8,10)}日收盘）</span><span>${['day','30m'].map(p=>{const v=ri.tf&&ri.tf[p];return v?`${TF[p]}${v.dir>0?'↑':v.dir<0?'↓':'·'}${v.dir&&v.dir===ri.dir?'✓':''}`:TF[p]+'–'}).join(' ')} ${ri.reso>=2&&ri.dir>0&&a.inv?'<b style="color:#a9a092">共振买点已破位失效</b>':ri.reso>=2?(ri.dir>0?'<b style="color:#c0392b">共振买点</b>':'<b style="color:#1f8a52">共振卖点</b>'):'未共振'}</span></div><div style="color:#9a907f;font-size:11px">盘中不改</div>`:'';
   return `<div class="sec" style="margin-top:8px;padding-top:6px">${rs}<div class="kv"><span>日线观点</span><span><b>${d.view}</b> · ${esc(dact)}</span></div>
   ${j.period!=='day'?`<div class="kv"><span>${PN[j.period]}操作</span><span><b>${esc(a.act)}</b>（${a.view}）</span></div>${(a.act!==dact||a.view!==d.view)?`<div style="color:#c0661a;font-size:12px">当前周期（${PN[j.period]}）结论与日线不同：短线看 ${PN[j.period]}，首页与「总结·日」按日线。</div>`:''}`:'<div style="color:#9a907f;font-size:12px">与首页、「总结·日」同源同文。</div>'}</div>`})()}
${(()=>{const R=(j.day_analysis&&j.day_analysis.review)||[];const tm=j.day_analysis&&j.day_analysis.review_time;const inv=a.inv||(j.day_analysis&&j.day_analysis.invalid);const hasBr=R.some(t=>/破位|放弃/.test(t));if(R.length&&hasBr)return`<div style="margin:8px 0;padding:6px 8px;border-radius:8px;background:#fff1e6;border:1px solid #f0c9a8;color:#c0661a;font-weight:600">${R.map(esc).join('；')}<div style="font-weight:400;font-size:11px;color:#9a907f">开盘复核 ${esc(tm||'')}（北京时间）· 与首页一致</div></div>`;if(inv)return`<div style="margin:8px 0;padding:6px 8px;border-radius:8px;background:#fff1e6;border:1px solid #f0c9a8;color:#c0661a;font-weight:600">开盘复核未见破位；之后现价跌破失效位（放弃）<div style="font-weight:400;font-size:11px;color:#9a907f">开盘复核 ${esc(tm||'')}（北京时间）· 与首页一致</div></div>`;return tm?`<div style="margin:6px 0;color:#9a907f;font-size:12px">开盘复核 ${esc(tm)}：未见破位 / 远离</div>`:''})()}
${(()=>{const I=(j.day_analysis&&j.day_analysis.intraday)||(j.analysis&&j.analysis.intraday);if(!I||!I.bg)return'';const asof=I.closed||!j.trading?`收盘 ${I.date||((I.asof||"").slice(0,10))}`:(I.asof||"").slice(5);return `<div style="margin:8px 0;padding:7px 9px;border-radius:8px;background:#faf6ee;border:1px solid #efe4d0;font-size:12.5px;color:#5a5244"><div style="display:flex;gap:16px;flex-wrap:wrap"><span><b style="color:#8a5a12">日内背景</b> ${esc(I.bg)}</span><span><b style="color:#8a5a12">15分量价</b> ${esc(I.vp15||"—")}</span></div><div style="font-size:11px;color:#9a907f;margin-top:3px">参考，不影响结论 · ${esc(asof)}${I.bg_note?" · "+esc(I.bg_note):""}</div></div>`})()}
  <div class="kv" style="margin-top:10px"><span>主信号（决定结论）</span><span>${esc(a.main)}</span></div>
  <div class="kv"><span>最近已确认信号</span><span>${esc(a.lastsig||'—')}</span></div>${a.cand?`<div class="kv"><span>候选（未确认）</span><span style="color:#a9a092">${esc(a.cand)}</span></div>`:''}
  <div class="kv"><span>持仓状态</span><span>${a.pos?'持仓':'空仓'}</span></div>
  <div class="kv"><span>上车位</span><span style="color:#d08a1a">${fp(a.entry,j.code)}</span></div>
  <div class="kv"><span>落袋位</span><span style="color:#1f9a5c">${fp(a.target,j.code)}</span></div>
  <div class="kv"><span>结构失效</span><span style="color:#d6403a">${fp(a.stop,j.code)}</span></div>
  ${a.note.length?`<div style="color:#c0661a;font-size:12px">${a.note.map(esc).join('；')}（附近没有可用的近期结构）</div>`:''}
  <div class="kv"><span>MACD 动能</span><span>${esc(a.mom||a.mc)}</span></div>
  ${(a.gates&&!Array.isArray(a.gates))?(()=>{const d=(['bear','caution'].includes(a.pc)||a.view==='看空'||a.view==='谨慎')?'bear':'bull';const g=a.gates[d];if(!g||typeof g!=='object')return'';return `<div style="margin:4px 0;font-size:12px"><b>形态+动能（${a.inv&&d==='bull'?'买点已破位失效':!Object.values(g).every(v=>v.length)?'不满足 · 观望':d==='bull'?'看多':'看空'}）</b>`+Object.entries(g).map(([k,v])=>`<div>${v.length?'✓':'✗'} ${k}：${esc((v.join('、')||'不满足').replace(a.inv?/现价未破该买点/g:/$^/,'现价已跌破该买点（已失效）'))}</div>`).join('')+(a.gn?`<div style="color:#b5651d">${esc(a.gn)}</div>`:'')+(a.rsrc?`<div style="color:#9a907f">共振来源：${esc(a.rsrc)}</div>`:'')+`</div>`})():''}
  <div class="kv"><span>盈亏比</span><span>${a.rr??'—'}</span></div>
  <div class="kv"><span>更新时间</span><span>${new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Shanghai'})} ${j.updated}${j.stale?' <b style="color:#c0661a">旧缓存</b>':''}</span></div>
  <div class="sec"><h5>当前 TAG <small style="font-weight:400;color:#9a907f;float:right">${PN[j.period]}背景</small></h5>${(a.inv?a.tags.filter(t=>!["上涨趋势","线段向上","当前笔向上","站上 MA20"].includes(t)):a.tags).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div>
  <div class="sec" hidden><h5>我的提醒</h5>${alerts.length?alerts.map(x=>`<div class="kv"><span>${x.dyn?({stop:'跌破失效位 ',entry:'到达上车位 ',target:'到达落袋位 ',bsp:'新买卖点',concl:'结论变化'}[x.kind]+(x.level??'')):x.kind==='bsp'?'新买卖点':(x.kind==='above'?'上穿 ':'跌破 ')+x.price}</span><span>${x.triggered&&!x.dyn?'<b style="color:#c0661a">已触发</b>':'监控中'}</span></div>`).join(''):'<span style="color:#9a907f">无（点顶栏「加提醒」）</span>'}</div>`}
 else if(rtab==='ask'){b.innerHTML=`<div style="color:#8a8072">按当前图表的缠论结构用本地规则回答（不调用大模型）。</div><div class="qa">${QS.map(q=>`<button class="tg" data-q="${q}">${q}</button>`).join('')}</div>
  <div id="answers">${(window._ans||[]).map(x=>`<div><b>问：</b>${esc(x[0])}</div><div class="ans">${esc(x[1])}</div>`).join('')}</div>
  <div class="ask"><input id="askq" placeholder="输入问题，如：止损放哪"><button class="ib pri" id="askgo">问</button></div>`;
  const ask=q=>{if(!q)return;(window._ans=window._ans||[]).push([q,answer(q)]);if(_ans.length>8)_ans.shift();renderRight()};
  b.querySelectorAll('[data-q]').forEach(x=>x.onclick=()=>ask(x.dataset.q));$('#askgo').onclick=()=>ask($('#askq').value.trim());$('#askq').onkeydown=e=>{if(e.key==='Enter')$('#askgo').click()}}
 else if(rtab==='sum'){renderSum(b)}
 else{const z=a.zs,last5=j.bsp.slice(-5).reverse();
  b.innerHTML=`<p><b>${esc(j.name)}（${j.code}）· ${PN[j.period]}</b>　收盘 ${a.C}${j.quote?`，日涨跌 ${j.quote.pct>0?'+':''}${j.quote.pct}%`:''}。</p>
  <p><b>结构：</b>共 ${j.bi.length} 笔、${j.seg.length} 段、${j.zs.length} 个中枢。走势判定为<b>${a.trend}</b>；最后一段${a.segDir}，当前笔${a.biDir}${a.lbi&&!a.lbi.sure?'（未完成）':''}。</p>
  <p><b>中枢：</b>${z?`最近中枢 ${z.low}–${z.high}，现价位于${a.where}。${a.where==='中枢上方'?'离开中枢向上，若回抽不进中枢可能形成三买。':a.where==='中枢下方'?'离开中枢向下，若反抽不回中枢可能形成三卖。':a.where==='中枢内'?'在中枢内来回，方向未选择，按区间对待。':''}`:'暂无中枢。'}</p>
  ${a.inv?'<p style="color:#c0661a"><b>复核：</b>最近买点已破位失效，原买点作废，不再看多。</p>':''}<p><b>买卖点：</b>${last5.length?last5.map(p=>`${A.T[p.x].slice(0,16)} ${bspCN(p.type,p.buy)}（${p.y}）`).join('；'):'暂无'}。</p>
  <p><b>背驰：</b>${a.bc.length?`最近一次 ${A.T[a.bc[a.bc.length-1].x].slice(0,16)} ${a.bc[a.bc.length-1].t}。`:'近期无一类点背驰。'}${a.macdBc?` MACD 面积：${a.macdBc}。`:''}</p>
  <p><b>指标：</b>${a.mc}；MA20 ${a.ma20}，现价在其${a.C>a.ma20?'上方':'下方'}；KDJ K=${a.ind.KDJ.K[a.n-1]} D=${a.ind.KDJ.D[a.n-1]}；RSI${indCfg.RSI.p1}=${a.ind.RSI['RSI'+indCfg.RSI.p1][a.n-1]}。</p>
  <p><b>计划：</b>${a.pos?'持仓':'空仓'}视角「${a.act}」。上车 ${a.entry??'—'} / 落袋 ${a.target} / 结构失效 ${a.stop}。</p>
  <p style="color:#9a907f;font-size:12px">以上为本地规则根据 chan.py 结构自动生成，仅供参考。</p>`}}
let SUMC={};
async function renderSum(b){const k=key();b.innerHTML='<div class="empty">日线总结计算中…</div>';
 try{const s=SUMC[k]&&Date.now()-SUMC[k].t<60000?SUMC[k].d:(await api(`api/summary?market=${st.market}&code=${encodeURIComponent(st.code)}`));SUMC[k]={t:Date.now(),d:s};if(rtab!=='sum'||k!==key())return;
  const c=s.view==='看多'?'':s.view==='看空'?'out':'wait';
  b.innerHTML=`<div class="kv"><span>日线总结</span><span class="pill">${s.buy_now&&!/ST/i.test(s.name||'')?'推荐买入':'依据 · 日线'}</span></div>
  <div class="big ${s.invalid?'out':c}">${s.invalid?esc(s.act_flat||'放弃'):s.view}</div>${/ST/i.test(s.name||'')?'<div style="color:#8a8072;font-size:12px">ST 股：不列入首页推荐买入</div>':''}<div style="color:#9a907f">主信号 ${esc(s.main_sig||s.signal)}　最近已确认 ${esc(s.last_sig||'—')}</div>
  ${s.next_step?`<div style="margin-top:6px;color:#b0650f">${esc(s.next_step)}</div>`:''}${s.sell_basis?`<div style="color:#8a8072;font-size:12px">${esc(s.sell_basis)}</div>`:''}${(s.review||[]).length?`<div style="margin-top:6px;color:#c0661a;font-weight:600">${s.review.map(esc).join('；')}</div>`:''}${s.intraday&&s.intraday.bg?`<div style="margin-top:6px;padding:6px 8px;background:#faf6ee;border-radius:8px;font-size:12.5px"><b style="color:#8a5a12">日内背景</b> ${esc(s.intraday.bg)}　<b style="color:#8a5a12">15分量价</b> ${esc(s.intraday.vp15||"—")}<div style="color:#9a907f;font-size:11px">参考，不影响结论</div></div>`:''}<div class="sec"><h5>理由</h5><ol style="margin:0;padding-left:18px">${s.reasons.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></div>
  <div class="sec"><h5>关键价位</h5><div class="kv"><span>现价（${s.date}）</span><span>${s.price}</span></div><div class="kv"><span>上车位</span><span style="color:#d08a1a">${s.entry??'—'}</span></div>
  <div class="kv"><span>落袋位</span><span style="color:#1f9a5c">${s.target??'—'}</span></div><div class="kv"><span>结构失效</span><span style="color:#d6403a">${s.stop??'—'}</span></div>
  <div class="kv"><span>更新时间</span><span>${s.updated}（北京时间）${s.stale?' · 旧缓存':''}</span></div>${(s.level_note||[]).length?`<div style="color:#c0661a;font-size:12px">${s.level_note.map(esc).join('；')}</div>`:''}</div>
  <div class="sec" style="color:#9a907f;font-size:12px">${esc(s.rules)}</div>`}catch(e){b.innerHTML='<div class="empty">总结失败：'+esc(e.message)+'</div>'}}
$('#rtabs').onclick=e=>{const t=e.target.dataset.t;if(t){rtab=t;renderRight()}};
// ---------- 画图 ----------
function draw(keep){const j=lastJ,K=j.kline,T=K.map(k=>k[0]),a=A,mob=isMob(),ind=a.ind;
 const subs=['VOL','MACD','KDJ','RSI'].filter(x=>indOn[x]&&(x!=='VOL'||j.volume.length));
 const H=chartHost.clientHeight||500,expanded=document.body.classList.contains('chart-expanded');
 const gap=expanded?22:12,bottom=mob?36:32;
 const subH=expanded?Math.min(205,Math.round(H*.15)):Math.max(48,Math.min(130,Math.round(H*.23),Math.floor((H-205)/Math.max(1,subs.length))-gap));
 const mainBottom=bottom+subs.length*(subH+gap)+ (opt.slider?28:0);
 const LVW=opt.lv?(mob?86:112):0;const grids=[{left:mob?8:14,right:(mob?52:62)+LVW,top:16,bottom:mainBottom,containLabel:false}];
 subs.forEach((s,i)=>grids.push({left:grids[0].left,right:grids[0].right,height:subH-6,bottom:bottom+(opt.slider?28:0)+(subs.length-1-i)*(subH+gap)}));
 const xA=grids.map((g,i)=>({type:'category',data:T,gridIndex:i,boundaryGap:true,axisLine:{lineStyle:{color:'#d9cfbd'}},axisLabel:{show:i===grids.length-1,color:'#8a8072',fontSize:10,formatter:v=>/m$/.test(j.period)?String(v).slice(5,16):v},axisTick:{show:false},axisPointer:{label:{show:i===grids.length-1}}}));
 const yA=grids.map((g,i)=>({scale:true,...(i?{}:{min:v=>+(v.min-(v.max-v.min)*.28).toPrecision(3),max:v=>+(v.max+(v.max-v.min)*.38).toPrecision(3),axisLabel:{color:'#8a8072',fontSize:10,showMinLabel:false,showMaxLabel:false}}),gridIndex:i,position:'right',offset:0,axisLabel:{color:'#8a8072',fontSize:10,inside:false},splitNumber:i?2:6,splitLine:{show:!i,lineStyle:{color:'#efe7d8'}},axisLabel:{color:'#8a8072',fontSize:10,showMinLabel:!!i,showMaxLabel:!!i}}));
 const S=[{type:'candlestick',name:'K线',data:K.map(k=>[k[1],k[2],k[3],k[4]]),itemStyle:{color:'#e0524b',color0:'#22a565',borderColor:'#e0524b',borderColor0:'#22a565'}}];
 const lines=(arr,color,w,name,z)=>({type:'lines',name,coordinateSystem:'cartesian2d',z,silent:true,data:arr.map(b=>({coords:[[T[b.x0],b.y0],[T[b.x1],b.y1]],lineStyle:{type:b.sure?'solid':'dashed'}})),lineStyle:{color,width:w}});
 if(chanOn.bi)S.push(lines(j.bi,'#3b8fd8',1.3,'笔',5));
 if(chanOn.seg)S.push(lines(j.seg,'#c0392b',2.4,'线段',6));
 const zsSeries=(arr,name,fill,stroke,w,z)=>({type:'custom',name,z,silent:true,clip:true,renderItem:(p,api)=>{const s=api.coord([api.value(0),api.value(3)]),e=api.coord([api.value(1),api.value(2)]);
  return{type:'rect',shape:{x:s[0],y:s[1],width:Math.max(1,e[0]-s[0]),height:e[1]-s[1]},style:{fill,stroke,lineWidth:w,lineDash:api.value(4)?null:[4,3]}}},data:arr.map(z=>[z.x0,z.x1,z.low,z.high,z.sure?1:0]),encode:{x:[0,1],y:[2,3]}});
 if(chanOn.trend&&opt.zs){S.push(zsSeries(j.zs,'笔中枢','rgba(80,170,230,.13)','#7cc0ea',1,3));if(j.segzs&&j.segzs.length)S.push(zsSeries(j.segzs,'段中枢','rgba(230,150,40,.06)','#e39a3a',1.6,2))}
 const short=t=>t.replace(/笔/g,'').replace('盘背一','盘背1').replace('类二','类2').replace(/一/g,'1').replace(/二/g,'2').replace(/三/g,'3');
 const PT={};j.bsp.forEach(p=>{const k=p.x+(p.buy?'b':'s');(PT[k]=PT[k]||{x:p.x,y:p.y,buy:p.buy,t:[],bc:null}).t.push(bspCN(p.type,p.buy))});
 if(opt.bc)a.bc.forEach(b=>{const k=b.x+(b.buy?'b':'s');(PT[k]=PT[k]||{x:b.x,y:b.y,buy:b.buy,t:[],bc:null}).bc=b.t});
 const pts=Object.values(PT).filter(p=>opt.bsp||p.bc);
 if(pts.length)S.push({type:'scatter',name:'买卖点',z:10,symbol:'arrow',symbolSize:mob?8:10,
  tooltip:{trigger:'item',formatter:p=>{const d=pts[p.dataIndex];return `${T[d.x]}<br>${[...(opt.bsp?d.t:[]),d.bc].filter(Boolean).join('、')}<br>价格 ${d.y}`}},
  data:pts.map(p=>{const full=[...(opt.bsp?p.t:[]),p.bc].filter(Boolean).join('、'),sh=[...(opt.bsp?p.t.map(short):[]),p.bc?'背驰':''].filter(Boolean).join('·');
   const cur=a.lb&&p.x===a.lb.x&&p.buy===a.lb.buy,dt=String(T[p.x]).slice(5,/m$/.test(j.period)?16:10);
   const cand=cur&&!a.inv&&(!!a.ck||/未完成|无背驰/.test(a.gn||'')),dead=cur&&p.buy&&a.inv,col=(dead||cand)?'#a9a092':cur?(p.buy?'#e0524b':'#1f9a5c'):'#c9bfae';
   const sh2=(cand&&(a.ck==='nodiv'||/无背驰/.test(a.csig+a.gn)))?sh.replace(/·?背驰/g,'').replace(/^·/,''):sh;
   return {value:[T[p.x],p.y],symbolRotate:p.buy?0:180,symbolOffset:[0,p.buy?9:-9],symbolSize:cur?(mob?11:13):(mob?7:8),z:cur?12:9,itemStyle:{color:cur?col:(p.bc&&!(opt.bsp&&p.t.length)?'#e3c88c':col),opacity:cur?1:.55},
    label:{show:true,formatter:cur?(dead?`${sh}\n${dt} · 已破位失效`:(cand?`${sh2}\n${dt} 候选·未确认`:`${sh}\n${dt} 当前生效`)):sh,position:p.buy?'bottom':'top',distance:cur?(mob?16:20):(mob?11:14),align:'center',lineHeight:cur?14:12,color:cur?'#fff':'#b0a693',fontSize:cur?11.5:9.5,fontWeight:cur?'bold':'normal',backgroundColor:cur?col:'rgba(255,253,248,.6)',padding:cur?[2,5]:[0,2],borderRadius:3},
    emphasis:{label:{formatter:full,fontSize:12}}}}),
  labelLayout:{hideOverlap:true,moveOverlap:'shiftY'}});if(pts.length)S.push({type:'scatter',name:'引线',z:8,silent:true,tooltip:{show:false},data:pts.map(p=>{const cur=a.lb&&p.x===a.lb.x&&p.buy===a.lb.buy,d=cur?(mob?16:20):(mob?11:14);return{value:[T[p.x],p.y],symbol:'rect',symbolSize:[1,d],symbolOffset:[0,p.buy?d/2+6:-(d/2+6)],itemStyle:{color:cur?'#8f8577':'#cfc5b4',opacity:.8}}})});
 if(indOn.MA)Object.entries(ind.MA).forEach(([n,v],i)=>S.push({type:'line',name:n,data:v,showSymbol:false,smooth:true,lineStyle:{width:1,color:['#e3a42c','#9b59b6','#3b8fd8','#e67e22'][i]},z:4}));
 if(indOn.BOLL)[['mid','#c48a2c'],['up','#9b59b6'],['dn','#9b59b6']].forEach(([k,c])=>S.push({type:'line',name:'BOLL'+k,data:ind.BOLL[k],showSymbol:false,lineStyle:{width:1,color:c,type:k==='mid'?'solid':'dashed'},z:4}));
 if(opt.lv){const ml=[];const L=(y,c,t)=>y!=null&&ml.push({yAxis:y,lineStyle:{color:c,type:'dashed',width:1},label:{show:true,position:'end',distance:(mob?46:56),formatter:`${t} ${fp(y,j.code)}`,color:'#fff',backgroundColor:c,padding:[2,4],borderRadius:3,fontSize:mob?10:11}});
  if(!NS()){L(a.target,'#22a565','落袋');if(a.stop!=null&&a.entry!=null&&Math.abs(a.stop-a.entry)<1e-9)L(a.entry,'#e0524b','上车/失效');else{L(a.entry,'#e3a42c','上车');L(a.stop,'#e0524b','失效')}}ml.push({yAxis:a.C,lineStyle:{color:'#999',type:'dotted'},label:{show:true,position:'end',distance:(mob?46:56),formatter:'现价 '+a.C,color:'#fff',backgroundColor:'#7a7062',padding:[2,4],borderRadius:3,fontSize:11}});
  S[0].markLine={symbol:'none',silent:true,data:ml};window._ml=ml}else window._ml=null;
 subs.forEach((s,i)=>{const gi=i+1,base={xAxisIndex:gi,yAxisIndex:gi,showSymbol:false};
  if(s==='VOL')S.push({...base,type:'bar',name:'VOL',data:j.volume.map((v,k)=>({value:v,itemStyle:{color:K[k][2]>=K[k][1]?'#e8908b':'#7fcca3'}}))});
  if(s==='MACD'){S.push({...base,type:'bar',name:'MACD',data:ind.MACD.hist.map(v=>({value:v,itemStyle:{color:v>=0?'#e0524b':'#22a565'}}))});S.push({...base,type:'line',name:'DIF',data:ind.MACD.dif,lineStyle:{width:1,color:'#e3a42c'}});S.push({...base,type:'line',name:'DEA',data:ind.MACD.dea,lineStyle:{width:1,color:'#3b8fd8'}})}
  if(s==='KDJ')[['K','#e3a42c'],['D','#3b8fd8'],['J','#9b59b6']].forEach(([k,c])=>S.push({...base,type:'line',name:k,data:ind.KDJ[k],lineStyle:{width:1,color:c}}));
  if(s==='RSI')Object.entries(ind.RSI).forEach(([k,v],x)=>S.push({...base,type:'line',name:k,data:v,lineStyle:{width:1,color:['#e3a42c','#3b8fd8','#9b59b6'][x]}}));
  grids[gi]._t=s});
 // 默认视图：最近一个走势（最近中枢 / 最近一段起点 → 最新）；不足时至少最近一笔并留少量前置K线
 const zl=j.zs[j.zs.length-1],sl=j.seg[j.seg.length-1],bl=j.bi[j.bi.length-1];
 let st0=Math.min(...[zl&&zl.x0>=K.length-600?zl.x0:null,sl?Math.min(sl.x0,sl.x1):null,bl?Math.min(bl.x0,bl.x1):null,K.length-80].filter(v=>v!=null));
 if(bl)st0=Math.min(st0,Math.min(bl.x0,bl.x1));
 let sv=Math.max(0,Math.min(st0-8,K.length-60)),ev=K.length-1;const NBARS0=NBARS;DEFV=[sv,ev];NBARS=K.length;
 if(keep&&NBARS0===K.length){const c=curV();sv=c[0];ev=c[1]}
 const xi=grids.map((_,i)=>i);
 chart.setOption({backgroundColor:'#fffdf8',animation:false,grid:grids,xAxis:xA,yAxis:yA,axisPointer:{link:[{xAxisIndex:'all'}]},
  title:subs.map((s,i)=>({text:s==='MACD'?`MACD(${indCfg.MACD.fast},${indCfg.MACD.slow},${indCfg.MACD.signal})`:s==='KDJ'?`KDJ(${indCfg.KDJ.n},${indCfg.KDJ.k},${indCfg.KDJ.d})`:s==='RSI'?'RSI':'VOL',left:grids[0].left+4,bottom:grids[i+1].bottom+grids[i+1].height-12,textStyle:{fontSize:10,color:'#8a8072',fontWeight:'normal'}})),
  tooltip:{trigger:'axis',show:true,showContent:!mob,axisPointer:{type:opt.cross?'cross':'line',lineStyle:{color:'#c9a86a'}},confine:true,backgroundColor:'rgba(255,253,248,.95)',borderColor:'#e3d9c6',textStyle:{color:'#3a342c',fontSize:12},
   formatter:ps=>{const k=ps.find(p=>p.seriesType==='candlestick');if(!k)return'';const i=k.dataIndex,v=K[i],pc=i?K[i-1][2]:v[1],pct=((v[2]/pc-1)*100).toFixed(2);
    return `${v[0]}<br>开 ${v[1]}　收 <b class="${v[2]>=pc?'up':'dn'}">${v[2]}</b> ${pct}%<br>低 ${v[3]}　高 ${v[4]}${j.volume[i]!=null?`<br>量 ${(j.volume[i]/1e4).toFixed(1)} 万`:''}`}},
  dataZoom:[{type:'inside',filterMode:'weakFilter',xAxisIndex:xi,startValue:sv,endValue:ev,zoomOnMouseWheel:false,moveOnMouseWheel:false,moveOnMouseMove:true,minValueSpan:20},...(opt.slider?[{type:'slider',filterMode:'weakFilter',xAxisIndex:xi,startValue:sv,endValue:ev,height:18,bottom:8,borderColor:'#e3d9c6',textStyle:{color:'#8a8072'}}]:[])],
  series:S},true)}
// ---------- 加载 ----------
const OFF_TTL={day:'30 分钟',week:'30 分钟','1m':'2 分钟','5m':'5 分钟','15m':'10 分钟','30m':'10 分钟','60m':'10 分钟','120m':'10 分钟'};
function stamp(j){const m=$('#msg'),S0=String(j.src||'').split('+')[0],src=S0==='futu'?'富途':S0==='sina'?'新浪':S0;
 const bar=j.kline.at(-1)?.[0]||j.data_date||'—';
 const zone=j.market==='us'?'纽约时间':'当地时间';
 let warn='';if(j.stale)warn+=` · ⚠ 行情暂时未更新，显示数据截至 ${j.kline[j.kline.length-1][0]}`;
 
 
 if(j.data_date&&j.quote&&j.data_date<j.quote.date)warn+=` · ⚠ 数据日期 ${j.data_date}，滞后于最新交易日 ${j.quote.date}`;
 const tip=`数据更新说明\n· 服务端缓存：交易时段所有周期 60 秒；非交易时段 日线/周线 30 分钟、1 分 2 分钟、5 分 5 分钟、15/30/60/120 分 10 分钟。\n· 页面自动刷新：按左上角选择（默认 15 秒；页面在后台时暂停）。\n· 因此交易时段 K 线较实际行情约延迟 1–2 分钟。\n· 最近更新 ${j.updated}（北京时间）。`;
 m.className=(j.stale||warn.includes('⚠'))?'warn':'';m.innerHTML=`${PN[j.period]} · 最新 K 线 ${esc(bar)}（${zone}） · 缓存写入 ${esc(j.updated)}（北京时间）${esc(warn)} <span class="qm" title="${esc(tip)}">?</span>`}
let loading=false;const KC={};
function kOv(h){let o=document.getElementById('kov');if(!h){if(o)o.remove();return}const c=$('#chart');if(!c)return;if(!o){o=document.createElement('div');o.id='kov';o.style.cssText='position:absolute;inset:0;z-index:20;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:rgba(255,252,245,.82);color:#8a5a12;font-size:15px';c.appendChild(o)}o.innerHTML=h}
function kFetch(u,ms){const c=new AbortController();const t=setTimeout(()=>c.abort(),ms||15000);return api(u,{signal:c.signal}).catch(e=>{throw e.name==='AbortError'?new Error('timeout'):e}).finally(()=>clearTimeout(t))}
function withTimeout(p,ms){return Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),ms||15000))])}
function skKey(p){return `cw_sk_${st.market}_${String(st.code).toUpperCase()}_${p||st.period}`}
function skGet(p){try{const o=JSON.parse(sessionStorage.getItem(skKey(p)));if(o&&o.j&&o.j.kline&&o.j.kline.length)return o}catch(e){}return null}
function skPut(j){if(!j||j.bare||!j.kline||!j.kline.length)return;try{sessionStorage.setItem(skKey(j.period),JSON.stringify({t:Date.now(),j}))}catch(e){}}
function kPre(p){if(p==='5m')return;const u=`api/chan?code=${encodeURIComponent(st.code)}&market=${st.market}&period=${p}&nofetch=1`;const ku=`api/chan?code=${encodeURIComponent(st.code)}&market=${st.market}&period=${p}`;if(KC[ku]&&Date.now()-KC[ku].t<50000)return;if(lastJ&&lastJ.has_periods&&lastJ.has_periods[p]===false)return;kFetch(u,8000).then(j=>{KC[ku]={t:Date.now(),j};skPut(j)}).catch(()=>{})}
async function load(silent){if(loading&&silent)return;loading=true;localStorage.cw_market=st.market;localStorage.cw_code=st.code;SS('cw_period',st.period);syncUI();if(!silent){$('#msg').className='';$('#msg').textContent='加载中…'}
 const want=key()+st.period;let ovT=null;let painted=false;
 const _u=`api/chan?code=${encodeURIComponent(st.code)}&market=${st.market}&period=${st.period}`;
 const _ur=`api/kraw?code=${encodeURIComponent(st.code)}&market=${st.market}&period=${st.period}`;
 const paint=(j,keep)=>{try{lastJ=j;A=analyze(j);stamp(j);renderTop();draw(!!keep||!!silent);renderRight();checkAlerts();if(rtab==='sum'&&!silent)renderRight();if(j.quote)quotes[key()]={price:j.quote.price,pct:j.quote.pct};renderList();painted=true;kOv(null)}catch(err){console.error('paint',err);throw err}};
 const applyFull=nj=>{if(want!==key()+st.period)return;KC[_u]={t:Date.now(),j:nj};skPut(nj);paint(nj,painted);if(!silent&&st.period==='day')setTimeout(()=>kPre('30m'),1000)};
 try{
  const hc=KC[_u];
  if(!silent){const sk=(!hc||!hc.j)?skGet(st.period):null;const early=(hc&&hc.j)?hc.j:(sk&&sk.j);if(early)paint(early,false)}
  if(!silent&&hc&&hc.j&&Date.now()-hc.t<50000){if(st.period==='day')setTimeout(()=>kPre('30m'),1000);return}
  let j;
  if(window.__pre&&__pre.u===_u){const P=__pre;window.__pre=null;
    if(!painted&&window.__prekraw&&__prekraw.u===_ur){const R=__prekraw;window.__prekraw=null;R.p.then(rj=>{if(want!==key()+st.period||(lastJ&&!lastJ.bare&&KC[_u]))return;try{paint(rj,false)}catch(e){}}).catch(()=>{})}
    if(!silent&&!painted)ovT=setTimeout(()=>{if(want===key()+st.period&&!painted)kOv('<div class="kspin" style="width:28px;height:28px;border:3px solid #e8d5ac;border-top-color:#c8902a;border-radius:50%;animation:kspin 0.8s linear infinite"></div><div>K 线加载中…</div><style>@keyframes kspin{to{transform:rotate(360deg)}}</style>')},120);
    j=await withTimeout(P.p,15000)}
  else{
    if(!silent&&!painted){kFetch(_ur,8000).then(rj=>{if(want!==key()+st.period)return;if(lastJ&&!lastJ.bare&&KC[_u])return;try{paint(rj,false)}catch(e){}}).catch(()=>{});
      ovT=setTimeout(()=>{if(want===key()+st.period&&!painted)kOv('<div class="kspin" style="width:28px;height:28px;border:3px solid #e8d5ac;border-top-color:#c8902a;border-radius:50%;animation:kspin 0.8s linear infinite"></div><div>K 线加载中…</div><style>@keyframes kspin{to{transform:rotate(360deg)}}</style>')},150)}
    j=await kFetch(_u,15000)}
  if(want!==key()+st.period)return;applyFull(j)}
 catch(e){if(!silent&&want===key()+st.period){const to=e.message==='timeout';$('#msg').className='warn';$('#msg').textContent=to?'K 线加载超时':'出错：'+e.message;
   if(!painted)kOv(`<div>${to?'K 线加载超时，网络较慢':'K 线暂时没加载出来'}</div><button id="kretry" style="padding:6px 22px;border:1px solid #c8902a;background:#c8902a;color:#fff;border-radius:6px;font-size:14px;cursor:pointer">重试</button>`);const b=document.getElementById('kretry');if(b)b.onclick=()=>{kOv(null);load(false)}}}
 finally{clearTimeout(ovT);loading=false;cd=+$('#rint').value}}
function NS(){return !!(lastJ&&lastJ.kind&&lastJ.kind!=='stock')}
function renderTop(){const j=lastJ;document.body.classList.toggle('nonstock',NS());{const ok=v=>v!=null&&v!==''&&v!=='undefined'&&v!=='null';const c=ok(j&&j.code)?j.code:st.code,mk=(j&&j.market)||st.market,pd=(j&&j.period)||st.period,kd=j&&j.kind;$('#tname').textContent=(j&&ok(j.name))?j.name:(window.CSUG&&CSUG.nameOf&&CSUG.nameOf(mk,c))||c||'—';$('#tdesc').textContent=[c,mk==='hk'?'港股':mk==='a'?(/^[569]/.test(c)?'沪市':/^[48]/.test(c)?'北交所':'深市'):(kd==='index'?'美股指数':kd==='fut'?'外盘期货':'美股'),PN[pd]].filter(ok).join(' · ')}
 if(j&&j.quote){const q=j.quote,c=q.pct>=0?'up':'dn';$('#quote').innerHTML=`<span class="${c}">${fp(q.price,j.code)}　${q.pct>0?'+':''}${(+q.pct).toFixed(2)}%</span>`}else $('#quote').textContent='';
 const inW=acct.some(x=>x.market===st.market&&x.code===st.code.toUpperCase()),pinned=acct.some(x=>x.market===st.market&&x.code===st.code.toUpperCase()&&x.pinned);
 if(window.CN&&$('#favBtn')){$('#favBtn').innerHTML=CN.star(st.market,st.code.toUpperCase(),(typeof lastJ!=='undefined'&&lastJ&&lastJ.name)||'',1);CN.render()}
 $('#bAdd').textContent=inW?'★ 已自选':'☆ 加自选';$('#bAdd').classList.toggle('on',inW);$('#bPin').disabled=!inW;$('#bPin').textContent=pinned?'⇣ 取消置顶':'⇡ 置顶';$('#bPin').classList.toggle('on',pinned);
 $('#bAlert').classList.toggle('on',alerts.some(x=>!x.triggered));
 const pos=+LS('cw_pos',{})[key()]||0;$$('#pos button').forEach(b=>b.classList.toggle('on',+b.dataset.v===pos))}
function syncUI(){$$('#pd button').forEach(b=>b.classList.toggle('on',b.dataset.v===st.period));$$('.tg[data-c]').forEach(b=>b.classList.toggle('on',!!chanOn[b.dataset.c]));
 $('#inds').innerHTML=Object.keys(IND_DEF).map(k=>`<button class="tg ind ${indOn[k]?'on':''}" data-i="${k}">${k}</button>${k==='VOL'?'':`<button class="gear" data-g="${k}" title="${k} 设置">⚙</button>`}`).join(' ');
 $$('#tools input').forEach(i=>i.checked=!!opt[i.dataset.o]);renderTop()}
// 周期/缠论/指标
$('#pd').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.classList.contains('lock')){toast(`${PN[b.dataset.v]} 级别暂未开放`);return}st.period=b.dataset.v;load()};
$$('.tg[data-c]').forEach(b=>b.onclick=()=>{chanOn[b.dataset.c]=!chanOn[b.dataset.c];SS('cw_chan2',chanOn);syncUI();if(lastJ)draw(true)});
$('#inds').onclick=e=>{const i=e.target.dataset.i,g=e.target.dataset.g;if(i){indOn[i]=!indOn[i];SS('cw_ind',indOn);syncUI();if(lastJ){A=analyze(lastJ);draw(true)}}if(g)openSet(g)};
let setK=null;function openSet(k){setK=k;$('#sett').textContent=k+' 设置';$('#setf').innerHTML=Object.entries(indCfg[k]).map(([p,v])=>`<label class="lbl">${IND_LBL[p]||p}</label><input type="number" data-p="${p}" value="${v}" min="1" step="${k==='BOLL'&&p==='k'?0.1:1}">`).join('');$('#setm').classList.add('show')}
$('#setok').onclick=()=>{$$('#setf input').forEach(i=>{const v=+i.value;if(v>0)indCfg[setK][i.dataset.p]=v});SS('cw_indcfg',indCfg);$('#setm').classList.remove('show');indOn[setK]=true;SS('cw_ind',indOn);syncUI();if(lastJ){A=analyze(lastJ);draw(true);renderRight()}};
$('#setdef').onclick=()=>{indCfg[setK]={...IND_DEF[setK]};openSet(setK)};
// 图表工具
$('#bTools').onclick=e=>{e.stopPropagation();$('#tools').classList.toggle('show')};document.addEventListener('click',e=>{if(!e.target.closest('.dd'))$('#tools').classList.remove('show')});
$$('#tools input').forEach(i=>i.onchange=()=>{opt[i.dataset.o]=i.checked;SS('cw_opt',opt);if(lastJ)draw(true)});
$('#tReset').onclick=()=>resetView();
// ---------- 触控板 / 鼠标交互：拖动平移、双指捏合缩放、双指左右滑平移、滚轮小步缩放（以鼠标为中心） ----------
let DEFV=[0,0],NBARS=0;const MINB=20;
// 价位标签防重叠：按像素位置排序，间距不足 16px 时上下错开（缩放/平移后重新计算）
function placeLv(){const ml=window._ml;if(!ml||!chart)return;try{const P=ml.map((m,i)=>({i,y:chart.convertToPixel({yAxisIndex:0},m.yAxis)})).filter(o=>isFinite(o.y)).sort((a,b)=>a.y-b.y);
 const G=16;let prev=-1e9;const off={};P.forEach(o=>{const ny=Math.max(o.y,prev+G);off[o.i]=ny-o.y;prev=ny});
 chart.setOption({series:[{markLine:{data:ml.map((m,i)=>({...m,label:{...m.label,offset:[0,off[i]||0]}}))}}]})}catch(e){}}
function curV(){const m=chart.getModel(),dz=m&&m.getComponent('dataZoom',0);if(!dz)return DEFV;const r=dz.getPercentRange(),n=NBARS-1;return[Math.round(r[0]/100*n),Math.round(r[1]/100*n)]}
function setV(a,b){const span=Math.max(MINB,Math.min(NBARS,b-a));if(a<0){a=0}if(a+span>NBARS-1+5){a=Math.max(0,NBARS-1+5-span)}chart.dispatchAction({type:'dataZoom',batch:[{dataZoomIndex:0,startValue:Math.round(a),endValue:Math.round(a+span)}].concat(opt.slider?[{dataZoomIndex:1,startValue:Math.round(a),endValue:Math.round(a+span)}]:[])})}
function resetView(){if(lastJ)setV(DEFV[0],DEFV[1])}
function zoomAt(f,px){const[a,b]=curV(),span=b-a,ns=Math.max(MINB,Math.min(NBARS,span*f));const g=chart.getModel().getComponent('grid',0).coordinateSystem.getRect();const r=Math.min(1,Math.max(0,(px-g.x)/g.width));setV(a+(span-ns)*r,a+(span-ns)*r+ns)}
$('#chart').addEventListener('wheel',e=>{if(!lastJ)return;e.preventDefault();const rect=$('#chart').getBoundingClientRect(),px=e.clientX-rect.left;
 if(e.ctrlKey){zoomAt(Math.exp(e.deltaY*0.012),px);return}                // 触控板双指张开/捏合（浏览器以 ctrl+wheel 上报）
 if(Math.abs(e.deltaX)>Math.abs(e.deltaY)){const[a,b]=curV(),g=chart.getModel().getComponent('grid',0).coordinateSystem.getRect();setV(a+e.deltaX/g.width*(b-a),b+e.deltaX/g.width*(b-a));return}  // 双指左右滑：平移
 const d=e.deltaMode===1?e.deltaY*16:e.deltaY;zoomAt(Math.exp(Math.max(-60,Math.min(60,d))*0.0025),px)  // 普通滚轮：小步缩放
},{passive:false,capture:true});
$('#chart').addEventListener('dblclick',resetView,true);
$('#tSave').onclick=()=>{const a=document.createElement('a');a.href=chart.getDataURL({pixelRatio:2,backgroundColor:'#fffdf8'});a.download=`${st.code}_${st.period}.png`;a.click()};
// 空仓/持仓
$('#pos').onclick=e=>{const v=e.target.dataset.v;if(v==null)return;const p=LS('cw_pos',{});p[key()]=+v;SS('cw_pos',p);if(lastJ){A=analyze(lastJ);draw(true);renderRight()}renderTop()};
// 刷新
$('#rint').value=LS('cw_rint',15);let cd=+$('#rint').value;
$('#rint').onchange=()=>{SS('cw_rint',+$('#rint').value);cd=+$('#rint').value;tickTxt()};
function tickTxt(){const v=+$('#rint').value;$('#rcd').textContent=v?(document.hidden?'已暂停（页面在后台）':`刷新 ${Math.max(cd,0)} 秒`):'自动刷新已关闭'}
setInterval(()=>{const v=+$('#rint').value;if(lastJ&&lastJ.trading===false){$('#rcd').textContent='休市中，不自动刷新';return}if(!v||document.hidden){tickTxt();return}cd--;if(cd<=0){cd=v;load(true);refreshQuotes()}tickTxt()},1000);
document.addEventListener('visibilitychange',tickTxt);
// 账号/自选
function renderUser(){$('#user').innerHTML=me?`<a href="watchlist">自选页</a><a href="#" id="lo">${esc(me.username)} · 退出</a>`:`<a href="watchlist">自选页</a><a href="#" id="li">登录 / 注册</a>`}
$('#user').onclick=async e=>{if(e.target.id==='li'){e.preventDefault();openAuth()}if(e.target.id==='lo'){e.preventDefault();await api('api/logout',{method:'POST'}).catch(()=>{});await refreshMe()}};
let atab='login';function openAuth(){$('#aerr').textContent='';$('#auth').classList.add('show');$('#au').focus()}
$('#auth .tabs').onclick=e=>{const t=e.target.dataset.t;if(!t)return;atab=t;$$('#auth .tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));$('#aok').textContent=t==='login'?'登录':'注册'};
$('#aok').onclick=async()=>{try{await api('api/'+atab,{method:'POST',body:JSON.stringify({username:$('#au').value.trim(),password:$('#ap').value})});$('#auth').classList.remove('show');$('#ap').value='';await refreshMe()}catch(e){$('#aerr').textContent=e.message}};
$('#ap').onkeydown=e=>{if(e.key==='Enter')$('#aok').click()};
async function refreshMe(){try{me=(await api('api/me')).user}catch(e){me=null}renderUser();
 if(me){try{acct=(await api('api/watch')).items}catch(e){acct=[]}await loadAlerts()}else{acct=[];alerts=[]}renderGroups();renderList();renderTop();refreshQuotes()}
function wlItems(){const seen=new Set();return acct.filter(x=>x.market===leftMkt&&(leftGrp==='全部'||x.grp===leftGrp)).filter(x=>{const k=x.market+x.code;if(seen.has(k))return false;seen.add(k);return true}).sort((a,b)=>(b.pinned||0)-(a.pinned||0))}
function renderGroups(){const gs=[...new Set(acct.filter(x=>x.market===leftMkt).map(x=>x.grp))];if(leftGrp!=='全部'&&!gs.includes(leftGrp))leftGrp='全部';
 $('#gsel2').innerHTML=['全部',...gs].map(g=>`<option ${g===leftGrp?'selected':''}>${esc(g)}</option>`).join('');$$('#mkt button').forEach(b=>b.classList.toggle('on',b.dataset.m===leftMkt))}
function renderList(){const L=wlItems();$('#lhd').textContent=`自选 · ${leftMkt==='a'?'沪深':'美股'} · ${L.length} 只`;
 if(!me){$('#list').innerHTML='<div class="empty">登录后显示账号自选<br><a href="#" onclick="openAuth();return false">登录 / 注册</a></div>';return}
 if(!L.length){$('#list').innerHTML='<div class="empty">当前分组暂无自选</div>';return}
 $('#list').innerHTML=L.map(x=>{const q=quotes[x.market+':'+x.code];return `<div class="it ${x.market===st.market&&x.code===st.code.toUpperCase()?'on':''}" data-m="${x.market}" data-c="${esc(x.code)}"><div class="n"><b>${x.pinned?'<span class="pin">⇡</span> ':''}${esc(x.name||x.code)}</b><small>${esc(x.code)}</small></div><div class="q">${q?`<div>${q.price}</div><div class="${q.pct>=0?'up':'dn'}">${q.pct>0?'+':''}${q.pct}%</div>`:'<span style="color:#c9bfae">—</span>'}</div></div>`}).join('')}
$('#mkt').onclick=e=>{const m=e.target.dataset.m;if(!m)return;leftMkt=m;renderGroups();renderList();refreshQuotes()};
$('#gsel2').onchange=()=>{leftGrp=$('#gsel2').value;SS('cw_lgrp',leftGrp);renderList();refreshQuotes()};
$('#list').onclick=e=>{const it=e.target.closest('.it');if(!it)return;window.open(`./?market=${it.dataset.m}&code=${encodeURIComponent(it.dataset.c)}&period=${st.period}`,'_blank','noopener')};
async function refreshQuotes(){const L=wlItems().slice(0,300);if(!L.length)return;try{const r=await api('api/quotes?codes='+encodeURIComponent(L.map(x=>x.market+':'+x.code).join(',')));Object.assign(quotes,r);renderList()}catch(e){}}
$('#bAdd').onclick=()=>{if(!me){openAuth();return}const gs=[...new Set(acct.map(x=>x.grp))];if(!gs.includes('默认'))gs.unshift('默认');
 $('#gsel').innerHTML=gs.map(g=>`<option>${esc(g)}</option>`).join('');$('#gnew').value='';$('#gerr').textContent='';$('#addt').textContent=`把 ${lastJ?lastJ.name:st.code} 加到自选`;$('#addm').classList.add('show')};
$('#bGrp').onclick=()=>{if(!me){openAuth();return}$('#bAdd').onclick();$('#addt').textContent=`新建分组并加入 ${lastJ?lastJ.name:st.code}`;$('#gnew').focus()};
$('#gok').onclick=async()=>{try{await api('api/watch',{method:'POST',body:JSON.stringify({market:st.market,code:st.code,name:lastJ&&lastJ.name,group:$('#gnew').value.trim()||$('#gsel').value})});$('#addm').classList.remove('show');toast('已加入自选');await refreshMe()}catch(e){$('#gerr').textContent=e.message}};
$('#bPin').onclick=async()=>{const p=acct.some(x=>x.market===st.market&&x.code===st.code.toUpperCase()&&x.pinned);try{await api('api/watch/pin',{method:'POST',body:JSON.stringify({market:st.market,code:st.code,pinned:!p})});await refreshMe()}catch(e){toast(e.message)}};
// 提醒
async function loadAlerts(){if(!me){alerts=[];return}try{alerts=(await api(`api/alerts?market=${st.market}&code=${encodeURIComponent(st.code)}`)).items}catch(e){alerts=[]}}
function renderAlerts(){const alerts_=alerts.filter(x=>!x.dyn);$('#alist').innerHTML=alerts_.length?alerts_.map(x=>`<div class="kv"><span>${x.kind==='bsp'?'出现新买卖点':(x.kind==='above'?'上穿 ':'跌破 ')+x.price}${x.note?' · '+esc(x.note):''}</span><span>${x.triggered?'已触发 ':''}<a href="#" data-del="${x.id}">删除</a></span></div>`).join(''):'<div class="lbl">这只股票还没有提醒</div>'}
$('#bAlert').onclick=async()=>{if(!me){openAuth();return}await loadAlerts();$('#alt').textContent=`给 ${lastJ?lastJ.name:st.code} 加提醒`;$('#aprice').value='';$('#akind').value='above';loadSet();$('#alerr').textContent='';renderAlerts();$('#alm').classList.add('show');pushHint()};
let ASET=null;async function loadSet(){const e=$('#aset');e.textContent='读取整套提醒…';try{ASET=await api(`api/alerts/set?market=${st.market}&code=${encodeURIComponent(st.code)}`);const fresh=!ASET.saved;
 e.innerHTML=`<h6>整套提醒（价位跟随最新日线结论，结论更新自动换新价位）${fresh?' · 默认全选':''}</h6>`+ASET.items.map(x=>`<label class="${x.applicable?'':'na'}"><input type="checkbox" data-k="${x.kind}" ${(fresh?x.applicable:x.on)?'checked':''} ${x.applicable?'':'disabled'}><span>${esc(x.label)}${x.last?`<small>最近触发：${esc(x.last)}</small>`:''}</span><span class="lv">${x.level!=null?x.level:(x.kind==='concl'?esc(x.cur||'—'):x.kind==='bsp'?(x.cur?'当前：'+esc(x.cur):'—'):'暂无价位')}</span></label>`).join('')+`<small>现价 ${ASET.price??'—'}（${esc(ASET.date||'')}）· 同一事件只推送一次</small>`}catch(x){e.textContent='整套提醒读取失败：'+x.message}}
async function pushHint(){const e=$('#alpush');e.textContent='微信推送状态读取中…';try{const d=await api('api/push');e.innerHTML=d.configured?'✅ 已开启微信推送（'+esc(d.mask)+'）：价格提醒交易时段约每分钟检查，触发即推送。<a href="settings" target="_blank">管理</a>':'未配置微信推送，目前只在站内提醒。<a href="settings" target="_blank">去设置</a>'}catch(x){e.innerHTML='站内提醒。<a href="settings" target="_blank">微信推送设置</a>'}}

let ALBUSY=false;$('#alok').onclick=async()=>{if(ALBUSY)return;ALBUSY=true;const B=$('#alok'),T0=B.textContent;B.disabled=true;B.textContent='添加中…';try{const kinds=[...document.querySelectorAll('#aset input[data-k]:checked')].map(x=>x.dataset.k);if(ASET)await api('api/alerts/set',{method:'PUT',body:JSON.stringify({market:st.market,code:st.code,kinds})});let r=null;if(+$('#aprice').value)r=await api('api/alerts',{method:'POST',body:JSON.stringify({market:st.market,code:st.code,kind:$('#akind').value,price:+$('#aprice').value,note:$('#anote').value})});$('#aprice').value='';await loadSet();$('#alerr').textContent=r&&r.dup?'该自定义提醒已存在，未重复添加':'已保存';$('#anote').value='';await loadAlerts();renderAlerts();renderTop();renderRight();if(r&&r.dup)$('#alerr').textContent='该提醒已存在，未重复添加'}catch(e){$('#alerr').textContent=e.message}finally{ALBUSY=false;B.disabled=false;B.textContent=T0}};
$('#alist').onclick=async e=>{const d=e.target.dataset.del;if(!d)return;e.preventDefault();await api('api/alerts/'+d,{method:'DELETE'});await loadAlerts();renderAlerts();renderTop();renderRight()};
function checkAlerts(){if(!lastJ||!alerts.length)return;const j=lastJ,p=j.quote?j.quote.price:A.C,lb=A.lb;
 alerts.filter(x=>!x.dyn&&!x.triggered&&x.market===j.market&&x.code===j.code).forEach(x=>{let hit=false,txt='';
  if(x.kind==='above'&&p>=x.price){hit=true;txt=`上穿 ${x.price}（现价 ${p}）`}
  if(x.kind==='below'&&p<=x.price){hit=true;txt=`跌破 ${x.price}（现价 ${p}）`}
  if(x.kind==='bsp'&&lb){const t=new Date(A.T[lb.x].replace(' ','T')+'+08:00').getTime()/1000;if(t>x.created){hit=true;txt=`出现 ${bspCN(lb.type,lb.buy)}`}}
  if(hit){toast(`🔔 ${j.name} ${txt}`);x.triggered=Date.now()/1000;api(`api/alerts/${x.id}/trigger`,{method:'POST',body:JSON.stringify({txt})}).catch(()=>{});renderTop();renderRight()}})}
// 搜索 / 切换（A–Z 键盘直接唤起）
function openSearch(init){$('#srch').classList.add('show');$('#sq').value=init||'';$('#sq').focus();searchRender()}
$('#bSearch').onclick=()=>openSearch('');
document.addEventListener('keydown',e=>{if(e.target.closest('input,select,textarea')||e.metaKey||e.ctrlKey||e.altKey)return;if($('.modal.show'))return;if(/^[a-zA-Z0-9]$/.test(e.key)){e.preventDefault();openSearch(e.key.toUpperCase())}});
function searchRender(){const q=$('#sq').value.trim().toUpperCase();const seen=new Set();let L=acct.filter(x=>{const k=x.market+x.code;if(seen.has(k))return false;seen.add(k);return !q||x.code.includes(q)||(x.name||'').toUpperCase().includes(q)}).slice(0,30);
 const h=[];if(/^\d{6}$/.test(q))h.push({market:'a',code:q,name:'打开 A 股 '+q});else if(/^[A-Z][A-Z.\-]{0,9}$/.test(q))h.push({market:'us',code:q,name:'打开美股 '+q});
 $('#sres').innerHTML=[...h,...L].map((x,i)=>`<div class="it ${i===0?'on':''}" data-m="${x.market}" data-c="${esc(x.code)}"><div class="n"><b>${esc(x.name||x.code)}</b><small>${esc(x.code)} · ${(x.market==='us'&&/^\./.test(x.code)?'美股指数':x.market==='us'&&/MAIN$/.test(x.code)?'外盘期货':x.market==='a'?'沪深':'美股')}</small></div></div>`).join('')||'<div class="empty">输入 6 位 A 股代码或美股代码</div>'}
$('#sq').oninput=searchRender;$('#sq').onkeydown=e=>{if(e.key==='Enter'){const f=$('#sres .it');if(f)f.click()}if(e.key==='Escape')$('#srch').classList.remove('show')};
$('#sres').onclick=e=>{const it=e.target.closest('.it');if(!it)return;$('#srch').classList.remove('show');st.market=it.dataset.m;st.code=it.dataset.c;leftMkt=st.market;renderGroups();renderList();window._ans=[];loadAlerts().then(()=>load())};
// 手机：单击才显示浮窗
const q=new URLSearchParams(location.search);if(q.get('code')){st.code=q.get('code').toUpperCase();st.market=(['us','hk'].includes(q.get('market'))?q.get('market'):'a');const p=q.get('period');if(Object.keys(PN).includes(p))st.period=p;history.replaceState(null,'',location.pathname)}
window.__mainReady=1;if(WL_UI)document.body.classList.remove('nowl');leftMkt=st.market;syncUI();renderRight();refreshMe().then(()=>load());

;(function(){const e=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]);
setInterval(()=>{const j=typeof lastJ!=='undefined'&&lastJ,b=document.getElementById('modelbox');if(!b)return;const m=j&&j.model;
if(!m){b.style.display='none';return}b.style.display='block';
b.innerHTML=`<b style="color:#8a5a12">strategy_v1 模型推荐：${e(m.verdict)}</b> · ${e(m.sig)}<br><span style="color:#5a4a30">${e(m.why)}</span><br><span style="color:#9a8e7a">信号日 ${e(m.date)} · 止损参考 ${e(m.stop)}（扫低最低点）· 收 ${e(m.close)} &gt; EMA20 ${e(m.ema)}</span>`},1000)})();
