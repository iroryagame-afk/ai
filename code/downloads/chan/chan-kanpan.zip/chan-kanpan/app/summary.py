"""日线缠论本地规则总结（不调模型）+ 自选股后台预计算。仅供技术参考，不构成投资建议。"""
import json, os, threading, time, sqlite3
BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "data", "summary.json")
TYPE_CN = {"1": "一", "1p": "盘背一", "2": "二", "2s": "类二", "3a": "三", "3b": "三"}
RULES = ("判定依据＝缠论「形态学 + 动力学」，两者必须同时满足，不做其他加权：形态学＝包含处理后的分型、笔、线段、中枢及走势结构，看买卖点所处位置"
         "（一买＝趋势背驰段终点；二买＝一买后回抽不破前低；三买＝离开中枢后回抽不进中枢；预判一/二/三买＝中枢下方/中枢内/中枢上沿回踩的待确认结构；卖点对称）；"
         "动力学＝MACD（柱面积背驰、盘整背驰、绿/红柱连续缩短或放大的力度变化、DIF/DEA 交叉、DIF 回抽零轴）。参考缠论原文第 24、25、27 课背驰与 MACD 辅助判断。"
         "首页分类：推荐买入＝近 5 根已确认买点、现价站稳且距买点不超过 8%、未破失效位、形态+动能均看多，只看日线、不要求 30 分共振（30 分状态仅作卡片参考；每日收盘后计算一次并冻结：A股北京时间 15:30，美股美东 16:30；首页与个股页日线结论只用冻结版，盘中不改）；"
         "看多＝预判买点结构+动能看多；看空＝已确认卖点+动能看空；谨慎＝预判卖点结构+动能看空。MA20 只作参考。买卖点超过 60 根视为过期；关键价位取最近结构，偏离过大不显示。"
         "由 chan.py 结构按固定规则生成，仅供参考，不构成投资建议。")

def bsp_cn(t, buy):
    out = []
    for x in str(t).split(","):
        w = "笔" + TYPE_CN.get(x.strip(), x.strip()) + ("买" if buy else "卖")
        if w not in out: out.append(w)
    return "、".join(out)

def _ema(x, n):
    return x.ewm(span=n, adjust=False).mean()

def analyze(df, res, period="day"):
    """统一规则：看图页「操作」（按当前周期）与「总结/首页」（日线）共用。"""
    K = df.reset_index(drop=True); n = len(K); close = K["close"].astype(float); C = float(close.iloc[-1])
    T = K["time"].astype(str).tolist(); hi = K["high"].astype(float); lo = K["low"].astype(float)
    r = lambda v: None if v is None else round(float(v), 3)
    bsp = sorted(res["bsp"], key=lambda p: p["x"]); lb_all = bsp[-1] if bsp else None
    RECENT = 60  # 超过 60 根的买卖点视为过期，不再参与结论和关键价位
    lb = lb_all if lb_all and n - 1 - lb_all["x"] <= RECENT else None
    last_buy = next((p for p in reversed(bsp) if p["buy"] and n - 1 - p["x"] <= RECENT), None)
    bis = res["bi"]; zss = res["zs"]
    zs = zss[-1] if zss else None; bi = bis[-1] if bis else None; seg = res["seg"][-1] if res["seg"] else None
    lows = sorted({round(min(b["y0"], b["y1"]), 4) for b in bis})  # 笔低点
    # 上车位：近期买点；否则按最近中枢（中枢内/下方→下沿附近，上方→上沿回踩）；都没有则最近笔低点
    zs_recent = zs if zs and zs["x1"] >= n - 1 - 250 else None
    if last_buy: entry = last_buy["y"]
    elif zs_recent: entry = zs_recent["high"] if C > zs_recent["high"] else zs_recent["low"]
    else: entry = min(bi["y0"], bi["y1"]) if bi else None
    # 结构失效：上车位下方最近的笔低点（取最近 250 根内，严格低于上车位）
    ref = min(C, entry) if entry else C
    rb = [b for b in bis if max(b["x0"], b["x1"]) >= n - 1 - 250]
    if last_buy: rb = [b for b in rb if max(b["x0"], b["x1"]) <= last_buy["x"]] or rb
    below = [min(b["y0"], b["y1"]) for b in rb if min(b["y0"], b["y1"]) < ref * 0.999]
    stop = max(below) if below else (ref * 0.97)
    if last_buy: stop = max(stop, last_buy["y"])  # 买点失效位＝买点价本身：跌破买点低点即该买点失效
    level_note = []
    if entry is not None and abs(entry / C - 1) > 0.3: level_note.append(f"上车位 {round(entry, 3)} 距现价超过 30%，暂不作参考"); entry = None
    if stop is not None and (C - stop) / C > 0.3: level_note.append(f"失效位 {round(stop, 3)} 距现价超过 30%，暂不作参考"); stop_hidden = stop; stop = None
    resist = sorted([v for v in [zs and zs["high"], zs and zs["low"], bi and max(bi["y0"], bi["y1"]), float(hi.tail(60).max()), float(hi.tail(120).max())] if v is not None and v > max(C, entry or 0) * 1.005])
    target = resist[0] if resist else (float(hi.tail(250).max()) if float(hi.tail(250).max()) > max(C, entry or 0) * 1.005 else max(C, entry or 0) * 1.1)
    if abs(target / C - 1) > 0.5: level_note.append(f"落袋位 {round(target, 3)} 距现价超过 50%，暂不作参考"); target = None
    ma20 = float(close.tail(20).mean())
    dif = _ema(close, 12) - _ema(close, 26); dea = _ema(dif, 9); hist = 2 * (dif - dea)
    mc = ("MACD 金叉" if dif.iloc[-2] <= dea.iloc[-2] else "MACD 多头") if dif.iloc[-1] > dea.iloc[-1] else ("MACD 死叉" if dif.iloc[-2] >= dea.iloc[-2] else "MACD 空头")
    h = hist.tail(4).tolist()
    mom = None
    if len(h) == 4:
        if h[-1] < 0 and abs(h[-1]) < abs(h[-2]) < abs(h[-3]): mom = "绿柱连续缩短，下跌动能衰减"
        elif h[-1] > 0 and h[-1] < h[-2] < h[-3]: mom = "红柱连续缩短，上涨动能衰减"
        elif h[-1] < 0 and abs(h[-1]) > abs(h[-2]) > abs(h[-3]): mom = "绿柱放大，下跌动能增强"
        elif h[-1] > 0 and h[-1] > h[-2] > h[-3]: mom = "红柱放大，上涨动能增强"
    macd_bc = None
    if len(bis) >= 3:
        x, y = bis[-1], bis[-3]; up = x["y1"] > x["y0"]
        area = lambda b: float(hist.iloc[min(b["x0"], b["x1"]):max(b["x0"], b["x1"]) + 1].abs().sum())
        if ((up and x["y1"] > y["y1"]) or (not up and x["y1"] < y["y1"])) and area(x) < area(y) * 0.8:
            macd_bc = "顶背驰（新高但 MACD 面积缩小）" if up else "底背驰（新低但 MACD 面积缩小）"
    # 背驰力度（排序用，非打分）：买卖点所在那一笔与前一同向笔的 MACD 柱面积缩小比例
    bc_strength = None
    if lb:
        _ar = lambda b: float(hist.iloc[min(b["x0"], b["x1"]):max(b["x0"], b["x1"]) + 1].abs().sum())
        same = [b for b in bis if ((b["y1"] < b["y0"]) if lb["buy"] else (b["y1"] > b["y0"])) and max(b["x0"], b["x1"]) <= lb["x"]]
        if len(same) >= 2 and _ar(same[-2]) > 0: bc_strength = round(1 - _ar(same[-1]) / _ar(same[-2]), 3)
    where = "暂无中枢" if not zs else "中枢上方" if C > zs["high"] else "中枢下方" if C < zs["low"] else "中枢内"
    trend = "盘整"
    if len(zss) >= 2:
        a1, a2 = zss[-2], zss[-1]
        trend = "上涨趋势" if a2["low"] > a1["high"] else "下跌趋势" if a2["high"] < a1["low"] else "盘整"
    seg_up = bool(seg and seg["y1"] > seg["y0"]); bi_up = bool(bi and bi["y1"] > bi["y0"])
    age = n - 1 - lb["x"] if lb else 999
    bc = [{"x": p["x"], "y": p["y"], "buy": p["buy"], "t": "盘整背驰" if "1p" in str(p["type"]) else "笔背驰"} for p in bsp if "1" in str(p["type"])]
    lbc = bc[-1] if bc else None
    why = []  # 不做任何加权打分：只列事实与满足的条件
    if lb:
        txt = bsp_cn(lb["type"], lb["buy"])
        if lb["buy"]: why.append(f"{age} 根前出现{txt}（{r(lb['y'])}），{'现价站稳' if C >= lb['y'] else '现价未站稳'}")
        else: why.append(f"{age} 根前出现{txt}（{r(lb['y'])}）")
    if not lb and lb_all: why.append(f"近 60 根无买卖点（最近一个是 {n - 1 - lb_all['x']} 根前的{bsp_cn(lb_all['type'], lb_all['buy'])}，已过期不计）")
    if mom: why.append(mom)
    if macd_bc: why.append("MACD " + macd_bc)
    if lbc and n - 1 - lbc["x"] <= 10: why.append(f"近期{'底' if lbc['buy'] else '顶'}背驰（{T[lbc['x']]}）")
    if zs: why.append(f"现价在最近中枢 {r(zs['low'])}–{r(zs['high'])} {where[2:] if where != '中枢内' else '内'}")
    why.append(f"线段{'向上' if seg_up else '向下'}、当前笔{'向上' if bi_up else '向下'}")
    broke = stop is not None and C < stop
    if broke: why.append(f"跌破结构失效位 {r(stop)}")
    why.append(f"{'站上' if C > ma20 else '低于'} MA20（{r(ma20)}）")
    weak_down = mom == "绿柱连续缩短，下跌动能衰减" or (macd_bc or "").startswith("底背驰")
    # ---------- 首页四类（后验 / 预判） ----------
    # 推荐买入 = 后验买点：近 5 根出现买点，现价站稳且未跌破失效位
    # 看多     = 预判买点：尚未出现确认买点，但结构指向即将出现（回踩中枢上沿=预判三买；中枢内/下沿+下跌动能衰减=预判二买；中枢下方+底背驰/绿柱缩短=预判一买）
    # 看空     = 后验卖点：近 5 根出现卖点，现价仍在卖点下方
    # 谨慎     = 预判卖点：中枢上方+顶背驰/红柱缩短=预判一卖；中枢内/上沿+上涨动能衰减=预判二卖；中枢下方反抽不进中枢=预判三卖
    up_fade = mom == "红柱连续缩短，上涨动能衰减" or (macd_bc or "").startswith("顶背驰")
    zl, zh = (zs["low"], zs["high"]) if zs else (None, None)
    cat, cat_sig = "none", ""
    if lb and age <= 5 and lb["buy"] and lb["y"] <= C <= lb["y"] * 1.08 and not broke:
        cat, cat_sig = "buy", bsp_cn(lb["type"], True) + "（已确认）"
    elif lb and age <= 5 and not lb["buy"] and lb["y"] * 0.92 <= C <= lb["y"]:
        cat, cat_sig = "bear", bsp_cn(lb["type"], False) + "（已确认）"
    elif zs:
        if C > zh and C <= zh * 1.05 and not bi_up and trend != "下跌趋势" and not (lb and not lb["buy"] and age <= 10): cat, cat_sig = "bull", "预判三买（回踩中枢上沿 %s 不入中枢）" % r(zh)
        elif zl <= C <= zh and weak_down and not bi_up: cat, cat_sig = "bull", "预判二买（中枢内下跌动能衰减）"
        elif C < zl and weak_down: cat, cat_sig = "bull", "预判一买（中枢下方%s）" % ("底背驰" if (macd_bc or "").startswith("底背驰") else "绿柱缩短")
        elif C > zh and up_fade and bi_up: cat, cat_sig = "caution", "预判一卖（中枢上方%s）" % ("顶背驰" if (macd_bc or "").startswith("顶背驰") else "红柱缩短")
        elif zl <= C <= zh and up_fade and bi_up: cat, cat_sig = "caution", "预判二卖（中枢内上涨动能衰减）"
        elif C < zl and C >= zl * 0.95 and bi_up and not (lb and lb["buy"] and age <= 10): cat, cat_sig = "caution", "预判三卖（反抽中枢下沿 %s 不进中枢）" % r(zl)
    # 已确认 硬校验①：买卖点所在笔必须已完成（最后一笔仍在延伸、终点就是最新一根的，只是候选，不算已确认）
    g0_note = ""
    if lb:
        lbi_ = bis[-1] if bis else None
        if lbi_ and not lbi_.get("sure", True) and max(lbi_["x0"], lbi_["x1"]) >= lb["x"] and lb["x"] >= n - 2:
            g0_note = "%s所在笔未完成（%s仍在延伸），只是候选，不算已确认" % (bsp_cn(lb["type"], lb["buy"]), "下跌笔" if lb["buy"] else "上涨笔")
    # 已确认 硬校验②：一类买卖点必须背驰——买卖点那一笔 MACD 柱面积小于前一同向笔（bc_strength>0），否则不成立
    if lb and not g0_note:
        t_ = [t.strip() for t in str(lb["type"]).split(",")]
        if all(t in ("1", "1p") for t in t_) and (bc_strength is None or bc_strength <= 0):
            g0_note = "%s无背驰（该笔 MACD 面积%s前一同向笔），一类不成立" % (bsp_cn(lb["type"], lb["buy"]), "未小于" if bc_strength is None else "大于")
    cand_note = g0_note
    cand_sig = (bsp_cn(lb["type"], lb["buy"]) + "（%s · %s）" % (r(lb["y"]), T[lb["x"]][:10]) + "：" + ("所在笔未完成" if "未完成" in g0_note else "无背驰")) if cand_note else ""
    prior_ok = [p for p in bsp if lb and p["x"] < lb["x"] and n - 1 - p["x"] <= RECENT] if cand_note else []
    pending = ""
    if g0_note and cat in ("buy", "bear") and "无背驰" in g0_note:
        # 一类：形态成立、笔已走完、但背驰不成立 → 看多/谨慎·待确认，不进推荐买入
        pending = "buy" if cat == "buy" else "sell"
        cat, cat_sig = ("bull" if pending == "buy" else "caution"), bsp_cn(lb["type"], lb["buy"]) + "·待确认（等背驰确认）"
        g0_note = g0_note.replace("一类不成立", "等背驰确认")
    elif g0_note and cat in ("buy", "bear"):
        cat, cat_sig = "none", ""
    else:
        g0_note = ""
    # 三类买卖点硬校验：三买＝离开中枢向上后回抽不进中枢，买点价与现价都须在最近中枢上沿之上；三卖对称
    g3_note = ""
    if cat in ("buy", "bear") and lb and "3" in str(lb["type"]):
        ok3 = bool(zs) and ((lb["y"] > zh and C > zh and trend != "下跌趋势") if cat == "buy" else (lb["y"] < zl and C < zl and trend != "上涨趋势"))
        if not ok3:
            rest = [t.strip() for t in str(lb["type"]).split(",") if "3" not in t]
            g3_note = "三%s不成立（%s）" % ("买" if cat == "buy" else "卖", ("现价/买点不在最近中枢 %s–%s 上方" if cat == "buy" else "现价/卖点不在最近中枢 %s–%s 下方") % (r(zl), r(zh)) if zs else "无中枢")
            if rest:
                lb = dict(lb, type=",".join(rest)); cat_sig = bsp_cn(lb["type"], cat == "buy") + "（已确认）"
            else: cat, cat_sig = "none", ""
    # 二类买卖点须有前置同向一类买卖点
    if cat in ("buy", "bear") and lb and "2" in str(lb["type"]) and "1" not in str(lb["type"]):
        prior1 = [p for p in bsp if p["x"] < lb["x"] and p["buy"] == lb["buy"] and "1" in str(p["type"])]
        opp1 = [p for p in bsp if p["x"] < lb["x"] and p["buy"] != lb["buy"]]
        if not prior1 or (opp1 and opp1[-1]["x"] > prior1[-1]["x"] and "2s" not in str(lb["type"])):
            rest = [t.strip() for t in str(lb["type"]).split(",") if "2" not in t]
            g3_note = (g3_note + "；" if g3_note else "") + "二类%s缺少前置一类%s，不成立" % (("买", "买") if lb["buy"] else ("卖", "卖"))
            if rest: lb = dict(lb, type=",".join(rest)); cat_sig = bsp_cn(lb["type"], lb["buy"]) + "（已确认）"
            else: cat, cat_sig = "none", ""
    # 方向一致：最近信号为卖点（且现价仍在卖点下方）不判看多；最近买点未破失效位不判看空
    if lb and cat in ("bull",) and not lb["buy"] and C <= lb["y"]:
        g3_note = (g3_note + "；" if g3_note else "") + "最近信号为%s，不判看多" % bsp_cn(lb["type"], False); cat, cat_sig = "none", ""
    if lb and cat in ("caution", "bear") and lb["buy"] and not broke:
        g3_note = (g3_note + "；" if g3_note else "") + "最近%s未破失效位，不判看空" % bsp_cn(lb["type"], True); cat, cat_sig = "none", ""
    # ---------- 三项条件：MACD 动能 / MACD 形态 / K 线形态 ----------
    # 形态学：包含处理后的分型/笔/线段/中枢结构（买卖点所处结构位置）；动力学：MACD 力度/背驰/零轴回抽
    TDESC = {"1": "趋势背驰段终点（一类）", "1p": "盘整背驰（一类）", "2": "一类后回抽不破前极值（二类）", "2s": "类二类（二类后再回抽不破）", "3a": "离开中枢后回抽不进中枢（三类）", "3b": "离开中枢后回抽不进中枢（三类）"}
    def sdesc(p):
        return "；".join(dict.fromkeys(TDESC.get(t.strip(), t.strip()) for t in str(p["type"]).split(",")))
    shape_b, shape_s = [], []
    if cat == "buy": shape_b.append(f"{bsp_cn(lb['type'], True)}：{sdesc(lb)}，现价未破该买点")
    if cat == "bear": shape_s.append(f"{bsp_cn(lb['type'], False)}：{sdesc(lb)}，现价在卖点下方")
    if cat == "bull": shape_b.append(cat_sig.replace("预判", "预判结构：", 1))
    if cat == "caution": shape_s.append(cat_sig.replace("预判", "预判结构：", 1))
    if bi and min(bi["x0"], bi["x1"]) >= n - 6:  # 新笔刚形成 = 分型确认
        (shape_b if bi_up else shape_s).append(("底" if bi_up else "顶") + f"分型确认后新笔{'向上' if bi_up else '向下'}（{T[min(bi['x0'], bi['x1'])][5:16]}）")
    gc = any(dif.iloc[j] > dea.iloc[j] and dif.iloc[j - 1] <= dea.iloc[j - 1] for j in range(max(1, n - 3), n))
    dc = any(dif.iloc[j] < dea.iloc[j] and dif.iloc[j - 1] >= dea.iloc[j - 1] for j in range(max(1, n - 3), n))
    rng = float((dif.tail(120).abs()).max() or 1)
    zb = dif.iloc[-1] > 0 and abs(dif.iloc[-1]) < 0.2 * rng and dif.iloc[-1] > dif.iloc[-2] and dif.tail(20).max() > 0.4 * rng   # 回抽零轴后再起
    zs_ = dif.iloc[-1] < 0 and abs(dif.iloc[-1]) < 0.2 * rng and dif.iloc[-1] < dif.iloc[-2] and dif.tail(20).min() < -0.4 * rng
    pb = bool(lbc and lbc["buy"] and n - 1 - lbc["x"] <= 10 and lbc["t"] == "盘整背驰"); ps = bool(lbc and not lbc["buy"] and n - 1 - lbc["x"] <= 10 and lbc["t"] == "盘整背驰")
    dyn_b = [x for x, ok in [("底背驰（新低但 MACD 绿柱面积缩小）", (macd_bc or "").startswith("底背驰")), ("盘整背驰", pb), ("绿柱连续缩短（下跌力度衰减）", mom == "绿柱连续缩短，下跌动能衰减"),
             ("红柱连续放大（上涨力度转强）", mom == "红柱放大，上涨动能增强"), ("DIF 上穿 DEA（近 3 根金叉）", gc), ("DIF 回抽零轴后再起", zb)] if ok]
    dyn_s = [x for x, ok in [("顶背驰（新高但 MACD 红柱面积缩小）", (macd_bc or "").startswith("顶背驰")), ("盘整背驰", ps), ("红柱连续缩短（上涨力度衰减）", mom == "红柱连续缩短，上涨动能衰减"),
             ("绿柱连续放大（下跌力度转强）", mom == "绿柱放大，下跌动能增强"), ("DIF 下穿 DEA（近 3 根死叉）", dc), ("DIF 反抽零轴后再落", zs_)] if ok]
    gates = {"bull": {"形态": shape_b, "动能": dyn_b}, "bear": {"形态": shape_s, "动能": dyn_s}}
    pre_cat, gate_note = cat, ((g0_note + ("；" + g3_note if g3_note else "")) if g0_note else g3_note)
    if cat != "none":
        g = gates["bull" if cat in ("buy", "bull") else "bear"]
        miss = [k for k, v in g.items() if not v]
        if miss:
            gate_note = f"出现{cat_sig}，但 {'、'.join(miss)} 不满足{'看多' if cat in ('buy', 'bull') else '看空'}条件，不列入"
            cat, cat_sig = "none", ""
    if gate_note: why.insert(0, gate_note)
    if cat != "none":
        g = gates["bull" if cat in ("buy", "bull") else "bear"]
        why.insert(0, "满足形态+动能：" + "；".join(f"{k}={'、'.join(v)}" for k, v in g.items()))
    if cat in ("bull", "caution"):
        conds = [f"价格{where}" + (f"（{r(zl)}–{r(zh)}）" if zs else "")]
        if cat == "bull":
            if mom == "绿柱连续缩短，下跌动能衰减": conds.append("MACD 绿柱连续缩短")
            if (macd_bc or "").startswith("底背驰"): conds.append("MACD 底背驰")
            conds.append("当前笔向下（回踩中）" if not bi_up else "当前笔向上")
        else:
            if mom == "红柱连续缩短，上涨动能衰减": conds.append("MACD 红柱连续缩短")
            if (macd_bc or "").startswith("顶背驰"): conds.append("MACD 顶背驰")
            conds.append("当前笔向上（反抽中）" if bi_up else "当前笔向下")
        conds.append(f"{'站上' if C > ma20 else '低于'} MA20")
        why.insert(1, "结构条件：" + "；".join(conds))
    elif cat in ("buy", "bear"): why.insert(1, "已确认" + ("买点" if cat == "buy" else "卖点") + "：" + cat_sig)
    if cand_note: why = [("出现候选%s（未确认：%s）" % (bsp_cn(lb["type"], lb["buy"]), cand_note.split("，")[0])) if ("站稳" in w and "根前出现" in w) else w for w in why]
    VIEW = {"buy": "看多", "bull": "看多", "bear": "看空", "caution": "谨慎", "none": "观望"}
    if cat not in ("bull", "caution"): pending = ""
    view = VIEW[cat] + ("·待确认" if pending else ""); buy_now = cat == "buy"
    if cat == "bull" and not entry: entry = zh if "三买" in cat_sig else (zl if zl and abs(zl / C - 1) <= 0.3 else entry)
    # 操作建议：空仓 / 持仓两种视角（与首页同源）
    if cat == "buy": af, wf = ("追涨试仓" if "3" in str(lb["type"]) else "买入" if "2" in str(lb["type"]) else "首次买入"), f"{cat_sig}；守 {r(stop) if stop else '最近笔低点'}"
    elif pending == "buy": af, wf = "等背驰确认", f"{cat_sig}：形态已成立、笔已走完，但该笔 MACD 面积不小于前一同向笔，背驰未成立；等背驰确认，不列推荐买入"
    elif pending == "sell": af, wf = "谨慎·等背驰确认", f"{cat_sig}：笔已走完但背驰未成立，等背驰确认"
    elif cat == "bull": af, wf = "等买点", f"{cat_sig}，买点出现并确认后再进" + (f"，参考 {r(entry)}" if entry else "")
    elif cat == "bear": af, wf = "回避", f"{cat_sig}"
    elif cat == "caution": af, wf = "谨慎", f"{cat_sig}，不追高"
    else: af, wf = "观望", (gate_note if gate_note else "没有已确认买卖点，也没有预判结构：" + "；".join(why[:2]))
    if broke: ah, wh = "止损离场", f"现价 {r(C)} 跌破结构失效 {r(stop)}"
    elif cat == "bear": ah, wh = "减仓 / 离场", cat_sig
    elif cat == "caution": ah, wh = "减仓 / 止盈", cat_sig
    elif target and C >= target * 0.98: ah, wh = "接近落袋位", f"距落袋位 {r(target)} 不到 2%，可分批止盈"
    else: ah, wh = "持有", f"结构未破，守 {r(stop) if stop else '最近笔低点'}"
    _lv = {"day": "日线", "30m": "30分"}.get(period, period)
    sell_basis = f"卖出依据（{_lv}级别）：{_lv}买点按{_lv}卖点 / 失效位止损 / {_lv}走势结束卖出" + ("，不做日内操作；30 分向下笔属小级别回调，不因此卖出" if period == "day" else "")
    wh = wh + "｜" + sell_basis
    signal = (bsp_cn(lb["type"], lb["buy"]) + "（候选，未确认）") if cand_note else (bsp_cn(lb["type"], lb["buy"]) + (("站稳" if C >= lb["y"] else "未站稳") if lb["buy"] else ("压制中" if C <= lb["y"] else "已突破"))) if lb else "无近期信号"
    tags = ([mom.split("，")[-1]] if mom else []) + [trend, where, "线段" + ("向上" if seg_up else "向下"), "当前笔" + ("向上" if bi_up else "向下"), mc, "站上 MA20" if C > ma20 else "MA20 下方"]
    if macd_bc: tags.append(macd_bc[:3])
    if lbc and n - 1 - lbc["x"] <= 10: tags.append("近期" + lbc["t"])
    return {"period": period, "cat": cat, "cat_sig": cat_sig, "dir": 1 if cat in ("buy", "bull") else -1 if cat in ("bear", "caution") else 0, "view": view, "buy_now": buy_now, "signal": signal, "main_sig": (cat_sig if cat != "none" else (gate_note or "无（未满足形态+动能，观望）")), "last_sig": ((bsp_cn(prior_ok[-1]["type"], prior_ok[-1]["buy"]) + " · " + T[prior_ok[-1]["x"]][:16]) if prior_ok else "近 60 根无已确认买卖点") if cand_note else ((signal + " · " + T[lb["x"]][:16]) if lb else "近 60 根无已确认买卖点"), "cand_sig": cand_sig, "pending": pending, "cand_kind": ("pending" if pending else "unfinished" if "未完成" in cand_note else "nodiv" if cand_note else ""), "pre_cat": pre_cat, "gate_note": gate_note, "gates": {d: {k: v for k, v in g.items()} for d, g in gates.items()}, 
            "signal_time": T[lb["x"]] if lb else None, "signal_age": age if lb else None, "reasons": why,
            "sell_basis": sell_basis, "bi_up": bi_up, "bc_strength": bc_strength, "price": r(C), "date": T[-1], "entry": r(entry), "target": r(target), "stop": r(stop), "where": where, "trend": trend,
            "seg_dir": "向上" if seg_up else "向下", "bi_dir": "向上" if bi_up else "向下", "bi_sure": bool(bi and bi["sure"]),
            "macd": mc, "macd_bc": macd_bc, "ma20": r(ma20), "bc": bc, "tags": tags,
            "rr": r((target - C) / (C - stop)) if (target and stop and C > stop) else None, "momentum": mom, "level_note": level_note,
            "last_bsp_all": lb_all, "last_bsp_age_all": (n - 1 - lb_all["x"]) if lb_all else None,
            "act_flat": af, "why_flat": wf, "act_hold": ah, "why_hold": wh,
            "last_bsp": lb, "last_buy": last_buy, "zs": zs, "rules": RULES}

def summarize(df, res):
    return analyze(df, res, "day")

# ---------- 后台预计算 ----------
_state = {"running": False, "last": None}
NAME_FN = None
US_CN_FN = None
def watch_codes(db_path):
    con = sqlite3.connect(db_path)
    rows = con.execute("SELECT market, code, MAX(name) FROM watch WHERE market IN ('a','us') GROUP BY market, code").fetchall()
    try:  # 用户收藏也纳入每日计算/冻结
        hv = {(m, str(c).upper()) for m, c, _ in rows}
        for m, c, n in con.execute("SELECT market, code, MAX(name) FROM fav WHERE market IN ('a','us') GROUP BY market, code").fetchall():
            if (m, str(c).upper()) not in hv: rows.append((m, c, n)); hv.add((m, str(c).upper()))
    except Exception as e: print("fav 读取失败", e, flush=True)
    con.close()
    # 搜索首页推荐模块里的票也纳入每日计算/冻结（data/search_picks.json）
    try:
        have = {(m, str(c).upper()) for m, c, _ in rows}
        P = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "search_picks.json")))
        for g in P.get("groups") or []:
            for c in g.get("codes") or []:
                if (g["market"], str(c).upper()) not in have: rows.append((g["market"], str(c).upper(), None)); have.add((g["market"], str(c).upper()))
    except Exception as e: print("search_picks 读取失败", e, flush=True)
    return rows

def rank_key(x):
    """推荐排序：按顺序比较缠论条件（非加权）：买卖点类型 三类>二类/类二>一类；距今根数小者先；现价距买卖点近者先；背驰力度大者先"""
    lb = x.get("last_bsp") or {}; t = str(lb.get("type", ""))
    tr = 0 if "3" in t else 1 if "2" in t else 2
    age = x.get("signal_age") if x.get("signal_age") is not None else 999
    y = float(lb.get("y") or 0); C = float(x.get("price") or 0)
    dist = abs(C - y) / y if y else 9
    return (tr, age, dist, -(x.get("bc_strength") or 0))
def rank_line(x):
    lb = x.get("last_bsp") or {}; t = str(lb.get("type", ""))
    tn = ("三" if "3" in t else "二" if "2" in t else "一") + ("买" if lb.get("buy") else "卖")
    y = float(lb.get("y") or 0); C = float(x.get("price") or 0); bc = x.get("bc_strength")
    return "排名依据：%s · %s根前 · 距%s点 %+.1f%% · 背驰%s" % (tn, x.get("signal_age"), "买" if lb.get("buy") else "卖", (C / y - 1) * 100 if y else 0, ("面积缩小 %d%%" % round(bc * 100)) if (bc is not None and bc > 0) else "无（面积未缩小）" if bc is not None else "—")
def tf30_note(c30):
    if not c30: return None
    if c30.get("cat") == "na" or "bi_up" not in c30: return "30分参考：取不到"
    return "30分参考：" + ("向上笔" if c30["bi_up"] else "向下笔") + ("，预判买点" if c30.get("cat") == "bull" else "，已确认买点" if c30.get("cat") == "buy" else "，预判卖点" if c30.get("cat") == "caution" else "，已确认卖点" if c30.get("cat") == "bear" else "")

ALERTS = os.path.join(BASE, "data", "alerts.json")
def read_alerts():
    try: return json.load(open(ALERTS))
    except Exception: return []
def make_alerts(mk, fz, prev):
    """收盘冻结后：后验=当天新确认的日线买/卖点；预判=当天新进入预判买/卖点（上一版不是同类）。只记新增，不重复。"""
    A = read_alerts(); seen = {(a["market"], a["code"], a["kind"], a["signal"]) for a in A}
    pc = {x["code"]: x.get("cat") for x in (prev or {}).get("items", [])} if prev else None
    new = []
    for x in fz["items"]:
        c = x.get("cat")
        if c in ("buy", "bear") and x.get("signal_age") == 0: kind = "后验"
        elif c in ("bull", "caution") and pc is not None and pc.get(x["code"]) != c: kind = "预判"
        else: continue
        g = (x.get("gates") or {}).get("bull" if c in ("buy", "bull") else "bear", {})
        a = {"market": mk, "session": fz["session"], "for_date": fz["for_date"], "kind": kind, "side": "买" if c in ("buy", "bull") else "卖",
             "code": x["code"], "name": x.get("name"), "signal": x.get("cat_sig"), "shape": g.get("形态", []), "dyn": g.get("动能", []),
             "price": x.get("price"), "entry": x.get("entry"), "stop": x.get("stop"), "target": x.get("target"), "added_bj": fz["computed_bj"]}
        if (mk, a["code"], kind, a["signal"]) in seen: continue
        seen.add((mk, a["code"], kind, a["signal"])); new.append(a)
    A = (new + A)[:2000]
    tmp = ALERTS + ".tmp"; json.dump(A, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, ALERTS)
    print("alerts", mk, fz["session"], len(new), flush=True)

def run_batch(load, compute, db_path, pause=0.6):
    if _state["running"]: return
    _state["running"] = True; t0 = time.time(); items, errs = [], 0
    try:
        rows = watch_codes(db_path)
        if US_CN_FN: US_CN_FN([c for m, c, _ in rows if m == "us"])  # 一次性批量取中文名
        for mk, code, name in rows:
            try:
                df, cached = load(mk, code, "day", futu="used")  # 不占新的富途历史K线额度
                s = summarize(df, compute(df, mk, code, "day"))
                s["tf"] = {"day": {"cat": s["cat"], "sig": s["cat_sig"] or s["signal"], "dir": s["dir"]}}
                if s["dir"] != 0:  # 只对日线有信号/预判的股票再算分钟级（不占新的富途额度，交易时段缓存 60 秒）
                    for per in ("30m",):
                        try:
                            dm, cm = load(mk, code, per, futu="used")
                            am = analyze(dm, compute(dm, mk, code, per), per)
                            s["tf"][per] = {"cat": am["cat"], "sig": am["cat_sig"] or am["signal"], "dir": am["dir"], "bi_up": am.get("bi_up")}
                            if not cm: time.sleep(pause)
                        except Exception as e: s["tf"][per] = {"cat": "na", "sig": "取不到（" + str(getattr(e, "detail", e))[:30] + "）", "dir": 0}
                same = [p for p, v in s["tf"].items() if v["dir"] == s["dir"] and s["dir"] != 0]
                s["reso"] = len(same); s["reso_tf"] = same
                nm = (NAME_FN(mk, code) if (NAME_FN and mk == "a") else (US_CN_FN([code]).get(code.upper()) if US_CN_FN else None)) or name or code
                s.update(market=mk, code=code, name=nm, stale=bool(df.attrs.get("stale")))
                items.append(s)
                if not cached: time.sleep(pause)  # 新拉取时节流，避免富途/新浪限流
            except Exception as e:
                errs += 1; print("summary 失败", mk, code, str(e)[:80], flush=True)
        freeze_reso(items)
        R = read_reso()
        from market_hours import is_trading
        for s in items:  # 只看日线：30 分不再是门槛，只留一句参考标签
            s["tf30_note"] = tf30_note(s.get("tf", {}).get("30m"))
        freeze_home(items, time.time() - t0)
        out = {"updated": time.time(), "took": round(time.time() - t0), "count": len(items), "errors": errs, "rules": RULES, "items": items}
        tmp = OUT + ".tmp"; json.dump(out, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, OUT)
        _state["last"] = time.time()
    finally: _state["running"] = False

RESO = os.path.join(BASE, "data", "reso.json")
FROZEN = os.path.join(BASE, "data", "home_frozen.json")
def _due(mk, session):
    """该交易日的收盘冻结时刻已到，且数据里确有这一天（假日/休市日数据不会出现新日期 → 不重算，沿用上一版）"""
    from market_hours import due_session
    d = due_session(mk)
    return d is not None and session == d.isoformat()
def freeze_home(items, took):
    from market_hours import SH
    import datetime as dt
    F = read_frozen()
    for mk in ("a", "us"):
        xs = [x for x in items if x["market"] == mk]
        if not xs: continue
        session = max(x["date"][:10] for x in xs)
        if not _due(mk, session) or F.get(mk, {}).get("session") == session: continue
        prev = F.get(mk)
        F[mk] = {"session": session, "for_date": next_weekday(session), "computed_bj": dt.datetime.now(SH).strftime("%Y-%m-%d %H:%M"),
                 "updated": time.time(), "errors": 0, "items": xs}
        print("home frozen", mk, session, len(xs), flush=True)
        sync_reso_from(mk, F[mk])
        try: make_alerts(mk, F[mk], prev)
        except Exception as e: print("alerts 失败", mk, e, flush=True)
    tmp = FROZEN + ".tmp"; json.dump(F, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, FROZEN)
REVIEW_F = os.path.join(BASE, "data", "open_review.json")
def read_review():
    try: return json.load(open(REVIEW_F))
    except Exception: return {}
def open_review(load, compute, mk):
    """开盘复核：只查冻结版中推荐买入/看多，不改日线结论。须在连续竞价时段内（竞价、盘前不判）。"""
    from market_hours import is_trading, today_local, review_at, SH
    import datetime as dt
    now = dt.datetime.now(dt.timezone.utc); d = today_local(mk, now)
    F = read_frozen().get(mk); V = read_review()
    if not F or F.get("for_date") != d.isoformat() or now < review_at(mk, d) or not is_trading(mk): return
    if V.get(mk, {}).get("for_date") == d.isoformat(): return
    tags = {}
    for x in F["items"]:
        if x.get("cat") not in ("buy", "bull"): continue
        try:
            df, _ = load(mk, x["code"], "day", futu="used"); C = float(df["close"].iloc[-1])
            t = []
            if x.get("stop") is not None and C < float(x["stop"]): t.append("开盘复核：跳空破位，放弃")
            lb = x.get("last_bsp")
            if lb and lb.get("buy") and C > float(lb["y"]) * 1.08: t.append("开盘复核：已远离，不追")
            if t: tags[x["code"]] = {"tags": t, "price": round(C, 3)}
        except Exception as e: print("open_review", mk, x["code"], str(e)[:60], flush=True)
    V[mk] = {"for_date": d.isoformat(), "time_bj": dt.datetime.now(SH).strftime("%Y-%m-%d %H:%M"), "items": tags}
    tmp = REVIEW_F + ".tmp"; json.dump(V, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, REVIEW_F)
    print("open review", mk, d, len(tags), flush=True)
def sync_reso_from(mk, fz):
    """共振结果与首页冻结版同一批：用冻结版条目覆盖 reso.json 中该市场（避免两次冻结时间不同造成分区与结论矛盾）"""
    try: R = json.load(open(RESO))
    except Exception: R = {}
    R[mk] = {"session": fz["session"], "for_date": fz["for_date"], "computed_bj": fz["computed_bj"],
             "items": {x["code"]: {"dir": x["dir"], "reso": x.get("reso", 0), "tf": x.get("tf", {})} for x in fz["items"]}}
    tmp = RESO + ".tmp"; json.dump(R, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, RESO)
def read_frozen():
    try: return json.load(open(FROZEN))
    except Exception: return {}
def next_weekday(d):
    import datetime as dt
    x = dt.date.fromisoformat(d) + dt.timedelta(days=1)
    while x.weekday() >= 5: x += dt.timedelta(days=1)
    return x.isoformat()

def freeze_reso(items):
    """收盘后（该市场非交易时段且已有当日日线）把日线+30分共振固定下来，作为下一交易日开盘的操作参考；盘中不覆盖。"""
    from market_hours import is_trading, SH
    import datetime as dt
    try: R = json.load(open(RESO))
    except Exception: R = {}
    for mk in ("a", "us"):
        xs = [x for x in items if x["market"] == mk]
        if not xs: continue
        session = max(x["date"][:10] for x in xs)
        if not _due(mk, session): continue
        if R.get(mk, {}).get("session") == session: continue
        # 美股：北京时间凌晨收盘；A 股：15:00 收盘。只在收盘后的窗口内冻结（A 股 15:05 之后、美股收盘之后）
        R[mk] = {"session": session, "for_date": next_weekday(session),
                 "computed_bj": dt.datetime.now(SH).strftime("%Y-%m-%d %H:%M"),
                 "items": {x["code"]: {"dir": x["dir"], "reso": x.get("reso", 0), "tf": x.get("tf", {})} for x in xs}}
    tmp = RESO + ".tmp"; json.dump(R, open(tmp, "w"), ensure_ascii=False); os.replace(tmp, RESO)

def read_reso():
    try: return json.load(open(RESO))
    except Exception: return {}

def start_loop(load, compute, db_path, every=1800):
    def loop():
        time.sleep(20)
        while True:
            for _m in ("a", "us"):  # 先做开盘复核（到点即做，不等整批重算），再跑批
                try: open_review(load, compute, _m)
                except Exception as e: print("open review", _m, e, flush=True)
            try: run_batch(load, compute, db_path)
            except Exception as e: print("summary loop", e, flush=True)
            try: after_close_jobs()
            except Exception as e: print("after close", e, flush=True)
            # 下一次冻结时刻到了就提前醒来（+90 秒，确保收盘数据已落盘）
            from market_hours import next_freeze
            import datetime as dt
            now = dt.datetime.now(dt.timezone.utc)
            from market_hours import next_review
            wait = min([every] + [(next_freeze(m, now) - now).total_seconds() + 90 for m in ("a", "us")] + [(next_review(m, now) - now).total_seconds() + 5 for m in ("a", "us")])
            time.sleep(max(60, wait))
    threading.Thread(target=loop, daemon=True, name="summary").start()

def read():
    try: return json.load(open(OUT))
    except Exception: return None


def is_bj(code):
    c = str(code)
    return c[:1] in ("4", "8") or c[:2] == "92"


_JOBS = {}
def after_close_jobs():
    """A 股冻结后：板块资金（新浪，全日）+ 全市场扫描（子进程，约 60–70 分钟）"""
    import subprocess, datetime as dt
    F = read_frozen().get("a") or {}; ses = F.get("session")
    if not ses: return
    now = dt.datetime.now()
    if now.strftime("%Y-%m-%d") != ses or now.hour * 60 + now.minute < 15 * 60 + 5: return
    sf = os.path.join(BASE, "data", "sector_flow_a.json")
    try: SF = json.load(open(sf))
    except Exception: SF = {}
    if not (SF.get("date") == ses and SF.get("final")) and _JOBS.get("sector") != ses:
        _JOBS["sector"] = ses
        subprocess.Popen([os.path.join(BASE, ".venv/bin/python"), "scan/sector_flow_sina.py"], cwd=BASE, stdout=open(os.path.join(BASE, "scan/sector_daily.log"), "a"), stderr=subprocess.STDOUT)
    try: MF = json.load(open(os.path.join(BASE, "data", "market_frozen_a.json")))
    except Exception: MF = {}
    p = _JOBS.get("market")
    lockf = os.path.join(BASE, "scan", "market_daily.lock")
    running = False
    try:
        pid = int(open(lockf).read().split()[0]); os.kill(pid, 0); running = True
    except Exception: running = False
    if MF.get("session") != ses and not running and (p is None or p.poll() is not None) and _JOBS.get("market_ses") != ses:
        _JOBS["market_ses"] = ses
        _JOBS["market"] = subprocess.Popen(["/bin/bash", "scan/market_daily.sh", ses], cwd=BASE, start_new_session=True)
        open(lockf, "w").write("%d %s" % (_JOBS["market"].pid, ses))
        print("market scan started", ses, flush=True)
    # 日内参考：交易时段每 20 分钟刷新自选；收盘后再跑一版落盘
    try:
        import datetime as _dt
        now=_dt.datetime.now(); key=now.strftime("%Y%m%d%H")+str(now.minute//20)
        from market_hours import is_trading
        if (is_trading("a") or is_trading("us") or now.hour*60+now.minute>=15*60+5) and _JOBS.get("intra_key")!=key:
            p=_JOBS.get("intra")
            if p is None or p.poll() is not None:
                _JOBS["intra_key"]=key
                _JOBS["intra"]=subprocess.Popen([os.path.join(BASE,".venv/bin/python"),"scan/intraday_ref.py"],cwd=BASE,stdout=open(os.path.join(BASE,"scan/intraday_ref.log"),"a"),stderr=subprocess.STDOUT)
    except Exception as e: print("intraday ref", e, flush=True)
