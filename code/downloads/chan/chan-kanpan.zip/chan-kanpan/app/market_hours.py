"""交易时段判断（工作日，不含节假日）。CHAN_FAKE_TRADING=a,us 可强制模拟交易时段。"""
import os, datetime as dt
from zoneinfo import ZoneInfo
SH, NY = ZoneInfo("Asia/Shanghai"), ZoneInfo("America/New_York")
def is_trading(market, now=None):
    fake = os.environ.get("CHAN_FAKE_TRADING", "")
    if market in fake.split(","): return True
    now = now or dt.datetime.now(dt.timezone.utc)
    if market == "a":
        t = now.astimezone(SH)
        if t.weekday() >= 5: return False
        hm = t.hour * 60 + t.minute
        return 570 <= hm < 690 or 780 <= hm < 900
    if market == "us":
        t = now.astimezone(NY)
        if t.weekday() >= 5: return False
        hm = t.hour * 60 + t.minute
        return 570 <= hm < 960
    return False
TRADING_TTL = 60
def bj_hm(ts): return dt.datetime.fromtimestamp(ts, SH).strftime("%H:%M")

# ---------- 收盘后冻结时间（A股 15:30 北京；美股 16:30 美东，自动处理夏令时）----------
FREEZE = {"a": (SH, 15, 30), "us": (NY, 16, 30)}
def freeze_at(market, d):
    """d: 该市场本地交易日 date → 冻结时刻（aware datetime）"""
    tz, h, m = FREEZE[market]
    return dt.datetime(d.year, d.month, d.day, h, m, tzinfo=tz)
def due_session(market, now=None):
    """最近一个已到冻结时刻的工作日（市场本地日期）"""
    now = now or dt.datetime.now(dt.timezone.utc)
    tz = FREEZE[market][0]; d = now.astimezone(tz).date()
    for _ in range(10):
        if d.weekday() < 5 and freeze_at(market, d) <= now: return d
        d -= dt.timedelta(days=1)
def next_freeze(market, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    tz = FREEZE[market][0]; d = now.astimezone(tz).date()
    for _ in range(10):
        if d.weekday() < 5 and freeze_at(market, d) > now: return freeze_at(market, d)
        d += dt.timedelta(days=1)

# ---------- 开盘复核时间（A股 9:40 北京；美股 9:40 美东，自动处理夏令时）----------
REVIEW = {"a": (SH, 9, 40), "us": (NY, 9, 40)}
def review_at(market, d):
    tz, h, m = REVIEW[market]
    return dt.datetime(d.year, d.month, d.day, h, m, tzinfo=tz)
def today_local(market, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.astimezone(REVIEW[market][0]).date()
def next_review(market, now=None):
    now = now or dt.datetime.now(dt.timezone.utc)
    d = today_local(market, now)
    for _ in range(10):
        if d.weekday() < 5 and review_at(market, d) > now: return review_at(market, d)
        d += dt.timedelta(days=1)
