"""缠论站本地版（MacBook）。行情只读：富途 OpenD request_history_kline（带 start/end），不含任何交易接口。
首页主推荐＝线上缠论站同一套 summary.analyze 日线模型（推荐买入/看多/看空/谨慎）；strategy_v1 仅作次要参考。
回测＝按同一套买卖点规则回放单票历史。"""
import os, sys, time, json, threading, datetime as dt, re
from zoneinfo import ZoneInfo
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE = os.path.dirname(os.path.abspath(__file__))
CHAN_DIR = os.path.join(BASE, "chanpy")
sys.path.insert(0, CHAN_DIR); sys.path.insert(0, BASE)
from Chan import CChan
from ChanConfig import CChanConfig
from Common.CEnum import AUTYPE, DATA_SRC, KL_TYPE
from Plot.PlotMeta import CChanPlotMeta
import summary as SUM

CACHE = os.path.join(BASE, "cache"); os.makedirs(CACHE, exist_ok=True)
SEED = json.load(open(os.path.join(BASE, "data", "seed.json")))
NAMES_DB = json.load(open(os.path.join(BASE, "data", "names.json")))
FROZEN_PATH = os.path.join(BASE, "data", "local_frozen.json")
SH, NY, HK = ZoneInfo("Asia/Shanghai"), ZoneInfo("America/New_York"), ZoneInfo("Asia/Hong_Kong")
SESS = {"a": (SH, [(570, 690), (780, 900)]), "hk": (HK, [(570, 720), (780, 960)]), "us": (NY, [(570, 960)])}
PERIODS = {"day": (KL_TYPE.K_DAY, 1200), "30m": (KL_TYPE.K_30M, 60), "5m": (KL_TYPE.K_5M, 40)}
TTL = 15; FUTU_RESERVE = 30
TIER = {"us": "美股档位「谨慎」，GPT 美股稿今日不买", "a": "A股 GPT 收盘稿：不开新仓", "hk": "港股无档位规则"}
CAT_CN = {"buy": "推荐买入", "bull": "看多", "bear": "看空", "caution": "谨慎", "none": "观望"}

# ---- 名称 / 备注 ----
META = {}  # (m,c) -> {n,en,cn,note,sector,biz}
for it in NAMES_DB["items"]:
    META[(it["m"], it["c"].upper() if it["m"] == "us" else it["c"])] = it
INDUS = {}; NAMES = {}
for mk in SEED["groups"]:
    for g in mk["groups"]:
        for it in g["items"]:
            c = it["c"].upper() if mk["m"] == "us" else it["c"]
            INDUS[(mk["m"], c)] = g["name"]
            mt = META.get((mk["m"], c))
            NAMES[(mk["m"], c)] = (mt["n"] if mt and mt.get("n") else it["n"])

def _fmt_name(m, c0, en="", cn=""):
    """美股：英文名/简称（中文）；A/港：只用中文。"""
    cn = cn if cn and re.search(r"[\u4e00-\u9fff]", str(cn)) else ""
    en = (en or "").strip()
    if m == "us":
        base = en or c0
        return f"{base}（{cn}）" if cn else base
    return cn or c0

def _fmt_note(sector="", biz=""):
    sector = (sector or "").strip() or "未知"
    biz = (biz or "").strip() or "未知"
    return f"板块：{sector}；业务：{biz}"

A_INDEX_NAMES = {"SH.000001": "上证综指", "SH.000688": "科创 50", "SZ.399006": "创业板指", "SH.000905": "中证 500"}


def stock_meta(m, c):
    if m == "a" and c in A_INDEX_NAMES:
        name = A_INDEX_NAMES[c]
        return {"name": name, "en": c, "cn": name, "note": "指数行情来自富途 OpenD", "sector": "指数", "biz": name}
    c0 = c.upper() if m == "us" else c
    sp = SPECIAL.get(c0) if m == "us" and "SPECIAL" in globals() else None
    if sp: return {"name": sp[2] + "（" + c0 + "）", "en": c0, "cn": sp[2], "note": "指数/期货，数据来自新浪（未经富途核验）", "sector": "指数/期货", "biz": sp[2]}
    mt = META.get((m, c0)) or {}
    en = mt.get("en") or ""
    cn = mt.get("cn") or ""
    sector = mt.get("sector") or INDUS.get((m, c0), "") or ""
    biz = mt.get("biz") or ""
    # A/港备注优先中文；纯英文业务改标未知，避免备注里冒英文
    if m != "us":
        if biz and not re.search(r"[\u4e00-\u9fff]", str(biz)):
            biz = "未知"
        if sector and not re.search(r"[\u4e00-\u9fff]", str(sector)):
            sector = INDUS.get((m, c0), "") or "未知"
    n = _fmt_name(m, c0, en, cn)
    note = _fmt_note(sector, biz)
    return {"name": n, "en": en, "cn": cn, "note": note, "sector": sector or "未知", "biz": biz or "未知"}


_ST_RE = re.compile(r"^(?:S\*ST|\*ST|SST|ST)[\u4e00-\u9fff\*]")

def is_st_name(name):
    """A股 ST/*ST/S*ST 等风险警示名称；英文名里碰巧含 ST 的美股不算。"""
    return bool(_ST_RE.match(str(name or "").strip()))

def display_name(m, c):
    return stock_meta(m, c)["name"]

def set_name(m, c, cn=None, en=None, sector=None, biz=None):
    """运行时补中文名 / 板块 / 业务（富途/新浪拉取后写回）。"""
    c0 = c.upper() if m == "us" else c
    mt = META.get((m, c0)) or {"m": m, "c": c0, "en": "", "cn": "", "n": c0,
                                "note": "", "sector": INDUS.get((m, c0), "") or "", "biz": ""}
    if en: mt["en"] = en
    if cn and re.search(r"[\u4e00-\u9fff]", cn):
        mt["cn"] = cn
    if sector: mt["sector"] = sector
    if biz: mt["biz"] = biz
    if not mt.get("sector"): mt["sector"] = INDUS.get((m, c0), "") or ""
    mt["n"] = _fmt_name(m, c0, mt.get("en") or "", mt.get("cn") or "")
    mt["note"] = _fmt_note(mt.get("sector"), mt.get("biz"))
    META[(m, c0)] = mt; NAMES[(m, c0)] = mt["n"]

def persist_names():
    try:
        items = list(META.values())
        miss = [{"m": m, "c": c, "en": v.get("en")} for (m, c), v in META.items() if m != "us" and not (v.get("cn") and re.search(r"[\u4e00-\u9fff]", v["cn"])) or (m == "us" and not (v.get("cn") and re.search(r"[\u4e00-\u9fff]", str(v.get("cn") or ""))))]
        # fix miss comprehension
        miss = []
        for (m, c), v in META.items():
            has = v.get("cn") and re.search(r"[\u4e00-\u9fff]", str(v["cn"]))
            if not has: miss.append({"m": m, "c": c, "en": v.get("en")})
        json.dump({"items": items, "missing": miss}, open(os.path.join(BASE, "data", "names.json"), "w"), ensure_ascii=False)
    except Exception as e:
        print("persist_names", e, flush=True)

# ---- strategy_v1 次要 ----
SV1_KEYS = list(SEED["gate"].keys())
GATE = dict(SEED["gate"])

def bj(ts=None): return dt.datetime.fromtimestamp(ts or time.time(), SH).strftime("%m-%d %H:%M:%S")
def bj_full(ts=None): return dt.datetime.fromtimestamp(ts or time.time(), SH).strftime("%Y-%m-%d %H:%M:%S")

def is_trading(m, now=None):
    tz, ss = SESS[m]; t = (now or dt.datetime.now(dt.timezone.utc)).astimezone(tz)
    if t.weekday() >= 5: return False
    hm = t.hour * 60 + t.minute; return any(a <= hm < b for a, b in ss)

def futu_code(m, c):
    if m == "a" and c in A_INDEX_NAMES: return c
    if m == "a": return ("SH." if c[0] in "659" else "BJ." if c[0] in "48" else "SZ.") + c
    if m == "hk": return "HK." + str(int(c)).zfill(5)
    u = c.upper()
    return "US." + (u[:-4] + "main" if u.endswith("MAIN") else u)

_flock = threading.Lock(); _last_req = [0.0]; _quota = {"t": 0, "remain": 0, "used": set()}
_user_wait = [0]  # >0 时后台刷新让路
_ctx = {"q": None}
_chan_cache = {}  # (m,c,period,mtime,len) -> res
_ana_cache = {}   # (m,c,period,mtime,len) -> analysis
_bg_refreshing = set()
_bg_lock = threading.Lock()

def clean_code(c):
    """去掉误拼进代码的周期后缀（历史 bug：us_NVDA_day.csv 被拆成 NVDA_day）。"""
    c = str(c or "").strip()
    c2 = re.sub(r"_(day|30m|5m)$", "", c, flags=re.I)
    return c2

def parse_cache_name(fn):
    m = re.match(r"^(a|us|hk)_(.+)_(day|30m|5m)\.csv$", fn)
    return (m.group(1), m.group(2), m.group(3)) if m else None

def _get_ctx():
    from futu import OpenQuoteContext
    if _ctx["q"] is None:
        _ctx["q"] = OpenQuoteContext(host="127.0.0.1", port=11111)
    return _ctx["q"]

def _reset_ctx():
    try:
        if _ctx["q"] is not None: _ctx["q"].close()
    except Exception: pass
    _ctx["q"] = None

# 指数 / 期货：富途不支持（美股指数无权限、ESmain/NQmain 无行情权限），改走新浪免费数据，不占富途历史K额度
SPECIAL = {"SPX": ("index", ".inx", "标普500指数"), ".SPX": ("index", ".inx", "标普500指数"), "INX": ("index", ".inx", "标普500指数"),
           "IXIC": ("index", ".ixic", "纳斯达克综合指数"), ".IXIC": ("index", ".ixic", "纳斯达克综合指数"),
           "DJI": ("index", ".dji", "道琼斯工业指数"), ".DJI": ("index", ".dji", "道琼斯工业指数"),
           "NQ": ("fut", "NQ", "纳指期货主力"), "NQMAIN": ("fut", "NQ", "纳指期货主力"),
           "ES": ("fut", "ES", "标普期货主力"), "ESMAIN": ("fut", "ES", "标普期货主力")}
def _special(m, c): return SPECIAL.get(str(c).upper()) if m == "us" else None
def _sina_rows(url):
    import requests
    t = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn/"}).text
    a = t.find("(["); b = t.rfind("])")
    return json.loads(t[a + 1:b + 1]) if a >= 0 and b > a else []
def fetch_sina_special(c, period):
    kind, sym, _ = SPECIAL[str(c).upper()]
    def mins(t):
        if kind == "index": u = f"https://stock.finance.sina.com.cn/usstock/api/jsonp_v2.php/var%20_X=/US_MinKService.getMinK?symbol={sym}&type={t}&___qn=3"
        else: u = f"https://gu.sina.cn/ft/api/jsonp.php/var%20_X=/GlobalService.getMink?symbol={sym}&type={t}"
        df = pd.DataFrame([{"time": x["d"], "open": float(x["o"]), "high": float(x["h"]), "low": float(x["l"]), "close": float(x["c"]), "volume": float(x.get("v") or 0)} for x in _sina_rows(u)])
        if len(df):
            tt = pd.to_datetime(df["time"]); mid = (tt.dt.hour == 0) & (tt.dt.minute == 0)
            df["time"] = tt.where(~mid, tt - pd.Timedelta(seconds=1)).dt.strftime("%Y-%m-%d %H:%M:%S")
        return df
    if period != "day":
        df = mins({"30m": 30, "5m": 5}[period])
    elif kind == "fut":
        rows = _sina_rows(f"https://stock2.finance.sina.com.cn/futures/api/jsonp.php/var%20_X=/GlobalFuturesService.getGlobalFuturesDailyKLine?symbol={sym}&source=web")
        df = pd.DataFrame([{"time": x["date"], "open": float(x["open"]), "high": float(x["high"]), "low": float(x["low"]), "close": float(x["close"]), "volume": float(x.get("volume") or 0)} for x in rows])
    else:
        rows = _sina_rows(f"https://stock.finance.sina.com.cn/usstock/api/jsonp_v2.php/var%20_X=/US_MinKService.getDailyK?symbol={sym}&___qn=3")
        df = pd.DataFrame([{"time": x["d"], "open": float(x["o"]), "high": float(x["h"]), "low": float(x["l"]), "close": float(x["c"]), "volume": float(x.get("v") or 0)} for x in rows])
        try:
            mm = mins(30)
            if len(mm):
                mm["d"] = mm["time"].str[:10]; last = mm["d"].iloc[-1]
                if len(df) and last > str(df["time"].iloc[-1])[:10]:
                    g = mm[mm["d"] == last]
                    df = pd.concat([df, pd.DataFrame([{"time": last, "open": g["open"].iloc[0], "high": g["high"].max(), "low": g["low"].min(), "close": g["close"].iloc[-1], "volume": g["volume"].sum()}])], ignore_index=True)
        except Exception as e: print("指数补当日失败", c, str(e)[:80], flush=True)
    if not len(df): raise RuntimeError("新浪无数据")
    if period == "day": df = df.tail(PERIODS["day"][1])
    return df.reset_index(drop=True)

def fetch_futu(m, c, period, priority=False):
    if _special(m, c): return fetch_sina_special(c, period)
    from futu import RET_OK, KLType, AuType
    c = clean_code(c)
    kt = {"day": KLType.K_DAY, "30m": KLType.K_30M, "5m": KLType.K_5M}[period]
    start = (dt.date.today() - dt.timedelta(days=PERIODS[period][1])).isoformat()
    end = (dt.date.today() + dt.timedelta(days=1)).isoformat()
    fc = futu_code(m, c)
    # 后台任务：若有用户请求在等，短暂让路
    if not priority:
        for _ in range(40):
            if _user_wait[0] <= 0: break
            time.sleep(0.05)
    with _flock:
        if priority: _user_wait[0] += 1
        try:
            ctx = _get_ctx()
            try:
                if time.time() - _quota["t"] > 600:
                    ret, d = ctx.get_history_kl_quota(get_detail=True)
                    if ret == RET_OK: _quota.update(t=time.time(), remain=d[1], used={x["code"] for x in d[2]})
                if fc not in _quota["used"] and _quota["remain"] <= FUTU_RESERVE:
                    raise RuntimeError("富途历史K线额度不足（保留 %d）" % FUTU_RESERVE)
                parts, key = [], None
                for _ in range(6):
                    w = (0.35 if priority else 0.55) - (time.time() - _last_req[0])
                    if w > 0: time.sleep(w)
                    _last_req[0] = time.time()
                    ret, d, key = ctx.request_history_kline(fc, start=start, end=end, ktype=kt, autype=AuType.QFQ, max_count=1000, page_req_key=key)
                    if ret != RET_OK:
                        _reset_ctx(); raise RuntimeError(str(d)[:120])
                    parts.append(d)
                    if fc not in _quota["used"]: _quota["used"].add(fc); _quota["remain"] -= 1
                    if key is None: break
            except Exception:
                _reset_ctx(); raise
        finally:
            if priority and _user_wait[0] > 0: _user_wait[0] -= 1
    df = pd.concat(parts).rename(columns={"time_key": "time"})
    if not len(df): raise RuntimeError("富途无数据")
    df["time"] = df["time"].astype(str).str[:10 if period == "day" else 19]
    return df[["time", "open", "high", "low", "close", "volume"]].reset_index(drop=True)

def _bg_fetch(m, c, period):
    key = (m, c, period)
    with _bg_lock:
        if key in _bg_refreshing: return
        _bg_refreshing.add(key)
    try:
        p = os.path.join(CACHE, f"{m}_{c}_{period}.csv")
        fetch_futu(m, c, period, priority=False).to_csv(p, index=False)
    except Exception as e:
        print("bg_fetch", m, c, period, str(e)[:100], flush=True)
    finally:
        with _bg_lock: _bg_refreshing.discard(key)

_klocks = {}
def load(m, c, period, allow_fetch=True, priority=True):
    """有缓存则秒开；交易时段过期时后台刷新，不阻塞首屏。"""
    c = clean_code(c)
    p = os.path.join(CACHE, f"{m}_{c}_{period}.csv"); has = os.path.exists(p)
    with _klocks.setdefault((m, c, period), threading.Lock()):
        age = time.time() - os.path.getmtime(p) if has else 1e9
        stale = is_trading(m) and age > TTL
        need_blocking = (not has) and allow_fetch
        err = None
        if need_blocking:
            try:
                fetch_futu(m, c, period, priority=priority).to_csv(p, index=False); has = True
            except Exception as e:
                err = str(e)[:120]; print("futu 失败", m, c, period, err, flush=True)
        elif has and stale and allow_fetch:
            threading.Thread(target=_bg_fetch, args=(m, c, period), daemon=True).start()
            err = "后台刷新中" if age > TTL else None
        if not has: raise HTTPException(503, "暂无缓存，富途取数失败：" + (err or "休市未拉取"))
        df = pd.read_csv(p, dtype={"time": str}); df.attrs["mtime"] = os.path.getmtime(p); df.attrs["err"] = err
        df.attrs["from_cache"] = True
        return df

_clock = threading.Lock()
def _chan_disk(m, c, period):
    return os.path.join(CACHE, f"{m}_{c}_{period}.chan.json")

def _load_chan_disk(m, c, period, mt, n):
    dp = _chan_disk(m, c, period)
    if not os.path.exists(dp): return None
    try:
        obj = json.load(open(dp))
        if abs(float(obj.get("mtime") or 0) - float(mt)) < 0.01 and int(obj.get("n") or -1) == int(n) and isinstance(obj.get("res"), dict):
            return obj["res"]
    except Exception:
        pass
    return None

def _save_chan_disk(m, c, period, mt, n, res):
    try:
        json.dump({"mtime": float(mt), "n": int(n), "res": res}, open(_chan_disk(m, c, period), "w"), ensure_ascii=False)
    except Exception as e:
        print("chan_disk save", m, c, period, str(e)[:80], flush=True)

def compute(df, m, c, period):
    """内存 → 磁盘 .chan.json → 现算。有盘缓存则秒开，不挡首屏。"""
    c = clean_code(c)
    mt = float(df.attrs.get("mtime") or 0); n = len(df)
    ck = (m, c, period, mt, n)
    hit = _chan_cache.get(ck)
    if hit is not None: return hit
    disk = _load_chan_disk(m, c, period, mt, n)
    if disk is not None:
        _chan_cache[ck] = disk
        return disk
    kt = PERIODS[period][0]; df = df.copy()
    df["high"] = df[["open", "high", "low", "close"]].max(axis=1)
    df["low"] = df[["open", "high", "low", "close"]].min(axis=1)
    if kt != KL_TYPE.K_DAY:
        df["time"] = df["time"].astype(str).str[:16] + ":00"
    name = f"loc_{m}_{c.replace('.', '_')}_{period}"
    with _clock:
        # 二次检查，避免排队后重复算
        hit = _chan_cache.get(ck)
        if hit is not None: return hit
        disk = _load_chan_disk(m, c, period, mt, n)
        if disk is not None:
            _chan_cache[ck] = disk
            return disk
        csv = os.path.join(CHAN_DIR, f"{name}_{KL_TYPE(kt).name[2:].lower()}.csv")
        df[["time", "open", "high", "low", "close"]].to_csv(csv, index=False, float_format="%.4f")
        chan = CChan(code=name, begin_time=None, end_time=None, data_src=DATA_SRC.CSV, lv_list=[kt],
                     config=CChanConfig({"bi_strict": True, "bi_end_is_peak": False, "zs_algo": "normal", "print_warning": False, "trigger_step": False, "bsp2_follow_1": False, "bsp3_follow_1": False}), autype=AUTYPE.NONE)
        meta = CChanPlotMeta(chan[0])
    r = lambda v: round(float(v), 4)
    res = {"bi": [{"x0": b.begin_x, "y0": r(b.begin_y), "x1": b.end_x, "y1": r(b.end_y), "sure": b.is_sure} for b in meta.bi_list],
            "seg": [{"x0": s.begin_x, "y0": r(s.begin_y), "x1": s.end_x, "y1": r(s.end_y), "sure": s.is_sure} for s in meta.seg_list],
            "zs": [{"x0": z.begin, "x1": z.end, "low": r(z.low), "high": r(z.high), "sure": z.is_sure} for z in meta.zs_lst],
            "segzs": [{"x0": z.begin, "x1": z.end, "low": r(z.low), "high": r(z.high), "sure": z.is_sure} for z in meta.segzs_lst],
            "bsp": [{"x": p.x, "y": r(p.y), "buy": p.is_buy, "type": p.type} for p in meta.bs_point_lst],
            "times": meta.datetick}
    _chan_cache[ck] = res
    _save_chan_disk(m, c, period, mt, n, res)
    # 控制内存：超过 200 条清一半
    if len(_chan_cache) > 200:
        for i, k in enumerate(list(_chan_cache.keys())):
            if i >= 100: break
            _chan_cache.pop(k, None)
    return res

def analyze_cached(df, res, m, c, period):
    c = clean_code(c)
    mt = float(df.attrs.get("mtime") or 0); ck = (m, c, period, mt, len(df))
    hit = _ana_cache.get(ck)
    if hit is not None: return hit
    a = SUM.analyze(df, res, period)
    _ana_cache[ck] = a
    if len(_ana_cache) > 200:
        for i, k in enumerate(list(_ana_cache.keys())):
            if i >= 100: break
            _ana_cache.pop(k, None)
    return a

def gate_sv1(df, m):
    d = df.copy(); tz = SESS[m][0]
    if is_trading(m) and str(d["time"].iloc[-1])[:10] == dt.datetime.now(tz).date().isoformat(): d = d.iloc[:-1]
    d = d.reset_index(drop=True)
    if len(d) < 26: return None
    t = d.iloc[-1]; prev = d.iloc[-6:-1]; sw = float(prev["low"].min())
    ema = d["close"].astype(float).ewm(span=20, adjust=False).mean().iloc[-1]
    body = abs(t.close - t.open); lsh = min(t.open, t.close) - t.low
    ok = t.low <= sw and t.close > sw and (t.close > t.open or (lsh >= body and lsh > 0)) and t.close > ema
    return {"ok": bool(ok), "date": str(t.time)[:10], "close": round(float(t.close), 3), "sw": round(sw, 3), "low": round(float(t.low), 3), "ema": round(float(ema), 3), "yang": bool(t.close > t.open), "lsh": bool(lsh >= body and lsh > 0)}

def sv1_of(m, c):
    k = f"{m}_{c}"
    if k not in SV1_KEYS: return None
    g = GATE.get(k) or {}
    if not g.get("ok"):
        return {"verdict": "已不满足", "sig": "第二步门槛未通过", "why": "最新已收完 K 线不再满足假跌破收回", "date": g.get("date"), "stop": g.get("low"), "close": g.get("close"), "ema": g.get("ema")}
    sig = "假跌破收回" + ("+长下影" if g.get("lsh") and not g.get("yang") else "")
    return {"verdict": "观望", "sig": sig, "why": "第二步门槛通过，但 " + TIER[m] + "（次要参考，非首页主推荐）", **{x: g.get(x) for x in ("date", "close", "ema")}, "stop": g.get("low")}

def quote_of(m, c):
    p = os.path.join(CACHE, f"{m}_{c}_day.csv")
    if os.path.exists(p):
        try:
            d = pd.read_csv(p, dtype={"time": str}).tail(2); c1, c0 = float(d.close.iloc[-1]), float(d.close.iloc[-2])
            return {"price": round(c1, 3), "chg": round(c1 - c0, 3), "pct": round((c1 / c0 - 1) * 100, 2), "date": d.time.iloc[-1][:10]}
        except Exception: pass
    q = SEED["q"].get(f"{m}_{c}")
    return {"price": q["px"], "pct": q["pct"], "date": q.get("d")} if q else None

def norm(m, c):
    if m not in SESS: raise HTTPException(400, "market 只能是 a / us / hk")
    c = clean_code(c)
    return c.strip().upper() if m == "us" else c.strip()

# ---- 缠论站冻结推荐（与线上 summary.analyze 同源）----
_frozen_lock = threading.Lock()
try: FROZEN = json.load(open(FROZEN_PATH))
except Exception: FROZEN = {"a": {"items": []}, "us": {"items": []}, "hk": {"items": []}}

def _slim(a, m, c):
    """把 analyze 结果收成首页卡片字段。"""
    mt = stock_meta(m, c); q = quote_of(m, c)
    out = {k: a.get(k) for k in (
        "cat", "cat_sig", "dir", "view", "buy_now", "signal", "main_sig", "last_sig", "pending", "cand_kind",
        "gate_note", "reasons", "act_flat", "why_flat", "act_hold", "why_hold", "entry", "stop", "target",
        "signal_age", "signal_time", "bc_strength", "tags", "trend", "where")}
    out.update(market=m, code=c, name=mt["name"], note=mt["note"], en=mt["en"], cn=mt["cn"],
               price=(q or {}).get("price"), quote=q, sector=mt["sector"], biz=mt["biz"],
               g=INDUS.get((m, c.upper() if m == "us" else c)))
    return out

def update_frozen_item(m, c, a):
    with _frozen_lock:
        bucket = FROZEN.setdefault(m, {"items": [], "session": None, "computed_bj": None})
        items = bucket.setdefault("items", [])
        slim = _slim(a, m, c)
        for i, x in enumerate(items):
            if x["code"].upper() == c.upper():
                items[i] = slim; break
        else:
            items.append(slim)
        bucket["computed_bj"] = bj_full()
        try: json.dump(FROZEN, open(FROZEN_PATH, "w"), ensure_ascii=False)
        except Exception: pass

def analyze_day(m, c, allow_fetch=True):
    c = clean_code(c)
    df = load(m, c, "day", allow_fetch=allow_fetch, priority=True)
    res = compute(df, m, c, "day")
    a = analyze_cached(df, res, m, c, "day")
    update_frozen_item(m, c, a)
    return df, res, a

def backtest_bsp(df, res, period="day"):
    """按缠论买卖点回放：已出现的买点 → 下一根开盘买入；止损＝买点价；下一卖点或止损离场。
    与首页「推荐买入」同一套 bsp 来源（chan.py），规则简化为可回测的固定撮合。"""
    K = df.reset_index(drop=True); n = len(K)
    O = K["open"].astype(float).values; H = K["high"].astype(float).values
    Lo = K["low"].astype(float).values; C = K["close"].astype(float).values
    T = K["time"].astype(str).tolist()
    bsp = sorted(res.get("bsp") or [], key=lambda p: p["x"])
    buys = [p for p in bsp if p.get("buy")]
    sells = [p for p in bsp if not p.get("buy")]
    trades = []; i_sell = 0
    for b in buys:
        xi = int(b["x"])
        if xi + 1 >= n: continue
        # 入场：信号下一根开盘
        ei = xi + 1; ep = float(O[ei]); stop = float(b["y"]); typ = str(b.get("type") or "")
        # 找之后的卖点
        exit_i = None; why = None; xp = None
        for s in sells:
            if int(s["x"]) > xi:
                # 先在 [ei, sell_x] 检查止损
                sj = int(s["x"])
                for k in range(ei, min(sj, n - 1) + 1):
                    if Lo[k] <= stop:
                        exit_i = k; xp = min(float(O[k]), stop); why = "触及失效位（买点价）"; break
                if exit_i is not None: break
                if sj + 1 < n:
                    exit_i = sj + 1; xp = float(O[exit_i]); why = "下一卖点后开盘（%s）" % s.get("type")
                else:
                    exit_i = sj; xp = float(C[sj]); why = "卖点当日收盘（末根）"
                break
        if exit_i is None:
            # 无后续卖点：检查止损，否则持有到末
            for k in range(ei, n):
                if Lo[k] <= stop:
                    exit_i = k; xp = min(float(O[k]), stop); why = "触及失效位（买点价）"; break
            if exit_i is None:
                exit_i = n - 1; xp = float(C[-1]); why = "回测期末未平仓"
        ret = xp / ep - 1
        trades.append({
            "sig_t": T[xi][:16], "typ": typ, "entry_t": T[ei][:16], "entry": round(ep, 4),
            "stop": round(stop, 4), "exit_t": T[exit_i][:16], "exit": round(xp, 4),
            "ret": round(ret, 4), "pnl_pct": round(ret * 100, 2), "why": why,
            "bars": int(exit_i - ei), "open": why == "回测期末未平仓"})
    closed = [t for t in trades if not t["open"]]
    wins = [t for t in closed if t["ret"] > 0]
    losses = [t for t in closed if t["ret"] <= 0]
    avg_w = (sum(t["ret"] for t in wins) / len(wins)) if wins else 0
    avg_l = (sum(t["ret"] for t in losses) / len(losses)) if losses else 0
    pf = (sum(t["ret"] for t in wins) / abs(sum(t["ret"] for t in losses))) if losses and sum(t["ret"] for t in losses) != 0 else (999 if wins else 0)
    eq = 1.0
    for t in closed: eq *= (1 + t["ret"])
    return {
        "rules": "信号＝chan.py 笔买卖点（与缠论站同源）；买入＝买点下一根开盘；止损＝买点价（失效位）；卖出＝下一卖点后开盘，或触及失效位。不含滑点/税费。仅供参考。",
        "period": period, "n_signals": len(buys), "n_trades": len(trades), "n_closed": len(closed),
        "n_open": sum(1 for t in trades if t["open"]),
        "win_rate": round(len(wins) / len(closed), 4) if closed else None,
        "avg_win": round(avg_w, 4), "avg_loss": round(avg_l, 4),
        "payoff": round(abs(avg_w / avg_l), 3) if avg_l else None,
        "profit_factor": round(pf, 3) if pf < 900 else None,
        "cum_ret": round(eq - 1, 4),
        "avg_bars": round(sum(t["bars"] for t in closed) / len(closed), 1) if closed else None,
        "trades": trades[-80:],  # 最近 80 笔
    }

# ---- FastAPI ----
app = FastAPI(title="chan-local")


@app.middleware("http")
async def revalidate_navigation(request, call_next):
    response = await call_next(request)
    if request.url.path == "/nav.js" or response.headers.get("content-type", "").startswith("text/html"):
        response.headers["Cache-Control"] = "no-cache"
    return response

def _has_periods(m, c):
    return {p: os.path.exists(os.path.join(CACHE, f"{m}_{c}_{p}.csv")) for p in ("day", "30m", "5m")}

def _bare_analysis(df):
    """裸 K 占位，供首屏先出图；正式结论仍走 summary.analyze。"""
    px = float(df["close"].iloc[-1])
    return {"price": round(px, 3), "act_flat": "加载中", "act_hold": "加载中", "why_flat": "", "why_hold": "",
            "view": "加载中", "tags": [], "zs": None, "bc": [], "macd_bc": [], "last_bsp": None, "last_buy": None,
            "entry": None, "stop": None, "target": None, "where": "", "seg_dir": "", "bi_dir": "", "trend": "",
            "signal_age": None, "main_sig": "", "signal": "", "last_sig": "", "cand_sig": "", "level_note": [],
            "momentum": "", "macd": "", "ma20": None, "rr": None, "reasons": [], "gates": {}, "gate_note": "",
            "cand_kind": "", "cat": "", "reso_src": "", "pre_cat": "", "invalid": False}

@app.get("/api/kraw")
def api_kraw(code: str = Query(...), market: str = Query("a"), period: str = Query("day"),
             nofetch: int = Query(0)):
    """只返回裸 K（读盘缓存，不算缠论）。有 CSV 时毫秒级；nofetch=1 时绝不打 OpenD。"""
    c = norm(market, code); m = market
    if period not in PERIODS: raise HTTPException(400, "period 只能是 day / 30m / 5m")
    t0 = time.time()
    try:
        df = load(m, c, period, allow_fetch=(not nofetch), priority=True)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, "暂无缓存：" + str(e)[:100])
    mt = stock_meta(m, c)
    k = df[["time", "open", "close", "low", "high"]].values.tolist()
    bare = _bare_analysis(df)
    return {"code": c, "market": m, "period": period, "cached": True, "bare": True,
            "name": mt["name"], "en": mt["en"], "cn": mt["cn"], "note": mt["note"],
            "quote": quote_of(m, c), "analysis": bare, "day_analysis": bare, "sv1": None,
            "reso": None, "data_date": str(df["time"].iloc[-1])[:16], "count": len(k), "kline": k,
            "volume": [float(v) for v in df["volume"].fillna(0)],
            "bi": [], "seg": [], "zs": [], "segzs": [], "bsp": [], "times": [],
            "src": "futu", "stale": bool(df.attrs.get("err")),
            "updated": dt.datetime.fromtimestamp(df.attrs["mtime"], SH).strftime("%H:%M:%S"),
            "trading": is_trading(m), "kind": "index" if m == "a" and c in A_INDEX_NAMES else "stock", "has_periods": _has_periods(m, c),
            "ms": int((time.time() - t0) * 1000),
            "note_chan": "裸 K 秒开；缠论结构加载中。仅供参考，不构成投资建议。",
            "model_src": "缠论站日线模型（summary.analyze）"}

@app.get("/api/chan")
def api_chan(code: str = Query(...), market: str = Query("a"), period: str = Query("day"),
             nofetch: int = Query(0)):
    c = norm(market, code); m = market
    if period not in PERIODS: raise HTTPException(400, "period 只能是 day / 30m / 5m")
    t0 = time.time()
    # nofetch=1：只吃已有 CSV，供前端懒预热，绝不打 OpenD、不拖其它请求
    df = load(m, c, period, allow_fetch=(not nofetch), priority=True)
    res = compute(df, m, c, period)
    ana = analyze_cached(df, res, m, c, period)
    if period == "day":
        day_a = ana
        # 冻结表更新放到后台，不拖首屏
        threading.Thread(target=lambda: update_frozen_item(m, c, ana), daemon=True).start()
    else:
        day_a = ana
        try:
            # 优先用已冻结日线结论；没有才算，且只用缓存不阻塞拉数
            with _frozen_lock:
                hit = next((x for x in (FROZEN.get(m) or {}).get("items") or [] if clean_code(x.get("code")).upper() == c.upper()), None)
            if hit and hit.get("cat"):
                day_a = {k: hit.get(k) for k in (
                    "cat", "cat_sig", "dir", "view", "buy_now", "signal", "main_sig", "last_sig", "pending", "cand_kind",
                    "gate_note", "reasons", "act_flat", "why_flat", "act_hold", "why_hold", "entry", "stop", "target",
                    "signal_age", "signal_time", "bc_strength", "tags", "trend", "where")}
            else:
                dd = load(m, c, "day", allow_fetch=False, priority=True)
                day_a = analyze_cached(dd, compute(dd, m, c, "day"), m, c, "day")
        except Exception:
            day_a = ana
    mt = stock_meta(m, c)
    k = df[["time", "open", "close", "low", "high"]].values.tolist()
    # 不再自动预取 30m/5m：交易时段会占满 OpenD 全局锁，拖慢下一只个股。
    # 其它周期由前端切换时再拉；懒预热用 nofetch=1。
    return {"code": c, "market": m, "period": period, "cached": True, "bare": False,
            "name": mt["name"], "en": mt["en"], "cn": mt["cn"], "note": mt["note"],
            "quote": quote_of(m, c), "analysis": ana, "day_analysis": day_a, "sv1": sv1_of(m, c),
            "reso": None, "data_date": str(df["time"].iloc[-1])[:16], "count": len(k), "kline": k,
            "volume": [float(v) for v in df["volume"].fillna(0)], **res,
            "src": "futu", "stale": bool(df.attrs.get("err")),
            "updated": dt.datetime.fromtimestamp(df.attrs["mtime"], SH).strftime("%H:%M:%S"),
            "trading": is_trading(m), "kind": "index" if m == "a" and c in A_INDEX_NAMES else "stock", "has_periods": _has_periods(m, c),
            "ms": int((time.time() - t0) * 1000),
            "note_chan": "缠论结构与建议由 chan.py + summary.analyze 生成（与线上缠论站同源）。" + ("" if is_trading(m) else "当前休市，显示最后一次缓存。") + "仅供参考，不构成投资建议。",
            "model_src": "缠论站日线模型（summary.analyze）"}

@app.get("/api/summary")
def api_summary(code: str = Query(...), market: str = Query("a")):
    c = norm(market, code)
    df, res, s = analyze_day(market, c, allow_fetch=is_trading(market) or not os.path.exists(os.path.join(CACHE, f"{market}_{c}_day.csv")))
    mt = stock_meta(market, c)
    s = dict(s); s.update(market=market, code=c, name=mt["name"], note=mt["note"], en=mt["en"], cn=mt["cn"],
                          updated=dt.datetime.fromtimestamp(df.attrs["mtime"], SH).strftime("%H:%M"),
                          stale=bool(df.attrs.get("err")), sv1=sv1_of(market, c), model_src="缠论站日线模型（summary.analyze）")
    return s

@app.get("/api/backtest")
def api_backtest(code: str = Query(...), market: str = Query("a"), period: str = Query("day")):
    c = norm(market, code)
    if period not in PERIODS: raise HTTPException(400, "period 只能是 day / 30m / 5m")
    # 回测可用缓存；交易时段也允许拉一次以更新
    df = load(market, c, period, allow_fetch=True)
    res = compute(df, market, c, period)
    bt = backtest_bsp(df, res, period)
    mt = stock_meta(market, c)
    bt.update(code=c, market=market, name=mt["name"], note=mt["note"],
              data_date=str(df["time"].iloc[-1])[:16], count=len(df),
              model_src="缠论站买卖点回放（chan.py bsp）", updated=bj_full())
    return bt

@app.get("/api/home")
def api_home():
    # 主推荐：缠论站日线模型分类；按市场拆开，不混排
    empty = lambda: {"buy": [], "bull": [], "bear": [], "caution": []}
    by_m = {m: empty() for m in ("us", "a", "hk")}
    by = empty()
    with _frozen_lock:
        for m, bucket in FROZEN.items():
            if m not in by_m: continue
            for x in bucket.get("items") or []:
                cat = x.get("cat") or "none"
                if cat not in by_m[m]: continue
                code = clean_code(x.get("code") or "")
                if not code: continue
                xx = dict(x); xx["code"] = code; xx["market"] = m
                mt = stock_meta(m, code); xx["name"] = mt["name"]; xx["note"] = mt["note"]; xx["en"] = mt["en"]; xx["cn"] = mt["cn"]
                # 推荐剔除 ST / *ST（按中文名），不进买入/看多/看空/谨慎
                if is_st_name(xx["name"]) or is_st_name(mt.get("cn")):
                    continue
                xx["quote"] = quote_of(m, code); xx["price"] = (xx["quote"] or {}).get("price", xx.get("price"))
                xx["g"] = INDUS.get((m, code.upper() if m == "us" else code))
                by_m[m][cat].append(xx); by[cat].append(xx)
    def rk(x):
        t = str(x.get("cat_sig") or "")
        pri = 0 if "三" in t else 1 if ("二" in t or "类二" in t) else 2
        age = x.get("signal_age") if x.get("signal_age") is not None else 999
        return (pri, age)
    for m in by_m:
        for k in by_m[m]: by_m[m][k] = sorted(by_m[m][k], key=rk)
    for k in by: by[k] = sorted(by[k], key=rk)

    sv1_by = {m: [] for m in ("us", "a", "hk")}; sv1 = []
    for k in SV1_KEYS:
        m, c = k.split("_", 1); c = clean_code(c); md = sv1_of(m, c)
        if not md: continue
        mt = stock_meta(m, c)
        row = {"m": m, "c": c, "n": mt["name"], "note": mt["note"], "g": INDUS.get((m, c)), "q": quote_of(m, c), "model": md}
        sv1.append(row); sv1_by.setdefault(m, []).append(row)

    gs = []
    for mk in SEED["groups"]:
        gs.append({"m": mk["m"], "label": mk["label"], "trading": is_trading(mk["m"]),
                   "groups": [{"name": g["name"], "items": [
                       (lambda it, m=mk["m"]: (lambda mt: {"c": it["c"], "n": mt["name"], "note": mt["note"], "en": mt["en"], "cn": mt["cn"], "q": quote_of(m, it["c"].upper() if m == "us" else it["c"])})(stock_meta(m, it["c"].upper() if m == "us" else it["c"])))(it)
                       for it in g["items"]]} for g in mk["groups"]]})
    frozen_meta = {m: {"computed_bj": (FROZEN.get(m) or {}).get("computed_bj"), "session": (FROZEN.get(m) or {}).get("session"),
                       **{k: (FROZEN.get(m) or {}).get(k) for k in ("for_date", "intraday", "expected_session", "stale", "stale_n", "source")},
                       "n": len([x for x in (FROZEN.get(m) or {}).get("items") or [] if clean_code(x.get("code") or "")])} for m in ("a", "us", "hk")}
    return {"model_src": "缠论站日线模型（summary.analyze，与线上同源）",
            "rules": SUM.RULES, "buy": by["buy"], "bull": by["bull"], "bear": by["bear"], "caution": by["caution"],
            "by_market": by_m, "sv1": sv1, "sv1_by_market": sv1_by, "markets": gs, "now": bj(), "status": STATUS, "frozen": frozen_meta,
            "totals": {k: len(by[k]) for k in by},
            "totals_by_market": {m: {k: len(by_m[m][k]) for k in by_m[m]} for m in by_m}}

@app.get("/api/quotes")
def api_quotes(codes: str = ""):
    out = {}
    for x in codes.split(","):
        if ":" in x:
            m, c = x.split(":", 1); q = quote_of(m, c.upper() if m == "us" else c); out[f"{m}:{c}"] = q
    return out

@app.get("/api/me")
def api_me(): return {"user": None}


_hot_lock = threading.Lock()
_hot_cache = {"items": [], "updated": None, "error": None, "expires": 0}


@app.get("/api/us_trade_heat")
def us_trade_heat():
    from futu import HotListSortField, Market, OpenQuoteContext, RET_OK

    with _hot_lock:
        if time.monotonic() >= _hot_cache["expires"]:
            quote = None
            try:
                quote = OpenQuoteContext(host="127.0.0.1", port=11111)
                status, result = quote.get_hot_list(Market.US, sort_field=HotListSortField.TRADE_HEAT, count=10)
                if status != RET_OK or result[1].empty:
                    raise RuntimeError("OpenD 未返回热度榜")
                items = [{"code": row["security"].split(".", 1)[-1], "name": row["name"],
                          "heat": int(row["trade_heat"])} for row in result[1].to_dict("records")]
                _hot_cache.update(items=items, updated=bj_full(), error=None, expires=time.monotonic()+300)
            except Exception:
                _hot_cache.update(error="富途交易热度榜暂未取得", expires=time.monotonic()+60)
            finally:
                if quote is not None:
                    quote.close()
        return {field: _hot_cache[field] for field in ("items", "updated", "error")}


@app.get("/api/fav")
def api_fav(): return {"user": None, "items": []}
@app.get("/api/watch")
def api_watch(): return {"items": []}
@app.get("/api/alerts")
def api_alerts(): return {"items": []}
@app.get("/api/push")
def api_push(): return {"configured": False}

@app.get("/api/suggest")
def api_suggest(q: str = ""):
    q = q.strip().upper(); out = []
    for (m, c), mt in list(META.items()):
        n = mt.get("n") or ""
        if q and (q in c.upper() or q in n.upper() or q in (mt.get("en") or "").upper() or q in (mt.get("cn") or "")):
            out.append({"market": m, "code": c, "name": n, "note": mt.get("note")})
        if len(out) >= 12: break
    return {"items": out}

@app.get("/api/status")
def api_status():
    return {"now": bj(), "trading": {m: is_trading(m) for m in SESS}, "model_src": "缠论站日线模型", **STATUS}

@app.post("/api/names/refresh")
def api_names_refresh(limit: int = Query(80)):
    """用本机 OpenD 补中文名（只读 get_stock_basicinfo），不拉 K 线。"""
    n = fill_names_futu(limit=limit)
    return {"updated": n, "missing": len(NAMES_DB.get("missing") or [])}

def _frozen_idx():
    out = {}
    with _frozen_lock:
        for m, b in FROZEN.items():
            for x in (b.get("items") or []):
                c = clean_code(x.get("code") or "")
                if c: out[(m, c)] = x
    return out

FUTU_FAV_GROUP = "特别关注"
_ffav = {"t": 0.0, "items": [], "err": None}
def futu_fav_list():
    """只读：富途自选「特别关注」分组，10 分钟缓存；读取失败沿用上次结果。跳过指数，避免与同号个股混淆。"""
    if time.time() - _ffav["t"] < 600: return _ffav["items"]
    try:
        from futu import OpenQuoteContext, RET_OK
        ctx = OpenQuoteContext(host="127.0.0.1", port=11111)
        try: ret, df = ctx.get_user_security(FUTU_FAV_GROUP)
        finally: ctx.close()
        if ret != RET_OK: raise RuntimeError(str(df)[:80])
        out = []
        for fc in df["code"].tolist():
            mk, cd = fc.split(".", 1)
            if mk in ("SH", "SZ", "BJ"):
                if (mk == "SH" and cd.startswith("000")) or (mk == "SZ" and cd.startswith("399")): continue
                out.append(("a", cd))
            elif mk == "HK": out.append(("hk", cd))
            elif mk == "US": out.append(("us", cd.upper()))
        _ffav.update(t=time.time(), items=out, err=None)
    except Exception as e:
        _ffav.update(t=time.time(), err=str(e)[:100]); print("富途特别关注读取失败", str(e)[:100], flush=True)
    return _ffav["items"]

_fsnap = {"t": 0.0, "key": "", "d": {}, "err": None}
def fav_snapshots(keys):
    """只读：富途实时快照（不占历史K线额度），30 秒缓存；失败返回上次结果。"""
    fcs = [futu_code(m, c) for m, c in keys]; k = ",".join(sorted(fcs))
    if k == _fsnap["key"] and time.time() - _fsnap["t"] < 30: return _fsnap["d"]
    try:
        from futu import OpenQuoteContext, RET_OK
        ctx = OpenQuoteContext(host="127.0.0.1", port=11111); out = {}
        try:
            for i in range(0, len(fcs), 200):
                ret, df = ctx.get_market_snapshot(fcs[i:i + 200])
                if ret != RET_OK:
                    ok = []
                    for fc in fcs[i:i + 200]:
                        r1, d1 = ctx.get_market_snapshot([fc])
                        if r1 == RET_OK: ok.append(d1)
                    if not ok: continue
                    df = pd.concat(ok)
                for r in df.to_dict("records"):
                    lp, pc = float(r.get("last_price") or 0), float(r.get("prev_close_price") or 0)
                    if lp > 0: out[r["code"]] = {"price": round(lp, 3), "pct": round((lp / pc - 1) * 100, 2) if pc > 0 else None, "time": str(r.get("update_time"))[:16]}
        finally: ctx.close()
        _fsnap.update(t=time.time(), key=k, d=out, err=None)
    except Exception as e:
        _fsnap.update(t=time.time(), err=str(e)[:100]); print("收藏快照失败", str(e)[:100], flush=True)
    return _fsnap["d"]

@app.get("/api/fav_cards")
def api_fav_cards(codes: str = "", offset: int = 0, limit: int = 12, lite: int = 0):
    """本地版收藏卡片：富途「特别关注」（只读）在前，浏览器 localStorage 收藏在后；只按代码补名称/行情/日线结论（只读缓存）。"""
    fu = [(m, c) for m, c in futu_fav_list()]
    fk = {(m, c) for m, c in fu}
    site = [tuple(x.split(":", 1)) for x in codes.split(",") if ":" in x]
    site = [(m, c.upper() if m == "us" else c) for m, c in site]
    keys = [(m, c, "futu") for m, c in fu] + [(m, c, "site") for m, c in site if (m, c) not in fk]
    idx = _frozen_idx(); rows = []
    page = keys[offset:offset + limit]
    snaps = fav_snapshots([(m, c) for m, c, _ in page]) if page else {}
    for m, c, src in page:
        mt = stock_meta(m, c); f = idx.get((m, c)) or {}; q = quote_of(m, c)
        if not lite:
            try:
                df = load(m, c, "day", allow_fetch=False)
                f = dict(f, **analyze_cached(df, compute(df, m, c, "day"), m, c, "day"))
            except Exception:
                pass
        fields = ("cat", "view", "cat_sig", "signal", "act_flat", "why_flat", "entry", "stop",
                  "target", "dir", "pending", "where", "date")
        row = {key: f.get(key) for key in fields}
        row.update(market=m, code=c, name=mt["name"], quote=q, price=(q or {}).get("price"),
                   src=src, intraday=snaps.get(futu_code(m, c)) or {})
        if not f:
            row.update(view="日线未核验", why_flat="暂无可用日线分析")
        rows.append(row)
    return {"user": None, "items": rows, "total": len(keys), "futu": {"group": FUTU_FAV_GROUP, "n": len(fu), "err": _ffav["err"]}}

@app.get("/api/signal_alerts")
def api_signal_alerts(market: str = "a"):
    """本地版提醒：取最近一次收盘冻结的买入类信号（已剔 ST），供开盘参考。"""
    b = FROZEN.get(market) or {}
    ses = str(b.get("computed_bj") or "")[:10] or dt.datetime.now(SH).strftime("%Y-%m-%d")
    items = []
    for x in b.get("items") or []:
        if x.get("cat") not in ("buy", "bull"): continue
        c = clean_code(x.get("code") or "")
        if not c: continue
        mt = stock_meta(market, c)
        if is_st_name(mt["name"]) or is_st_name(mt.get("cn")): continue
        rs = x.get("reasons") or []
        items.append({"market": market, "code": c, "name": mt["name"], "session": ses, "for_date": ses,
                      "kind": "后验" if "已确认" in str(x.get("cat_sig")) else "预判", "side": "买",
                      "signal": x.get("cat_sig") or x.get("signal") or "",
                      "shape": [r for r in rs if "形态" in r or "买点" in r][:2],
                      "dyn": [r for r in rs if "MACD" in r or "动能" in r or "柱" in r][:2],
                      "price": x.get("price"), "entry": x.get("entry"), "stop": x.get("stop"), "target": x.get("target"), "review": []})
    return {"items": items, "latest_session": ses}

STATIC = os.path.join(BASE, "static")
# 重构 1030：导航结构对齐 csnpk —— / 搜索首页，/home 全部推荐，/fav 收藏，/alerts 提醒
@app.get("/")
def index(request: Request):
    return FileResponse(os.path.join(STATIC, "index.html" if request.query_params.get("code") else "search.html"))
from fastapi.responses import RedirectResponse
@app.get("/home")
def _home(): return RedirectResponse("./")

app.mount("/vendor", StaticFiles(directory=os.path.join(BASE, "vendor")), name="vendor")
app.mount("/", StaticFiles(directory=STATIC), name="static")

# ---- 补中文名 ----
def fill_names_futu(limit=120):
    from futu import OpenQuoteContext, RET_OK, Market, SecurityType
    miss_by = {"a": [], "hk": [], "us": []}
    for (m, c), v in META.items():
        has = v.get("cn") and re.search(r"[\u4e00-\u9fff]", str(v["cn"]))
        if not has and m in miss_by: miss_by[m].append((m, c))
    # 三市场均分额度，避免美股排前面挤掉港股
    per = max(20, limit // 3)
    miss = miss_by["a"][:per] + miss_by["hk"][:per] + miss_by["us"][:per]
    if not miss: return 0
    ctx = OpenQuoteContext(host="127.0.0.1", port=11111); n = 0
    try:
        for mkt_key, futu_mkt in (("a", None), ("hk", Market.HK), ("us", Market.US)):
            part = [(m, c) for m, c in miss if m == mkt_key]
            if not part: continue
            if mkt_key == "a":
                sh = ["SH." + c for m, c in part if c[0] in "659"]
                sz = ["SZ." + c for m, c in part if c[0] not in "65948"]
                bj = ["BJ." + c for m, c in part if c[0] in "48"]
                for mk, codes in ((Market.SH, sh), (Market.SZ, sz), (Market.SH, bj)):
                    if not codes: continue
                    for i in range(0, len(codes), 200):
                        ret, d = ctx.get_stock_basicinfo(mk, SecurityType.STOCK, codes[i:i+200])
                        if ret != RET_OK: print("basicinfo a", d, flush=True); continue
                        for _, row in d.iterrows():
                            code = str(row["code"]).split(".")[-1]
                            nm = str(row.get("name") or "")
                            if re.search(r"[\u4e00-\u9fff]", nm):
                                ind = str(row.get("industry") or row.get("stock_owner") or "").strip()
                                set_name("a", code, cn=nm, sector=ind or None, biz=ind or None); n += 1
            else:
                codes = [futu_code(m, c) for m, c in part]
                for i in range(0, len(codes), 200):
                    ret, d = ctx.get_stock_basicinfo(futu_mkt, SecurityType.STOCK, codes[i:i+200])
                    if ret != RET_OK: print("basicinfo", mkt_key, d, flush=True); continue
                    for _, row in d.iterrows():
                        raw = str(row["code"]); code = raw.split(".")[-1]
                        if mkt_key == "hk": code = str(int(code)).zfill(5) if str(code).isdigit() else code.zfill(5)
                        nm = str(row.get("name") or "")
                        if mkt_key == "us":
                            ind = str(row.get("industry") or "").strip()
                            set_name("us", code, en=nm if not re.search(r"[\u4e00-\u9fff]", nm) else None,
                                     cn=nm if re.search(r"[\u4e00-\u9fff]", nm) else None,
                                     sector=ind or None, biz=ind or None)
                            if re.search(r"[\u4e00-\u9fff]", nm): n += 1
                        else:
                            if re.search(r"[\u4e00-\u9fff]", nm):
                                ind = str(row.get("industry") or "").strip()
                                set_name(mkt_key, code, cn=nm, sector=ind or None, biz=ind or None); n += 1
        us_miss = [c for (m, c), v in META.items() if m == "us" and not (v.get("cn") and re.search(r"[\u4e00-\u9fff]", str(v.get("cn") or "")))]
        us_miss = us_miss[:80]
        if us_miss:
            n += fill_us_cn_sina(us_miss)
    finally:
        ctx.close()
    persist_names(); return n

def fill_us_cn_sina(codes):
    import urllib.request as ur
    n = 0
    for i in range(0, len(codes), 50):
        part = [c.upper() for c in codes[i:i+50]]
        try:
            rq = ur.Request("https://hq.sinajs.cn/list=" + ",".join("gb_" + c.lower().replace(".", "$") for c in part),
                            headers={"Referer": "https://finance.sina.com.cn"})
            txt = ur.urlopen(rq, timeout=10).read().decode("gbk", "ignore")
            for line in txt.splitlines():
                mm = re.match(r'var hq_str_gb_([a-z$.\-]+)="([^,"]*)', line)
                if not mm: continue
                nm = mm.group(2).split("-")[0].strip()
                if re.search(r"[\u4e00-\u9fff]", nm):
                    set_name("us", mm.group(1).upper().replace("$", "."), cn=nm); n += 1
        except Exception as e:
            print("sina cn", e, flush=True)
        time.sleep(0.3)
    return n

# ---- 后台：交易时段刷新「当前推荐 + strategy_v1」日线；收盘后重算 analyze ----
STATUS = {"last_loop": None, "last_refresh": {}, "post_close_done": {}, "last_scan": None, "names_filled": 0}

def _codes_to_refresh(m):
    codes = set()
    with _frozen_lock:
        for x in (FROZEN.get(m) or {}).get("items") or []:
            if x.get("cat") in ("buy", "bull", "bear", "caution"):
                codes.add(x["code"])
    for k in SV1_KEYS:
        mm, c = k.split("_", 1)
        if mm == m: codes.add(c)
    return list(codes)

def _refresh_market(m):
    n = 0
    codes = [clean_code(c) for c in _codes_to_refresh(m)]
    codes = [c for c in codes if c]
    for c in codes[:20]:  # 限频：每轮最多 20，让路用户请求
        if _user_wait[0] > 0:
            time.sleep(0.2); continue
        try:
            p = os.path.join(CACHE, f"{m}_{c}_day.csv")
            fetch_futu(m, c, "day", priority=False).to_csv(p, index=False)
            df = pd.read_csv(p, dtype={"time": str}); df.attrs["mtime"] = os.path.getmtime(p)
            a = analyze_cached(df, compute(df, m, c, "day"), m, c, "day")
            update_frozen_item(m, c, a)
            if f"{m}_{c}" in SV1_KEYS:
                g = gate_sv1(df, m)
                if g: GATE[f"{m}_{c}"] = g
            n += 1
        except Exception as e:
            print("refresh 失败", m, c, str(e)[:100], flush=True)
    STATUS["last_refresh"][m] = f"{bj()} 刷新 {n} 只"

def _sanitize_frozen():
    """启动时清洗误把周期后缀写进 code 的冻结条目，合并去重。"""
    with _frozen_lock:
        changed = False
        for m in list(FROZEN.keys()):
            bucket = FROZEN.setdefault(m, {"items": [], "session": None, "computed_bj": None})
            items = bucket.get("items") or []
            merged = {}
            for x in items:
                c = clean_code(x.get("code") or "")
                if not c: changed = True; continue
                if c != x.get("code"): changed = True
                xx = dict(x); xx["code"] = c; xx["market"] = m
                key = c.upper()
                old = merged.get(key)
                if old is None:
                    merged[key] = xx
                else:
                    # 保留有分类的、或更新时间更新的
                    if (xx.get("cat") in ("buy","bull","bear","caution")) and (old.get("cat") not in ("buy","bull","bear","caution")):
                        merged[key] = xx
            new_items = list(merged.values())
            if len(new_items) != len(items): changed = True
            bucket["items"] = new_items
        if changed:
            try: json.dump(FROZEN, open(FROZEN_PATH, "w"), ensure_ascii=False)
            except Exception: pass
            print("sanitize_frozen done", {m: len((FROZEN.get(m) or {}).get("items") or []) for m in ("a","us","hk")}, flush=True)

def _scan_cached():
    """对已有日线缓存的股票重跑 analyze，扩充本地冻结推荐（不新拉额度）。"""
    n = 0
    for fn in os.listdir(CACHE):
        parsed = parse_cache_name(fn)
        if not parsed or parsed[2] != "day": continue
        m, c, _ = parsed
        if m not in SESS: continue
        c = clean_code(c)
        try:
            df = pd.read_csv(os.path.join(CACHE, fn), dtype={"time": str})
            df.attrs["mtime"] = os.path.getmtime(os.path.join(CACHE, fn))
            a = analyze_cached(df, compute(df, m, c, "day"), m, c, "day")
            update_frozen_item(m, c, a); n += 1
        except Exception as e:
            print("scan", fn, str(e)[:80], flush=True)
    STATUS["last_scan"] = f"{bj()} 扫描缓存 {n} 只"

def _prefetch_recs():
    """预取推荐股三个周期（有缓存则跳过），后台低优先级。"""
    codes = []
    with _frozen_lock:
        for m in ("us", "a", "hk"):
            for x in (FROZEN.get(m) or {}).get("items") or []:
                if x.get("cat") in ("buy", "bull"):
                    codes.append((m, clean_code(x["code"])))
    for m, c in codes[:25]:
        for period in ("day", "30m", "5m"):
            p = os.path.join(CACHE, f"{m}_{c}_{period}.csv")
            if os.path.exists(p) and (not is_trading(m) or time.time() - os.path.getmtime(p) <= TTL):
                # 预热缠论缓存
                try:
                    df = pd.read_csv(p, dtype={"time": str}); df.attrs["mtime"] = os.path.getmtime(p)
                    compute(df, m, c, period)
                except Exception: pass
                continue
            _bg_fetch(m, c, period)
            time.sleep(0.05)

# ---- 数据日/适用日：按推荐池日线缓存最后一根 bar 计算 ----
def _bar_date(m, c):
    p = os.path.join(CACHE, f"{m}_{c}_day.csv")
    try:
        with open(p) as f: last = f.read().strip().splitlines()[-1]
        return last.split(",")[0].strip('"')[:10] if last else None
    except Exception: return None

def _next_wd(d):
    d = d + dt.timedelta(days=1)
    while d.weekday() >= 5: d += dt.timedelta(days=1)
    return d

def _expected_session(m):
    """最近一个已收盘交易日（不含节假日判断）。"""
    tz, ss = SESS[m]; t = dt.datetime.now(dt.timezone.utc).astimezone(tz); d = t.date()
    if t.weekday() >= 5 or t.hour * 60 + t.minute < ss[-1][1]:
        d = d - dt.timedelta(days=1)
        while d.weekday() >= 5: d -= dt.timedelta(days=1)
    return d.isoformat()

def _pool_codes(m):
    """冻结池里全部股票（去重清洗，不再按 cat 过滤）。
    只取本地已有日线缓存的票：这些票 30 天内已占过富途历史K额度，重拉不再消耗新额度；
    没缓存的 seed 票不在这里拉，避免一次性吃掉几百只额度。"""
    out, seen = [], set()
    with _frozen_lock:
        items = list((FROZEN.get(m) or {}).get("items") or [])
    for x in items:
        c = clean_code(x.get("code") or "")
        if not c or c.upper() in seen: continue
        if not os.path.exists(os.path.join(CACHE, f"{m}_{c}_day.csv")): continue
        seen.add(c.upper()); out.append(c)
    return out

def _recalc_session(m):
    if m not in SESS: return
    tz, ss = SESS[m]; t = dt.datetime.now(dt.timezone.utc).astimezone(tz); today = t.date().isoformat()
    ds = [d for d in (_bar_date(m, c) for c in _pool_codes(m)) if d]
    if not ds: return
    mx = max(ds); intraday = (mx == today and t.hour * 60 + t.minute < ss[-1][1])
    if intraday:
        sess = _expected_session(m); for_d = today
    else:
        sess = mx; for_d = _next_wd(dt.date.fromisoformat(mx)).isoformat()
    exp = _expected_session(m)
    with _frozen_lock:
        b = FROZEN.setdefault(m, {"items": []})
        b.update(session=sess, for_date=for_d, intraday=intraday, expected_session=exp,
                 stale=(min(ds) < exp), stale_n=len([d for d in ds if d < (today if intraday else mx)]),
                 source="local_futu")
        try: json.dump(FROZEN, open(FROZEN_PATH, "w"), ensure_ascii=False)
        except Exception: pass

def _refresh_stale(m, force=False):
    """补算冻结池全部股票的日线（不再只刷当前买入/看多）；仅限已有日线缓存的票，不扫全市场。"""
    exp = _expected_session(m); n = 0
    for c in _pool_codes(m):
        d = _bar_date(m, c)
        if not force and d and d >= exp: continue
        while _user_wait[0] > 0: time.sleep(0.2)
        try:
            p = os.path.join(CACHE, f"{m}_{c}_day.csv")
            fetch_futu(m, c, "day", priority=False).to_csv(p, index=False)
            df = pd.read_csv(p, dtype={"time": str}); df.attrs["mtime"] = os.path.getmtime(p)
            update_frozen_item(m, c, analyze_cached(df, compute(df, m, c, "day"), m, c, "day")); n += 1
        except Exception as e: print("stale refresh 失败", m, c, str(e)[:100], flush=True)
    _recalc_session(m)
    with _frozen_lock:
        _its = list((FROZEN.get(m) or {}).get("items") or [])
    _pool = _pool_codes(m)
    if len(_pool) >= 10 and not any(x.get("cat") not in (None, "none") for x in _its):
        print(f"WARN {bj()} {m} 冻结池 {len(_pool)} 只有日线缓存但推荐全为观望，检查数据/规则", flush=True)
        STATUS.setdefault("warn", {})[m] = f"{bj()} 推荐全空（池 {len(_pool)}）"
    STATUS.setdefault("catchup", {})[m] = f"{bj()} 补算 {n} 只 → session {(FROZEN.get(m) or {}).get('session')}"
    return n

def _loop():
    time.sleep(2)
    try: _sanitize_frozen()
    except Exception as e: print("sanitize", e, flush=True)
    try: _scan_cached()
    except Exception as e: print("init scan", e, flush=True)
    try: _prefetch_recs()
    except Exception as e: print("prefetch", e, flush=True)
    try:
        STATUS["names_filled"] = fill_names_futu(limit=120)
    except Exception as e: print("names", e, flush=True)
    while True:
        try:
            now = dt.datetime.now(dt.timezone.utc); STATUS["last_loop"] = bj()
            for m in SESS:
                tz, ss = SESS[m]; t = now.astimezone(tz); hm = t.hour * 60 + t.minute
                if is_trading(m): _refresh_market(m)
                elif t.weekday() < 5:
                    for a, b in ss:
                        key = f"{t.date()}_{b}"
                        if b <= hm < b + 40 and STATUS["post_close_done"].get(m) != key:
                            _refresh_stale(m, force=True); _scan_cached(); _prefetch_recs()
                            STATUS["post_close_done"][m] = key
                if not is_trading(m) and time.time() - STATUS.setdefault("catchup_ts", {}).get(m, 0) > 1800:
                    STATUS["catchup_ts"][m] = time.time()
                    _recalc_session(m)
                    if (FROZEN.get(m) or {}).get("stale"): _refresh_stale(m)
                if is_trading(m): _recalc_session(m)
            # 休市也周期性预热推荐股缠论缓存（不拉 OpenD）
            if not any(is_trading(m) for m in SESS):
                try: _prefetch_recs()
                except Exception: pass
        except Exception as e:
            print("loop err", e, flush=True)
        time.sleep(60)

if os.environ.get("CHAN_LOOP", "1") == "1":
    threading.Thread(target=_loop, daemon=True).start()
