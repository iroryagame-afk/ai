@echo off
chcp 65001 >nul
cd /d "%~dp0app"
if not exist .venv\Scripts\python.exe (
  echo 首次运行，正在安装依赖...
  python -m venv .venv || (echo 未找到 Python，请先安装 Python 3.10+ & pause & exit /b)
  .venv\Scripts\python -m pip install -r requirements.txt
)
start "" http://127.0.0.1:18791
.venv\Scripts\python -m uvicorn local_app:app --host 127.0.0.1 --port 18791
pause
