#!/bin/sh
cd "$(dirname "$0")/app"
[ -x .venv/bin/python ] || { python3 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt; }
(sleep 4; open http://127.0.0.1:18791 2>/dev/null) &
exec .venv/bin/python -m uvicorn local_app:app --host 127.0.0.1 --port 18791
